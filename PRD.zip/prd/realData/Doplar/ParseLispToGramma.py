'''
Created on 21  2014

@author: Owner
'''
import sys
import time
from defs.Rule import Rule
from defs.Sigma import Sigma
from defs.NT import NT
from defs.PL import PL
from defs.Algorithm import ExplainAndCompute
from defs.Explanation import Explanation
from math import log
import random

currentLetter = 0
Letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
Letters2 = "A B C D E F G H I J K L M N O P Q R S T U V W X Y Z"
currentNumber = 1#{letter: 1 for letter in Letters2.split(" ")}
AllNTs = []     #List of strings
AllRules = ""
AllRulesAsList = []

def probeByEntropy(exps=[]):
    
    print "------------ Explanations at this Point --------------"
    print exps
    
    mapTreesValues = {}
    treeIDtoTree = {}
    totalProbability = 0.0
    
    #Calculate P(t) = P(tree is part of the correct explanation)
    for exp in exps:
#         expProb = exp.getExpProbability()
#         totalProbability += expProb
        for tree in exp.getTrees():
            treeID = tree.getID()
            treeProb = tree.getProbability()
            treeIDtoTree[treeID] = tree
            if treeID in mapTreesValues:
                mapTreesValues[treeID] += treeProb
            else:
                mapTreesValues[treeID] = treeProb
    print "tree probability values:"
    print mapTreesValues 
    
    #Normalize P(t) to be a probability
    normalizationFactor = sum(mapTreesValues.values())
    normalised_mapTreesValues = {k: v/normalizationFactor for k, v in mapTreesValues.iteritems() }
    print normalised_mapTreesValues
    
    #Calculate Entropy in system with and without each tree
    normalizationFactor_ExpProbablity = sum(x.getExpProbability() for x in exps)
    print "normalizationFactor_ExpProbablity =", normalizationFactor_ExpProbablity

    #Collect probabilities of all explanations remaining in the system with and without tree (for normalization purposes)
    expProbsWithTree = {k: [] for k, v in mapTreesValues.iteritems() }
    expProbsWithoutTree = {k: [] for k, v in mapTreesValues.iteritems() }
    for exp in exps:
        #expNormalizedProbability = exp.getExpProbability() /normalizationFactor_ExpProbablity
        for treeID in mapTreesValues.keys():
            if treeID in exp.getTreeIDs():
                expProbsWithTree[treeID].append(exp.getExpProbability())
            else:
                expProbsWithoutTree[treeID].append(exp.getExpProbability())

    entropyWithTree = {k: 0 for k, v in mapTreesValues.iteritems() }
    entropyWithoutTree = {k: 0 for k, v in mapTreesValues.iteritems() }
    
    #Calculate the normalized Entropy
    for treeID in expProbsWithTree.keys():
        totalProbWith = sum(expProbsWithTree[treeID])
        totalProbWithout = sum(expProbsWithoutTree[treeID])
        for expProb in expProbsWithTree[treeID]:
            entropyWithTree[treeID] -= (expProb / totalProbWith) * log(expProb / totalProbWith,2)
        for expProb in expProbsWithoutTree[treeID]:
            entropyWithoutTree[treeID] -= (expProb / totalProbWithout) * log(expProb / totalProbWithout,2)
        
    print "entropyWithTree", entropyWithTree
    print "entropyWithoutTree", entropyWithoutTree
    
    #Calculate information gain per tree             
    informationGainPerTree = {}
    for treeID in normalised_mapTreesValues.keys():
        value=normalised_mapTreesValues[treeID]
        tree = treeIDtoTree[treeID]
        informationGain = value*entropyWithTree[treeID] + (1-value)*entropyWithoutTree[treeID]
        
        if informationGain in informationGainPerTree:
            informationGainPerTree[informationGain].append(treeID) 
        else:
            informationGainPerTree[informationGain] = [treeID]
    
    print "Trees by entropy:"
    print informationGainPerTree
    
    
    #Find Tree with maximum information gain (minimum entropy)
    minEntropy = min(informationGainPerTree.keys())
    treeIDToProb = informationGainPerTree[minEntropy][0]
    treeToProbeFor = treeIDtoTree[treeIDToProb]   
    
    #Ask about this tree 
    print "Is this part of your plan?"
    print informationGainPerTree[minEntropy][0]
    print treeToProbeFor.reprWithParams()
    
    input_var = raw_input("Please type y/n: ")
    newExps = []
    for exp in exps:
        if input_var=="y":
            if treeIDToProb in exp.getTreeIDs():
                newExps.append(exp)
        if input_var=="n":
            if not (treeIDToProb in exp.getTreeIDs()):

                newExps.append(exp)
    
    if 1<len(newExps):
        probeByEntropy(newExps)
    
    elif 1==len(newExps):
        print "------------------ The Final Explanation is: -------------------"
        print newExps[0]
        
    else:
        print "------------------ No Explanation Fits the Probing ------------------"

def probeByRandom(exps=[]):
    print "------------ Explanations at this Point --------------"
    print exps
    
    trees = []
    IDs = []
    for exp in exps:
        for tree in exp.getTrees():
            if tree.getID() not in IDs:
                trees.append(tree)
                IDs.append(tree.getID())
    
    tree = random.choice(trees)
    
    #Ask about this tree 
    print "Is this part of your plan?"
    print tree.getID()
    print tree.reprWithParams()
    
    input_var = raw_input("Please type y/n: ")
    newExps = []
    for exp in exps:
        if input_var=="y":
            if tree.getID() in exp.getTreeIDs():
                newExps.append(exp)
        if input_var=="n":
            if not (tree.getID() in exp.getTreeIDs()):

                newExps.append(exp)
    
    if 1<len(newExps):
        probeByRandom(newExps)
    
    elif 1==len(newExps):
        print "------------------ The Final Explanation is: -------------------"
        print newExps[0]
        
    else:
        print "------------------ No Explanation Fits the Probing ------------------"
    
    return newExps

def runAlgorithm(stringObs):
    
    Sigmas = []
    NTs = []
    Goals = []
    Observations = []
    for i in range(100):
        Sigmas.append(Sigma("A"+str(i+1)))
    
    for nt in AllNTs:
        if nt[0]=="*":
            Goals.append(NT(nt[1:]))
            NTs.append(NT(nt[1:]))
        else:
            NTs.append(NT(nt))
    
    for obs in stringObs[1:]:
        print obs
        Observations.append(Sigma(obs))

    newPL = PL(Sigmas, NTs, Goals, AllRulesAsList)
    print "here1"
    exps = ExplainAndCompute(newPL, Observations)
    return
    
    
    if len(exps)==0:
        print "No Explnanations"    
    print "\n\n"    
    explanations = 0   
    noFrontier = []
    goalsPusrued = {}
    
    exps.sort(key=Explanation.getExpProbability)
    firstflag = True
    
    #exps = probeByRandom(exps)
    while not len(exps)==0:
        exp = exps.pop()

        if firstflag:
            print "-------------\n First Exp\n-----------------"
            firstflag = False
        
        if exp.getFrontierSize()==0:
            print "-------------\n Exp with Empty Frontier\n-----------------"
           
        print exp
        for tree in exp.getTrees():
            root = tree.getRoot().get()
            if goalsPusrued.has_key(root):
                goalsPusrued[root] += exp.getExpProbability()
            else:
                goalsPusrued[root] = exp.getExpProbability()
                
    
    print goalsPusrued
    sumOfProb = sum(goalsPusrued.values())
    goalsNormPursued = {key : val/sumOfProb for key ,val in goalsPusrued.items()}
        
    print goalsNormPursued

def printDomainFile(path='C:\\Users\\Owner\\Dropbox\\Reuth\\Online Plan Recognition\\Doplar\\Results2015\\domain'+str(sys.argv[2])+'.txt'):
    global AllNTs
    global AllRules
    file = open(path, "w+")
    file.write("Sigmas\n")
    for i in range(100):
        file.write("A"+str(i+1)+" []\n")
    
    file.write("\n")
    file.write("NTs\n")
    for nt in AllNTs:
        file.write(nt+" []\n")
    
    file.write("\nRules\n")
    file.write(AllRules)
    
    file.close()
    
def printObservations(observations):
    file = open("C:\\Users\\Owner\\Dropbox\\Reuth\\Online Plan Recognition\\Doplar\\sampleObs.txt", "w+")
    for obs in observations:
        file.write(obs)
        file.write("[]\n")
    
    file.close()
    
def addRule(ruleToPrint):
    global AllRules
    global AllRulesAsList
    
    toPrint = "\n"
    toPrint += str(ruleToPrint._A) #ruleToPrint._A.get()[1:]
    toPrint += " -> "
    for child in ruleToPrint._alpha:
        if child.get()[0]=="A":
            toPrint += (str(child)+" ") # str(int(child.get()[1:])+99) + " "
        elif child.get()[0]=="B":
            toPrint += (str(child)+" ") #child.get()[1:] + " "
    toPrint += str(ruleToPrint._order)
    toPrint += "\n[]\n\n"
    AllRules += toPrint
    AllRulesAsList.append(ruleToPrint)

def generateNextLetter(definedLetter=False):
    global currentLetter
    global Letters
    global currentNumber
    
    if not definedLetter:
        letterToReturn = Letters2.split(" ")[currentLetter]
    else:
        letterToReturn = definedLetter
        
    numberToReturn = currentNumber
    currentNumber += 1
    

#     if not definedLetter:
#         letterToReturn = Letters2.split(" ")[currentLetter]
#         if currentNumber < 100:
#             numberToReturn = currentNumber[letterToReturn]
#             currentNumber[letterToReturn] += 1
#         else:
#             currentLetter += 1
#     else:
#         letterToReturn = definedLetter
#         
#     numberToReturn = currentNumber[letterToReturn]
#     currentNumber[letterToReturn] += 1
    
    return letterToReturn+str(numberToReturn)

def getDelimiters(line):
    indices = []
    openBrackets = 0
    changed = False
    
    for i in range(len(line)):
        if line[i]=="(":
            openBrackets += 1
            changed = True
        elif line[i]==")":
            openBrackets -= 1
        
        if openBrackets==0 and changed:
            indices.append(i)
            changed = False
            
    return indices 

def parseWholeFile(currentLine):
    global currentLetter
    global Letters2
    global currentNumber
    global AllNTs
    
    currentLine = currentLine[1:-1]
    delimiters = getDelimiters(currentLine)
    del1 = delimiters[0]-2
    del2 = delimiters[1]+1
    i=1
    while True:
        currentLetter = 1
        currentNumber = 1#{letter: 1 for letter in Letters2.split(" ")}
        singleProblem = currentLine[del1+2:del2]
#        print singleProblem
        
        probDels = getDelimiters(singleProblem)[0]
        recipeLibrary = singleProblem[:probDels]
        observations = singleProblem[probDels+4:-1]
        
        if i==int(sys.argv[2]):
            parseRecipeLibrary(recipeLibrary)
            sys.stdout = open('C:\Users\Owner\Dropbox\Reuth\Online Plan Recognition\Doplar\Results2015\Weight-Cut5\\res'+str(sys.argv[2])+'.txt', 'w+')
            printObservations(observations.split(" "))
            start = time.clock()
            runAlgorithm(observations.split(" "))
            elapsed = (time.clock() - start)
            print elapsed
            AllNTs = []
            AllRules = []
              
#         if i==2:
#             break  
        i+=1
        del1=del2+1
        if i==len(delimiters)+1:
            break
        elif i==len(delimiters):
            del2=len(delimiters)-1
        else:        
            del2=delimiters[i]+1
        if i==len(delimiters):
            break

def parseOrder(order):
    pairs = "["+order.replace(".", ",")+"]"
    pairs = pairs.replace(") (", "),(")
    order = eval(pairs)
    return order

def parseOrRecipe(line):
    global AllNTs
    line = line[3:-1].strip()
    newRules = []
    newNT = generateNextLetter()
    AllNTs.append(newNT)
    
    if line[1:-1].count("(")==0:
        sigmas = line.split()
        for sigma in sigmas:
            newRules.append(Rule(NT(newNT), [Sigma(sigma)]))
       
    else: 
        rules = []   
        delims = getDelimiters(line)
        i=1
        del1 = 0
        del2 = delims[0]+2 if len(delims) >=2 else len(line)
        while True:
            i+=1
            if len(line[del1:del2])<2:
                if i==len(delims)+1:
                    break
            resultOfAnd = parseAndRecipe(line[del1:del2])
            alpha = NT(resultOfAnd[0])
            newRules.append(Rule(NT(newNT), [alpha]))
            
            del1=del2
            if i==len(delims)+1:
                break
            if i==len(delims):
                del2=len(line)
            else:        
                del2=delims[i]+2  
                
    for rule in newRules:
        addRule(rule)
                    
    return (newNT, newRules) 
            
def parseAndRecipe(recipe):
    global AllNTs
    recipe = recipe.strip()[1:-1]
    recipeDelimiters = getDelimiters(recipe)
#     print recipeDelimiters

#     for x in range(len(recipeDelimiters)):
#         print recipe[recipeDelimiters[x]]
    alphaLetters = []
    i=0
    del1 = 0
    del2 = recipeDelimiters[0]+2 if len(recipeDelimiters) >= 2 else len(recipe)
    while True:
        i+=1
        currentPiece = recipe[del1:del2].strip()
        #print "current:", currentPiece
        if currentPiece=="":
            x=1
        elif currentPiece[1]=="(":
            order = parseOrder(currentPiece[1:-1])
        elif currentPiece[0]=="N":
            order = []
            resultOfOr = parseOrRecipe(currentPiece[4:])
            alphaLetters.append(NT(resultOfOr[0]))
            #print "here:", currentPiece[:2]
        elif currentPiece[1]=="O": #OR
                        #(Place in sentence, (NT, rules)) 
            resultOfOr = parseOrRecipe(currentPiece)
            alphaLetters.append(NT(resultOfOr[0]))
                      
        del1=del2
        if i==len(recipeDelimiters)+1:
            break
        elif i==len(recipeDelimiters):
            del2=len(recipe)
        else:        
            del2=recipeDelimiters[i]+2
            
    letter = generateNextLetter()
    AllNTs.append(letter)
    newRule = Rule(NT(letter), alphaLetters, order)
    addRule(newRule)
    return (letter, newRule)
    
def parseRecipeLibrary(currentLine):
    currentLine = currentLine[1:].strip()
     
    delimiters = getDelimiters(currentLine[:-1])
    if len(delimiters)!=4:
        return []
    
    recipes = []
    recipes.append(currentLine[:delimiters[0]+1])
    recipes.append(currentLine[delimiters[0]+4:delimiters[1]+1])
    recipes.append(currentLine[delimiters[1]+4:delimiters[2]+1])
    recipes.append(currentLine[delimiters[2]+4:delimiters[3]+1])
    recipes.append(currentLine[delimiters[3]+4:])
     
#     print "r1:", recipe1
#     print "r2:", recipe2
#     print "r3:", recipe3
#     print "r4:", recipe4
#     print "r5:", recipe5
    
    for i in range(5):
        result = parseAndRecipe(recipes[i])
        AllNTs.remove(result[0])
        AllNTs.append("*"+str(result[0])) 
        #addRule(result[1]) 
#     
#     addRule(parseAndRecipe(recipe2)[1])
#     addRule(parseAndRecipe(recipe3)[1])
#     addRule(parseAndRecipe(recipe4)[1])
#     addRule(parseAndRecipe(recipe5)[1])
#
     
#    printDomainFile()
    
    #print parseAndRecipe(recipe2)
    #print parseAndRecipe(recipe3)
    #print parseAndRecipe(recipe4)
    #print parseAndRecipe(recipe5)
#      
#     #End case - reached a line with no ()
#     if currentLine.count('(')==0:
#         if currentLine[0] == 'N':
#             i = 3
#         elif currentLine[0] == 'O':
#             rulesToMake = currentLine.split(" ")[1:]
#             print rulesToMake
#         else:
#             i = 3
#     else:
#         
#      

import profile

# def main():
#     profile.run('myMain()')

def main():
    grammarPath = str(sys.argv[1])
    grammarFile = open(grammarPath)
    grammarAsLine = grammarFile.read()
    
    parseWholeFile(grammarAsLine)
    
if __name__ == '__main__': main()    