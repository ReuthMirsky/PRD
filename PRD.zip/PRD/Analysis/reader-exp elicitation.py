import sys
import csv

def printValues(path):
    with open(path, 'rb') as csvfile:
        myFile = csv.reader(csvfile, delimiter=',', quotechar='|')
        instances = [[]]
        maxQueries=0
        i=0
        
        for row in myFile:
            previous=1
            for item in row:
                if float(previous)>float(item):
                    print previous
                previous=item
        return
        
if __name__ == '__main__':
#     print "Full Trees:"
#     printValues('C:\Users\dekelr\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Probing\Doplar\IJCAI-1Goal\Entropy-3\ExpsByQueries-full.csv')
#     
#     print "**************"
#     
#     print "Subtrees:"
#     printValues('C:\Users\dekelr\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Probing\Doplar\Subtrees-1 Goal\Entropy-3\ExpsByQueries - Subtrees.csv')
#
########################################
#     print "Full uninferred:"
#     printValues('C:\Users\dekelr\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Probing\Doplar\Subtrees-1 Goal\Entropy Full-Uninferred 7\ExpsByQueries.csv')
#     
#     print "Full inferred:"
#     printValues('C:\Users\dekelr\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Probing\Doplar\Subtrees-1 Goal\Entropy 7-Full Inferred\ExpsByQueries.csv')
#     
#     print "Mixed:"
#     printValues('C:\Users\dekelr\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Probing\Doplar\Subtrees-1 Goal\Entropy - Mix7 E under 3\ExpsByQueries.csv')
########################################
    print "Entropy:"
    printValues('C:\Users\Owner\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Probing\Doplar\Ambiguity Domains\\2-5-2-3-2-random\probeByEntropy-6\exps.csv')
    
#     print "MPH:"
#     printValues('C:\Users\dekelr\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Probing\Doplar\Ambiguity Domains\\1-5-2-3-2-unord\probeByMostProbableExp-6\ExpsByQueries.csv')
#     
#     print "MPP:"
#     printValues('C:\Users\dekelr\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Probing\Doplar\Ambiguity Domains\\1-5-2-3-2-unord\probeByMostProbableTree-6\ExpsByQueries.csv')
#     
#     print "Random:"
#     printValues('C:\Users\dekelr\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Probing\Doplar\Ambiguity Domains\\1-5-2-3-2-unord\probeByRandom-6\ExpsByQueries.csv')