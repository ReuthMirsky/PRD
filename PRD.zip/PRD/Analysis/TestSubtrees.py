import xml.etree.ElementTree as ET
from defs.Tree import Tree
from defs.Sigma import Sigma
from defs.NT import NT
from defs.Probes import *
from defs.Explanation import Explanation

def parseTreeForExample(root, PL):
    children = root.getchildren()
    
    if root.tag[0] == "C":
        t = Tree("Basic", Sigma(root.tag, []), [], [], PL)
        t._isComplete=True
        return t

    else:
        tree = Tree("Complex", NT(root.tag, []), [], [], PL)
        isComplete=True
        for child in children:
            treeChild = parseTreeForExample(child, PL)
            if not treeChild.isComplete():
                isComplete=False
            tree._children.append(treeChild)

        tree._isComplete=isComplete
            
        return tree

def readExpFromFile():
    xmltree = ET.parse("C:\Users\Owner\Desktop\Subtree Example.xml")
    explanation = xmltree.getroot()
    children = explanation.getchildren()
    parsedExp=[]
    for child in children:
        parsedTree = parseTreeForExample(child, [])
        parsedExp.append(parsedTree)
#    parsedExp = [parseTreeFromXML_Doplar(explanation, PL)]
    return parsedExp

if __name__ == '__main__':
    parsedExp = readExpFromFile()
    
    matrix=[]
    i=0
    
#     print "TEST 1 - Does the example work?"
#     for tree in parsedExp:
#         matrix.append([])
#         for secondTree in parsedExp:
#             matrix[i].append(Refines(secondTree, tree))
#         
#         print matrix[i], "\n"
#         i+=1
#         
#     print "Test 2 - Does the 'create Subtrees' work?"
#     subtreesOfTree = rootSubTrees(parsedExp[4])
#     for tree in subtreesOfTree:
#         print tree
#         print Refines(parsedExp[4], tree)
#         print Match(parsedExp[4], tree)
#         print Match(tree, parsedExp[4])

#     print "Test 3 - Does the refine/match work?"
#     print parsedExp[2]
#     for tree in parsedExp:
#         print tree
#         print Refines(parsedExp[2], tree)
#         print Refines(tree, parsedExp[2])
#         print Match(parsedExp[2], tree)
#         print Match(tree, parsedExp[2])        
    
    print "Test 4 - Query the example"
    global subtrees
    global subtreesID
    exps = []

    #parsedExp = parsedExp[-4:]
    for tree in parsedExp:
        if tree.getID()>11:
            exps.append(Explanation([tree]))
        subtrees.append(tree)
    
    for tree in subtrees:
        subtreesID.append(tree.getID())
    
    createMatrices(exps)
    exps = query(exps, [], probeByEntropySub)
    
    print exps
    
    
    