import sys
import csv

def printValues(path):
    with open(path, 'rb') as csvfile:
        myFile = csv.reader(csvfile, delimiter=',', quotechar='|')
        instances = [[]]
        maxQueries=0
        prevRow=0
        i=0
        for row in myFile:
            if len(row)==1: #If this is the separator row that tells you how many queries were performed in total in this log
                if int(row[0])>maxQueries:  #Remember the maximum value of queries across all logs
                    maxQueries=int(row[0])
                i+=1
                instances.append([])
            else:
#                 if int(row[0])>prevRow:
#                     print prevRow
                instances[i].append(row)
                prevRow=int(row[0])
              
        instances=instances[:-1]    #This will contain a list of lists of pairs [[[14, 10], [10, 3]], [[17, 5], [5,2], ...]] each inner list is the pairs of decreases for a specific log 
        
        
        decreases=[]
        for instance in instances:
            percent = [0]
            original100 = int(instance[0][0])    #This is the number of hypotheses for this log before querying
            i=0
            for i in range(maxQueries):
                if i<len(instance):
                    query = instance[i]     #This is a single pair - # of hypotheses before and after a query is performed
                    before = int(query[0])
                    after = int(query[1])
                    reduction = 0.0+(before-after)
                    reductionInPercent = reduction/original100*100
                    percent.append(percent[i]+reductionInPercent)
                else:
                    percent.append(percent[i])
            decreases.append(percent[1:])
        
        steps=[]
        
        k=0
        matrix = open("C:\Users\dekelr\Desktop\percents.csv", "a+")
        for row in range(len(decreases)):
            if k!=12:
                k+=1
            else:
                print decreases[row]
                k+=1
            matrix.write(str(decreases[row])[1:-1]+"\n")
        matrix.close()
        

        for i in range(maxQueries):
            total=0
            steps.append(0)
            for j in range(len(decreases)):
                if len(decreases[j])>i:
                    steps[i]+=decreases[j][i]
                    total+=1
            steps[i]/=total
            steps[i]=100-steps[i]
            
        print steps
        for stepAverage in steps:
            print stepAverage 

if __name__ == '__main__':
#     print "Full Trees:"
#     printValues('C:\Users\Owner\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Probing\Doplar\IJCAI-1Goal\Entropy-3\ExpsByQueries-full.csv')
#     
#     print "**************"
#     
#     print "Subtrees:"
#     printValues('C:\Users\Owner\Desktop\ExpsByQueries - Copy.csv')
#

    print "Full inferred:"
    printValues('C:\\Users\\dekelr\\Dropbox (BGU)\\Reuth-new\\Online Plan Recognition\\Probing\\Doplar\\And-Or variances\\OR 1\\Full\\ExpsByQueries.csv')
#       
    print "Subs small:"
    printValues('C:\\Users\\dekelr\\Dropbox (BGU)\\Reuth-new\\Online Plan Recognition\\Probing\\Doplar\\And-Or variances\\OR 1\\Subtrees Small\\ExpsByQueries.csv')
#       
#     print "Mixed:"
#     printValues('C:\Users\Owner\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Probing\Doplar\Subtrees-1 Goal\Entropy - Mix7 E under 3\ExpsByQueries.csv')
       
    print "Subs big:"
    printValues('C:\\Users\\dekelr\\Dropbox (BGU)\\Reuth-new\\Online Plan Recognition\\Probing\\Doplar\\And-Or variances\\OR 1\\Subtrees Big\\ExpsByQueries.csv')
     
     
#     print "Entropy:"
#     printValues('C:\Users\Owner\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Probing\Doplar\Ambiguity Domains\\1-5-2-3-4-random\probeByEntropy-6\ExpsByQueries.csv')
#      
#     print "MPH:"
#     printValues('C:\Users\Owner\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Probing\Doplar\Ambiguity Domains\\1-5-2-3-4-random\probeByMostProbableExp-6\ExpsByQueries.csv')
#      
#     print "MPP:"
#     printValues('C:\Users\Owner\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Probing\Doplar\Ambiguity Domains\\1-5-2-3-4-random\probeByMostProbableTree-6\ExpsByQueries.csv')
#      
#     print "Random:"
#     printValues('C:\Users\Owner\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Probing\Doplar\Ambiguity Domains\\1-5-2-3-4-random\probeByRandom-6\ExpsByQueries.csv')
#      