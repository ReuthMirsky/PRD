from Queue import Queue
from copy import deepcopy 
from Explanation import Explanation
from Sigma import Letter, Sigma
from NT import NT
from Rule import Rule
from Tree import Tree
import random
from math import log
import sys
import xml.etree.ElementTree as ET
import time
import Algorithm
import itertools
import collections

#home
location = "Owner"
#office
#location = "dekelr"    

oldNumExps = 0;
oldNumTrees = 0;
queriesNumber = 0;

first = True
subtrees = []
subtreesID = []

expsByQueries = "C:\\Users\\"+location+"\\Desktop\\test2\\ExpsByQueries.csv" 
treesByQueries = "C:\\Users\\"+location+"\\Desktop\\test2\\TreesByQueries.csv" 
LargestEntropy = "C:\\Users\\"+location+"\\Desktop\\test2\\Entropy.csv"
queriesAsked = "C:\\Users\\"+location+"\\Desktop\\test2\\Queries.csv"

resultExps = ""
resultTrees = ""

treesMatrix={}

##############################################################################################################################
#                                            Basic Functions
##############################################################################################################################
def NormalizeProbabilities(exps):
    totalProbability = 0.0
    for exp in exps:
        totalProbability += exp.getExpProbability()
    
    for exp in exps:
        probability = exp.getExpProbability() / totalProbability
        exp.setExpProbability(probability)        

# Best is the set of trees to compare to
# other is the tree to compare
# Operator is either Refine/Match
def compareToBestExp(best, other, operator):   
    for tree in best:
        if operator(tree, other):
            return True
    return False

##############################################################################################################################
#                                            Refine / Match / Contain
##############################################################################################################################
###  MATCH OPERATOR ######        
def Match(this, other):
#   1. if this.name!=other.name
    if not other.getRoot().matchLetter(this.getRoot()):
        return False

#   2. if one of them is open
    if (not this.isComplete()) or (not other.isComplete()):
        return True 

#   3.      If p1 and p2 are basic actions return True - implicitly checked 
#   4.      If p1 and p2 are complex actions
    if len(other._children) == len(this._children):

    #   5. recursive check for children
        for childIndex in range(len(other._children)):
            if not Match(this._children[childIndex], other._children[childIndex]):
                return False
        return True
    
    elif len(other._children)==0 or len(this._children)==0:
        return True
    
    return False

###  Refine OPERATOR ######               
def Refines(this, other):      #"This" is the bigger tree and we want to know if it is a refinement of "other"   
    if not other.getRoot().matchLetter(this.getRoot()):
#         print "1"
        return False
    
    if type(this.getRoot().get())==Sigma:
#         print "2"
        return True 

    if other.isComplete() and not this.isComplete():
#         print "3"
        return False

#     if this.isComplete() and not other.isComplete():
#         print "4"
#         return True
         
    if len(other._children) > len(this._children):  #This is > because the smaller tree can have no children yet
#         print "4"
        return False
    
    for childIndex in range(len(other._children)):

        if not Refines(this._children[childIndex], other._children[childIndex]):
#                 print this
#                 print other
            return False
            
    return True

def Refines2(this, other):      #"This" is the bigger tree and we want to know if it is a refinement of "other"   
    if not other.getRoot().matchLetter(this.getRoot()):
        return False
    
    if type(this.getRoot().get())==Sigma:
        return True 

    if other.isComplete() and not this.isComplete():
        return False

#     if this.isComplete() and not other.isComplete():
#         print "4"
#         return True
         
    if len(other._children) > len(this._children):  #This is > because the smaller tree can have no children yet
        return False
    
    for childIndex in range(len(other._children)):

        if not Refines(this._children[childIndex], other._children[childIndex]):
            return False
            
    return True

###  Equals OPERATOR ######  
def Equals(this, other):
    return this==other

def readRefinesProbabilites(biggerTreeIndex, smallerTreeIndex):
    global treesMatrix
    
    return smallerTreeIndex in treesMatrix[biggerTreeIndex][0] 

def readContainsProbabilites(biggerTreeIndex, smallerTreeIndex):
    global treesMatrix
    
    return biggerTreeIndex in treesMatrix[smallerTreeIndex][0] 
    
def readMatchProbabilites(biggerTreeIndex, smallerTreeIndex):
    global treesMatrix
    
    return smallerTreeIndex in treesMatrix[biggerTreeIndex][1]

def createMatrices(exps):
    global subtrees
    global treesMatrix
    for biggerTree in subtrees:
        biggerTreeID = biggerTree.getID()
        treesMatrix[biggerTreeID] = ([biggerTreeID],[biggerTreeID]) #0 is contains, 1 is match
        for smallerTree in subtrees:
            smallerTreeID = smallerTree.getID()
            if smallerTreeID in treesMatrix[biggerTreeID]:
                continue
            else:
                if Refines(biggerTree, smallerTree):
                    treesMatrix[biggerTreeID][0].append(smallerTreeID)
                if Match(biggerTree, smallerTree):
                    treesMatrix[biggerTreeID][1].append(smallerTreeID)                          
    
    return

# Tree is the tree to get probability of
# Exps is the set of all explanations
# Operator is either readRefinesProbabilites/readContainesProbabilites/readMatchProbabilites
def GetProbability(tree, exps, operator):
    probabilityWithTree = 0.0
    probabilityWithoutTree = 0.0
    expsWith = 0
    expsWithout = 0
    for exp in exps:
        contains = False
        for biggerTree in exp.getTrees():
            if operator(biggerTree.getID(), tree.getID()):
                contains = True
                break
        if contains:
            probabilityWithTree += exp.getExpProbability()
            expsWith += 1
        else:
            probabilityWithoutTree += exp.getExpProbability()
            expsWithout += 1
    
    treeProbability = probabilityWithTree / (probabilityWithTree+probabilityWithoutTree)
    #print tree.getID(), ": ", probabilityWithTree, "(", expsWith, "), ", probabilityWithoutTree,"(", expsWithout, "),", treeProbability
    return treeProbability

##############################################################################################################################
#                                            Probe Strategies
##############################################################################################################################

###  MPT  ######    
def probeByMostProbableTree(exps=[], askedAbout=[]):
    IDsAndProbs = {}
    IDsAndTrees = {}
    treesOrderedByProbability = {}
   
    #Calculate the probabilities of the remaining trees
    for exp in exps:
        for tree in exp.getTrees():
            if tree.getID() not in IDsAndProbs.keys():
                IDsAndProbs[tree.getID()] = GetProbability(tree, exps, readRefinesProbabilites) 
                IDsAndTrees[tree.getID()] = tree
                if IDsAndProbs[tree.getID()] not in treesOrderedByProbability.keys():
                    treesOrderedByProbability[IDsAndProbs[tree.getID()]] = [tree.getID()]
                else:
                    treesOrderedByProbability[IDsAndProbs[tree.getID()]].append(tree.getID())
    
    #Remove Trees already asked about
    probabilityToSearch = 0
    treeIDToProb = -1
    while 0==probabilityToSearch or (treeIDToProb in askedAbout):
        if probabilityToSearch!=0:
            treesOrderedByProbability[probabilityToSearch].pop()
            if 0==len(treesOrderedByProbability[probabilityToSearch]):
                del treesOrderedByProbability[probabilityToSearch]

        if len(treesOrderedByProbability)==0:
            return [-1, []]     #Meaning all trees were queried about once
        
        probabilityToSearch = max(treesOrderedByProbability.keys())
        treeIDToProb = treesOrderedByProbability[probabilityToSearch][-1]
        treeToProbeFor = IDsAndTrees[treeIDToProb]
    
    #Ask about this tree
    askedAbout.append(treeIDToProb) 
    #print "Number of trees: ", len(IDsAndProbs.keys())
    return [treeToProbeFor, askedAbout]

###  MPT-Sub  ######    
def probeByMostProbableTreeSub(exps=[], askedAbout=[]):
    global subtrees
    global subtreesID
    
    if len(subtrees)==0:
            return [-1, []]     #Meaning all trees were queried about once
        
    treeByProbability={}
    for tree in set(subtrees):
        treeProb = GetProbability(tree, exps, readRefinesProbabilites) 
        if treeProb in treeByProbability.keys():
            treeByProbability[treeProb].append(tree)
        else:
            treeByProbability[treeProb]=[tree]
    
    bestProbability = max(treeByProbability.keys())
    treeToProbeFor = treeByProbability[bestProbability][0]
    treeIDToProb = treeToProbeFor.getID()
    #subtrees = filter(lambda a: a.getID() != treeIDToProb, subtrees)
    #subtreesID = filter(lambda a: a != treeIDToProb, subtreesID)
    print "Number of subtrees: ", len(subtrees)
    #subtrees.remove(treeToProbeFor)
    #subtreesID.remove(subtreesID)
    askedAbout.append(treeToProbeFor)

    return [treeToProbeFor, askedAbout]

###  MPE  ######    
def probeByMostProbableExp(exps=[], askedAbout=[]):
    expsByProbability= {}
    trees = []

    # Collect explanations by probability            
    for exp in exps:
        for tree in exp.getTrees():
            if tree.getID() not in trees:
                trees.append(tree.getID())
        expProb = exp.getExpProbability()
        if expProb not in expsByProbability.keys():
            expsByProbability[expProb] = [exp]
        else:
            expsByProbability[expProb].append(exp)
    
       
    #Remove Trees already asked about
    probabilityToSearch = 0
    treeIDToProb = -1

    while 0==probabilityToSearch or (treeIDToProb in askedAbout):
        if probabilityToSearch!=0:
            expsByProbability[probabilityToSearch].pop(len(expsByProbability[probabilityToSearch])-1)
            if 0==len(expsByProbability[probabilityToSearch]):
                del expsByProbability[probabilityToSearch]

        if len(expsByProbability)==0:
            return [-1, []]     #Meaning all trees were queried about once
        
        
        probabilityToSearch = max(expsByProbability.keys())
        i = 0 
        while i==0 or i<len(expsByProbability[probabilityToSearch][len(expsByProbability[probabilityToSearch])-1].getTrees()):
            treeToProbeFor = expsByProbability[probabilityToSearch][len(expsByProbability[probabilityToSearch])-1].getTrees()[i]
            treeIDToProb = treeToProbeFor.getID()    
            if (treeIDToProb not in askedAbout):
                break
            i+=1
        
    #Ask about this tree
    askedAbout.append(treeIDToProb) 
    #print "Number of trees: ", len(trees)
    return [treeToProbeFor, askedAbout]    
  
###  Entropy  ######      
def probeByEntropy(exps=[], askedAbout=[]):
    treeIDtoTree = {}
    
    for exp in exps:
        for tree in exp.getTrees():
            treeID = tree.getID()
            if treeID not in treeIDtoTree:  #If this is the first time we see this tree
                treeIDtoTree[treeID] = tree              

    #Collect probabilities of all explanations remaining in the system with and without tree
    informationGainPerTree = {}
    
    for treeID in treeIDtoTree.keys():
        entropyWithTree=0
        entropyWithoutTree=0
        
        #Calculate Ent(phi(H, t, True)) and Ent(phi(H, t, False))
        for exp in exps:
            refines = False
            for bigTree in exp.getTrees():
                if readRefinesProbabilites(bigTree.getID(), treeID):
                    expProb=exp.getExpProbability()
                    entropyWithTree-=(expProb * log(expProb,2))
                    refines = True
                    break
                if readMatchProbabilites(bigTree.getID(), treeID):
                    expProb=exp.getExpProbability()
                    entropyWithTree-=(expProb * log(expProb,2))
                    break
            if not refines:
                expProb=exp.getExpProbability()
                entropyWithoutTree-=(expProb * log(expProb,2))
        
        #Calculate Information Gain    
        tree = treeIDtoTree[treeID]
        treeProbabilityR = GetProbability(tree, exps, readRefinesProbabilites)
        treeProbabilityM = GetProbability(tree, exps, readMatchProbabilites)
        informationGain = treeProbabilityM*entropyWithTree + (1-treeProbabilityR)*entropyWithoutTree
        
        if informationGain in informationGainPerTree:
            informationGainPerTree[informationGain].append(treeID) 
        else:
            informationGainPerTree[informationGain] = [treeID]


        #print tree.reprWithParams()
        #print informationGain, ":", treeProbabilityM, "*", entropyWithTree, "+ (1-", treeProbabilityR, ")*", entropyWithoutTree 
        

    treeIDToProb = 0
    #Remove Trees already asked about
    while 0==treeIDToProb or (treeIDToProb in askedAbout):
        if treeIDToProb!=0:
            minEntropy = min(informationGainPerTree.keys())
            informationGainPerTree[minEntropy].remove(treeIDToProb)
            if 0==len(informationGainPerTree[minEntropy]):
                del informationGainPerTree[minEntropy]

        if len(informationGainPerTree)==0:
            return [-1, []]     #Meaning all trees were queried about once
        
        minEntropy = min(informationGainPerTree.keys())
        print "minEntropy=", minEntropy
        treeIDToProb = informationGainPerTree[minEntropy][0]
        treeToProbeFor = treeIDtoTree[treeIDToProb] 
    
    #Ask about this tree
    askedAbout.append(treeIDToProb) 
    #print "Number of trees: ", len(treeIDtoTree.keys())
    return [treeToProbeFor, askedAbout]
    
    
###  Entropy-Sub  ######   
lastEntropy=0 
lastEntropyDiff=0  
def probeByEntropySub(exps=[], askedAbout=[]):
    global lastEntropy
    global lastEntropyDiff
    global subtrees
    global subtreesID
    
#     print "len subtrees=", len(subtrees)
#     print "len subtreesIDs=", len(subtreesID)
#     print "subtreesIDs=", subtreesID 
    
    treeIDtoTree = {}
    
    for subtree in subtrees:
        treeID = subtree.getID()
        #print treeID
        if treeID not in treeIDtoTree:  #If this is the first time we see this tree
            treeIDtoTree[treeID] = subtree              

    #Collect probabilities of all explanations remaining in the system with and without tree
    informationGainPerTree = {}
    
    for treeID in treeIDtoTree.keys():
        entropyWithTree=0
        entropyWithoutTree=0
        
        #Calculate Ent(phi(H, t, True)) and Ent(phi(H, t, False))
        for exp in exps:
            refines = False
            for bigTree in exp.getTrees():
                if readRefinesProbabilites(bigTree.getID(), treeID):
                    expProb=exp.getExpProbability()
                    entropyWithTree-=(expProb * log(expProb,2))
                    refines = True
                    break
#                 elif treeID==11:
#                     print bigTree.getID()
                    
                if readMatchProbabilites(bigTree.getID(), treeID):
                    expProb=exp.getExpProbability()
                    entropyWithTree-=(expProb * log(expProb,2))
                    break
            if not refines:
                expProb=exp.getExpProbability()
                entropyWithoutTree-=(expProb * log(expProb,2))
        
        #Calculate Information Gain    
        tree = treeIDtoTree[treeID]
        treeProbabilityR = GetProbability(tree, exps, readRefinesProbabilites)
        treeProbabilityM = GetProbability(tree, exps, readMatchProbabilites)
        informationGain = treeProbabilityM*entropyWithTree + (1-treeProbabilityR)*entropyWithoutTree
        
        #print "tree=", tree.getID(), ": ", "P_r=", treeProbabilityR, ", P_m=", treeProbabilityM, ", E_w=", entropyWithTree, ", E_w/o=", entropyWithoutTree
        
        if informationGain in informationGainPerTree:
            informationGainPerTree[informationGain].append(treeID) 
        else:
            informationGainPerTree[informationGain] = [treeID]


        #print tree.reprWithParams()
        #print informationGain, ":", treeProbabilityM, "*", entropyWithTree, "+ (1-", treeProbabilityR, ")*", entropyWithoutTree 
        

    treeIDToProb = 0
    treeToProbeFor = None
    #Remove Trees already asked about
    informationGainPerTree = collections.OrderedDict(sorted(informationGainPerTree.items()))
    while 0==treeIDToProb or len(informationGainPerTree)!=0:
        if treeIDToProb!=0:
            minEntropy = min(informationGainPerTree.keys())
            informationGainPerTree[minEntropy].remove(treeIDToProb)
            if 0==len(informationGainPerTree[minEntropy]):
                del informationGainPerTree[minEntropy]

        if len(informationGainPerTree)==0:
            return [-1, []]     #Meaning all trees were queried about once
        
        
        minEntropy = min(informationGainPerTree.keys())
        #print informationGainPerTree
        possibleTreeIDs = informationGainPerTree[minEntropy]
        possibleTrees=[]
        for treeID in possibleTreeIDs:
            possibleTrees.append(treeIDtoTree[treeID])
        possibleTrees = sorted(possibleTrees, key=Tree.getDepth)
#         print possibleTrees
#         treeIDToProb = informationGainPerTree[minEntropy][0]
#         treeToProbeFor = treeIDtoTree[treeIDToProb] 
        treeToProbeFor = possibleTrees[-1]
#         treeIDToProb= treeToProbeFor.getID()
        #maxEntropy = max(informationGainPerTree.keys())
        lastEntropyDiff=lastEntropy-minEntropy
        lastEntropy=minEntropy
        fileEntropy = open(LargestEntropy, 'a+')
        fileEntropy.write(str(lastEntropy).replace(",",".")+",")
        fileEntropy.close()
#        treeIDToProb = informationGainPerTree[minEntropy][0]
#        treeToProbeFor = treeIDtoTree[treeIDToProb] 
    
        #Ask about this tree
        #askedAbout.append(treeIDToProb)
        #subtreesID.remove(treeIDToProb)
        #subtrees.remove(treeToProbeFor) 
        #print "Number of trees: ", len(treeIDtoTree.keys())
        return [treeToProbeFor, askedAbout]

###  Entropy-Mixed ######      
count=1
def probeByEntropyMix(exps=[], askedAbout=[]):
    global lastEntropy
    global lastEntropyDiff
    global count
    if lastEntropy<=3:
        return probeByEntropy(exps, askedAbout)
    else:
        count+=1
        [treeToProbeFor, askedAbout] = probeByEntropySub(exps, askedAbout)
        if treeToProbeFor!=-1:
            askedAbout.append(treeToProbeFor.getID())
        return [treeToProbeFor, askedAbout]
    
###  Random  ######        
def probeByRandom(exps=[], askedAbout=[]):
    trees = []
    IDs = []
        
    for exp in exps:
        for tree in exp.getTrees():
            if tree.getID() not in IDs:
                trees.append(tree)
                IDs.append(tree.getID())
    
    #Remove Trees already asked about
    treeIDToProb = 0
    treeToProbeFor = None
    while 0==treeIDToProb or (treeIDToProb in askedAbout):
        if treeIDToProb!=0:
            IDs.remove(treeIDToProb)
            trees.remove(treeToProbeFor)
        if len(IDs)==0:
            return [-1, []]     #Meaning all trees were queried about once
        
        #Find Tree by random 
        treeToProbeFor = random.choice(trees)
        treeIDToProb = treeToProbeFor.getID()
        
    #Ask about this tree
    askedAbout.append(treeIDToProb) 
    #print "Number of trees: ", len(trees)
    return [treeToProbeFor, askedAbout]

###  Random-Sub  ######        
def probeByRandomSub(exps=[], askedAbout=[]):
    global subtrees
    global subtreesID
    
    if len(subtreesID)==0:
        return [-1, []]     #Meaning all trees were queried about once
        
    #Find Tree by random 
    treeToProbeFor = random.choice(subtrees)
    print "subtrees.count=", subtrees.count(treeToProbeFor)
    treeIDToProb = treeToProbeFor.getID()
    subtrees = filter(lambda a: a.getID() != treeIDToProb, subtrees)
    subtreesID = filter(lambda a: a != treeIDToProb, subtreesID)
    askedAbout.append(treeToProbeFor)
    
    #Ask about this tree
    #askedAbout.append(treeIDToProb) 
    print "Number of subtrees: ", len(subtrees)
    return [treeToProbeFor, askedAbout]

##############################################################################################################################
#                                            Query Function
##############################################################################################################################
def allSubTrees(existingSubtrees, newTree):
    if newTree not in existingSubtrees:
        existingSubtrees.append(newTree)
    for child in newTree._children:
        allSubTrees(existingSubtrees, child)
    
def rootSubTrees(tree, setOfPrevious=[]):
    #print "tree depth=", tree.getDepth()
    if tree.getDepth()==1:
        #print tree
        return [tree.myCopy()]
    childrenOptions=[[]]
    for child in tree._children:
        child.setID()
        #print "child=", child
        singleChildOptions = rootSubTrees(child.myCopy())
        childrenOptionsWithCurrentChild = []
        for olderChildrenOption in childrenOptions:
            #childrenOptionsWithCurrentChild.append(olderChildrenOption)
            for option in singleChildOptions:
                newOption = option.myCopy()
                newOption.setID()
                newOlderChildrenOption = []
                for childTree in olderChildrenOption:
                    newChildTree = childTree.myCopy()
                    newChildTree.setID()
                    newOlderChildrenOption.append(newChildTree)
                newOlderChildrenOption.append(newOption)
                childrenOptionsWithCurrentChild.append(newOlderChildrenOption)
                #childrenOptionsWithCurrentChild.append(option.myCopy())
        childrenOptions.extend(childrenOptionsWithCurrentChild)
    toReturnList=[]
    for option in childrenOptions:
        newTree = tree.myCopy()
        newTree.setID()
        newTree._children = option
        if option==[]:
            newTree._isComplete=False
        for child in newTree._children:
            if not child._isComplete:
                newTree._isComplete=False
        if len(newTree._children)==0 or len(newTree._children)==len(tree._children):
            toReturnList.append(newTree)
    return list(set(toReturnList))
            
        
def getFirstTree(imitator, trees):
    for tree in trees:
        if tree==imitator:
            return tree.getID()
    return -1
      
def query(exps=[], askedAbout=[], probingStrategy=probeByRandom):
    global first
    global subtrees
    global subtreesID
    
    #print "------------ Explanations at this Point --------------"
    #print exps

    #createMatrices(exp) - should be performed higher in hierarchy, because this is not needed to be calculated every query

    NormalizeProbabilities(exps)
    bestExp = readBestExpFromFile_TP(exps[0].getTrees()[0]._PL)#readBestExpFromFile_VL(exps[0].getTrees()[0]._PL)#readBestExpFromFile_Doplar(exps[0].getTrees()[0]._PL) 
   
    [treeToProbeFor, newAskedAbout] = probingStrategy(exps, askedAbout)


    global oldNumExps, oldNumTrees, resultExps, resultTrees, queriesNumber
    queriesNumber+=1

    if oldNumExps!=0:
        resultExps+=str(oldNumExps)+","+str(len(exps))+"\n"
    oldNumExps=len(exps)
             
    if oldNumTrees!=0:
        resultTrees+=str(oldNumTrees)+","+str(len(subtrees))+"\n"
    oldNumTrees=len(subtrees)
    
    if treeToProbeFor == -1:
        print "------------------ Cannot Discard Any More Hypotheses -------------------"
        
        file1 = open(expsByQueries, 'a+')
        file2 = open(treesByQueries, 'a+')
        file3 = open(queriesAsked, 'a+')
        fileEntropy = open(LargestEntropy, 'a+')
        resultExps += str(resultExps.count("\n"))+"\n"
        resultTrees += str(resultTrees.count("\n"))+"\n"
        file1.write(resultExps)
        file2.write(resultTrees)
        fileEntropy.write("\n")
        file3.write(sys.argv[2]+","+sys.argv[1]+","+str(queriesNumber-1)+"\n")
        file1.close()
        file2.close()
        fileEntropy.close()
        
        return exps    
   
    newAskedAbout.append(treeToProbeFor.getID())
   
    if first:
        resFile= open("C:\\Users\\Owner\\Desktop\\test2\\"+sys.argv[2]+"-"+sys.argv[1]+".xml", 'a+')
        resFile.write(treeToProbeFor)
        #resFile.write(reprInTPForm(treeToProbeFor)[0])
        resFile.close()
        first=False
        
    print "Is this part of your plan?"
    print treeToProbeFor
    #print reprInTPForm(treeToProbeFor)[0] #treeToProbeFor.reprWithParams()
    
    print "Best is:"
    for tree in bestExp:
        print tree.reprWithParams()
    
    ### See if the treeToProbeFor can be refined to one of the trees in "best"
    isPart = compareToBestExp(bestExp, treeToProbeFor, Refines)
    print isPart
        
    newExps = []
    toRemove=[]
    
    ### QA(p)=True, we need to keep all hypotheses with p' s.t. p ~m p'
    if isPart:
        for exp in exps:
            for tree in exp.getTrees():
                if Match(tree, treeToProbeFor):
                    newExps.append(exp)
                    break
        
        for subtree in subtrees:
            if Refines(treeToProbeFor, subtree):
                #subtrees.remove(subtree)
                toRemove.append(subtree)
    ### QA(p)=False, we need to keep all hypotheses with no p' s.t. p ~r p'      
    else:
        for exp in exps:
            toPut=True
            for tree in exp.getTrees():
#                 if treeToProbeFor.getID()==14857 and tree.getID()==14857:
#                     print "14857", Refines(tree, treeToProbeFor)
#                     print tree.reprWithParams()
#                     print treeToProbeFor.reprWithParams()
                if Refines(tree, treeToProbeFor):
                    toPut=False
                    break
    
            if toPut:
                newExps.append(exp)
        for subtree in subtrees:
            if Refines(subtree, treeToProbeFor):
                toRemove.append(subtree)

    ###  Inferred Queries    
    for treeToRemove in toRemove:
        subtrees.remove(treeToRemove)
        subtreesID.remove(treeToRemove.getID())

    ###  Uninferred Queries
    if treeToProbeFor.getID() is subtreesID: 
        subtrees.remove(treeToProbeFor)
        subtreesID.remove(treeToProbeFor.getID())


#     print "___________________"
#     print newExps
#     print "___________________"
           
    ### Do we need to perform another query? 
    if 1==len(newExps):
        print "------------------ The Final Explanation is: -------------------"
        print newExps[0]
        file1 = open(expsByQueries, 'a+')
        file2 = open(treesByQueries, 'a+')
        file3 = open(queriesAsked, 'a+')
        fileEntropy = open(LargestEntropy, 'a+')
        resultExps+=str(oldNumExps)+",1\n"
        resultTrees+=str(oldNumExps)+","+str(len(newExps[0].getTrees()))+"\n"   
        resultExps += str(resultExps.count("\n"))+"\n"
        resultTrees += str(resultTrees.count("\n"))+"\n"     
        file1.write(resultExps)
        file2.write(resultTrees)
        file3.write(sys.argv[2]+","+sys.argv[1]+","+str(queriesNumber)+"\n")
        fileEntropy.write("\n")
        file1.close()
        file2.close()
        file3.close()
        fileEntropy.close()
        return newExps
    
    elif 1<len(newExps):
        return query(newExps, newAskedAbout, probingStrategy)
            
    else:
        print "------------------ No Explanation Fits the Probing ------------------"
        return []    
    
    