from PL import PL
from Tree import Tree
from Sigma import Sigma, Letter
from NT import NT
from Rule import Rule
from SearchNode import Node
from SoccerDomain import initPL
#from defs import SoccerDomain
from collections import deque
import itertools
import sys
import time
from Probes import Refines, Match
import profile
from sets import Set
from copy import deepcopy
import random

dummy=0
maxLeaves=0

def checkDistinctivenessDummy(open):
    global dummy
    if dummy==3:
        return True
    else:
        dummy+=1
        return False
#                 
# def createPermutationsNoInterleaving(obsPerChild, rule):
#     print obsPerChild
#     if len(rule._order)==0:
#         allPerm =  itertools.permutations(obsPerChild)
#         allObs = []
#         for permutation in allPerm:
#             print permutation
#             newSequence = ""
#             for token in permutation:
#                 if token==[-1]:
#                     continue
#                 newSequence += token
#             allObs.append(newSequence)
#         return allObs
#     else:
#         if checkDistinctivenessDummy([]):
#             return ["a"]
#         else:
#             return ["b"] 
    
# def canExplain(node, sequence): 
#     if len(sequence)==1:
#         return True
#     rule = node._rule
#     #This means this node is not yet expanded
#     if rule==[]:
#         return True
#     if rule==():
#         return False
#     #orderingConstraints=node._rule._order
#     leavesLen = [0]
#     for child in node._children:
#         leavesLen.append(leavesLen[-1]+len(getLeaves(child)))
#     i=0
#     print leavesLen
#     while i+1<len(leavesLen):
#         if not canExplain(node._children[i], sequence[leavesLen[i]:leavesLen[i+1]]):
#             print "cannot explain"
#             return False
#         i+=1
#     return True
     
def getLeaves(node):
    if node._actionType=="Basic":
        return [node.getRoot()._ch]
    
    if len(node._children)==0:
        return []
    res=[]
    for child in node._children:
        #childSequences = getLeaves(child)
        res.extend(getLeaves(child))
    return res   
    
def getObservations(node):
    global maxLeaves
    basicSequence = getLeaves(node)
    return basicSequence
#     allSequences = itertools.permutations(basicSequence)
#     allPossibleSequences = []
#     for sequence in allSequences:
#         if sequence!=():
#             if canExplain(node, sequence):
#                 allPossibleSequences.append(sequence)
#     return allPossibleSequences 
        

def allGoalsReachables(removedRules):
    global reachables
    for goal in reachables.keys():
        goalIsReachable = False
        for path in reachables[goal]:
            pathIsReachable = True 
            for rule in removedRules:
                if rule in path:
                    pathIsReachable = False
                    break
            if pathIsReachable:
                goalIsReachable = True
                continue
        if goalIsReachable:
            continue
        else:
            return False
            
    return True


def checkPlanDistinctiveness2(open):
    global maxLeavesWcpd
    global basicPL
    plans = {}
    goals = []
    answer=False
    plGoals = basicPL._R
    
    for node in open:

        plan = node.getTree()#.getRoot()._ch
        if not plans.has_key(plan):
            plans[plan]=[]
        #Else - no need to add the key, can just extend the existing list
        observations = node.getObservations()
        #This means that there are no observable actions yet
        if len(observations)==0:
            continue
        
        if plan.getRoot()._ch not in goals:
            goals.append(node.getTree().getRoot()._ch)
        
        plans[plan].append(observations)
    
    if len(plGoals)!=len(goals):
        return False    

    answer=True   
    #print len(plans.keys()) 
    
    for plan in plans.keys():
        if len(plans[plan])==0:
            return False
        for sequence in plans[plan]:
            if len(sequence)<maxLeavesWcpd:
                continue
            if len(sequence)==maxLeavesWcpd and answer==False:
#                 print "len(",sequence,")=",len(sequence),", maxleaves=",maxLeavesWcpd," and answer is False"
                continue
            for plan2 in plans.keys():
                if plan2!=plan:
                    for sequence2 in plans[plan2]:
                        if contains(sequence2, sequence) or contains(sequence, sequence2):# and not Match(plan, plan2):
                            #if plan2.getRoot()._ch!= plan.getRoot()._ch:
                                #print plan.getRoot()._ch, plan2.getRoot()._ch
                                #print sequence, " / ", sequence2
                            #print "here", answer
#                             print sequence, "---", sequence2, maxLeavesWcpd
                            minLen = min(len(sequence), len(sequence2))
                            if maxLeavesWcpd<=minLen:
                                maxLeavesWcpd=minLen
                                #print plan2, ", ", plan
                                #print sequence2, "<", sequence
                                answer=False
    return answer     

def checkPlanDistinctiveness(openL):
    global maxLeavesWcpd
    global basicPL
    global plansComparedWcpd
    
    plansComparedWcpd=0
    plans = {}
    goals = []
    plGoals = basicPL._R
    
    for node in openL:

        plan = node.getTree()#.getRoot()._ch
        if not plans.has_key(plan):
            plans[plan]=[]
        #Else - no need to add the key, can just extend the existing list
        observations = node.getObservations()
        #This means that there are no observable actions yet
        if len(observations)==0:
            continue
        
        if node.getTree().getRoot()._ch not in goals:
            goals.append(node.getTree().getRoot()._ch)
        
        if observations not in plans[plan]:
            plans[plan].append(observations)
    
    if len(plGoals)!=len(goals):
        return False    

    answer=True    
    planNum=0
    iPlans=0
    iSequences=0
    
    for plan1 in plans.keys():
        planNum+=1
        if len(plans[plan1])==0:
            return False
        for sequence in plans[plan1]:
#             if len(sequence)<maxLeavesWcpd:
#                 #print "len(",sequence,")=",len(sequence),", maxleaves=",maxLeaves
#                 continue
#             if len(sequence)==maxLeavesWcpd and answer==False:
#                 continue
            for plan2 in plans.keys()[planNum:]:
                iPlans+=1
                if plan2!=plan1:
                    plansComparedWcpd+=1
                    for sequence2 in plans[plan2]:
                        iSequences+=1
                        containsForReduction1=containsForReduction(sequence2, sequence)
                        containsForReduction2=containsForReduction(sequence, sequence2)
                        if containsForReduction1>maxLeaves or containsForReduction2>maxLeaves:
                            minLen = min(containsForReduction1, containsForReduction2)
#                        #Reminder: This simple condition does not fit here - causes Soccer's wcpd become 2 instead of 3
#                         if contains(sequence, sequence2) or contains(sequence2, sequence):
#                             minLen = min(len(sequence), len(sequence2))                            
                            if maxLeavesWcpd<=minLen:
#                                 print plan2, ", ", plan1
#                                 if maxLeavesWcpd<minLen:    
#                                     print plan2.getRoot().get(), plan1.getRoot().get()
#                                     print sequence2, "<", sequence
                                maxLeavesWcpd=minLen
                                answer=False    
    #print "wcpd distinctiveness loops: plans=", iPlans, "sequences=", iSequences
    return answer 

def checkDistinctiveness(openL):
    global maxLeavesWcd
    global basicPL
    global plansComparedWcd
    
    plansComparedWcd=0
    
    plans = {}
    goals = []
    plGoals = basicPL._R
       
    for node in openL:

        plan = node.getTree()#.getRoot()._ch
        if not plans.has_key(plan.getRoot()._ch):
            plans[plan.getRoot()._ch]=[]
        #Else - no need to add the key, can just extend the existing list
        observations = node.getObservations()
        #This means that there are no observable actions yet
        if len(observations)==0:
            continue
        
        if node.getTree().getRoot()._ch not in goals:
            goals.append(node.getTree().getRoot()._ch)
        
        if observations not in plans[plan.getRoot()._ch]:
            plans[plan.getRoot()._ch].append(observations)

    
    if len(plGoals)!=len(goals):
        return False    

    answer=True    
    planNum=0
    iPlans=0
    iSequences=0
    
    for plan1 in plans.keys():
        planNum+=1
        if len(plans[plan1])==0:        
            return False
        for sequence in plans[plan1]:
#             if len(sequence)<maxLeavesWcd:
#                 continue
#             if len(sequence)==maxLeavesWcd and answer==False:
#                 continue
            for plan2 in plans.keys()[planNum:]:
                iPlans+=1
                if plan2!=plan1:
                    plansComparedWcd+=1
                    for sequence2 in plans[plan2]:
                        iSequences+=1
                        containsForReduction1=containsForReduction(sequence2, sequence)
                        containsForReduction2=containsForReduction(sequence, sequence2)
                        if containsForReduction1>maxLeavesWcd or containsForReduction2>maxLeavesWcd:
                            minLen = min(containsForReduction1, containsForReduction2)
#                        #Reminder: This simple condition does not fit here - causes Soccer's wcpd become 2 instead of 3
#                         if contains(sequence2, sequence) or contains(sequence, sequence2):
#                             minLen = min(len(sequence), len(sequence2))                            
                            if maxLeavesWcd<=minLen:
                                maxLeavesWcd=minLen
                                answer=False   
    #print "wcd distinctiveness loops: plans=", iPlans, "sequences=", iSequences
    return answer         

def checkDistinctivenessForReduction(openL, returnWitnesses=False):
    global basicPL
    global DebugFlag
    
    maxLeavesWcd=0
    plans = {}
    goals = []
    plGoals = basicPL._R
      
    for node in openL:

        plan = node.getTree()#.getRoot()._ch
        if not plans.has_key(plan.getRoot()._ch):
            plans[plan.getRoot()._ch]=[]
        #Else - no need to add the key, can just extend the existing list
        observations = node.getObservations()
        #This means that there are no observable actions yet
        if len(observations)==0:
            continue
        
        if node.getTree().getRoot()._ch not in goals:
            goals.append(node.getTree().getRoot()._ch)
        
        if observations not in plans[plan.getRoot()._ch]:
            plans[plan.getRoot()._ch].append((observations,node))
        
    if len(plGoals)!=len(goals):
        return -1 if not returnWitnesses else (-1, -1)

    answer=True    
    planNum=0
    iPlans=0
    iSequences=0
    witnessPlans=[]
    
    for plan1 in plans.keys():
        planNum+=1
        for sequence, node in plans[plan1]:
#             if len(sequence)<maxLeavesWcd:
#                 continue
#             if len(sequence)==maxLeavesWcd and answer==False:
#                 continue
            for plan2 in plans.keys()[planNum:]:
                iPlans+=1
                if plan2!=plan1:
                    for sequence2, node2 in plans[plan2]:
                        iSequences+=1
                        containsForReduction1=containsForReduction(sequence2, sequence)
                        containsForReduction2=containsForReduction(sequence, sequence2)
                        if containsForReduction1>maxLeavesWcd or containsForReduction2>maxLeavesWcd:
                            minLen = min(containsForReduction1, containsForReduction2)
#                         if contains(sequence2, sequence) or contains(sequence, sequence2):
#                             minLen = min(len(sequence), len(sequence2))                 
                            if maxLeavesWcd<=minLen:
#                                 print plan2, ", ", plan1
#                                 print sequence2, "<", sequence
                                maxLeavesWcd=minLen
                                witnessPlans=[node]
                                witnessPlans.append(node2)
#                                 if maxLeavesWcd==2 and DebugFlag:
#                                     print plan2, ", ", plan1
#                                     print sequence2, "<", sequence 
    #print "wcd distinctiveness loops: plans=", iPlans, "sequences=", iSequences
    return maxLeavesWcd if not returnWitnesses else (maxLeavesWcd, witnessPlans)  

def checkPlanDistinctivenessForReduction(openL, returnWitnesses=False):
    global basicPL
    plans = {}
    goals = []
    plGoals = basicPL._R
    maxLeavesWcpd=0
    

    for node in openL:

        plan = node.getTree()#.getRoot()._ch
        if not plans.has_key(plan):
            plans[plan]=[]
        #Else - no need to add the key, can just extend the existing list
        observations = node.getObservations()
        #This means that there are no observable actions yet
        if len(observations)==0:
            continue
        
        if node.getTree().getRoot()._ch not in goals:
            goals.append(node.getTree().getRoot()._ch)
                    
        plans[plan].append((observations,node))
    
    if len(plGoals)!=len(goals):
        return -1 if not returnWitnesses else (-1, -1)    

    answer=True    
    planNum=0
    iPlans=0
    iSequences=0
    witnessPlans=[]
   
    for plan1 in plans.keys():
        planNum+=1
        if len(plans[plan1])==0:
            return False
        for sequence, node in plans[plan1]:
            if len(sequence)<maxLeavesWcpd:
                #print "len(",sequence,")=",len(sequence),", maxleaves=",maxLeaves
                continue
            if len(sequence)==maxLeavesWcpd and answer==False:
                #informationFile.write("len("+str(sequence)+")="+str(len(sequence))+", maxleaves="+str(maxLeavesWcpd)+" and answer is False\n")
                continue
            for plan2 in plans.keys()[planNum:]:
                iPlans+=1
                if not plan2==plan1:
                    if Refines(plan1, plan2) or Refines(plan2, plan1):
                        continue
                    for sequence2, node2 in plans[plan2]: 
                        iSequences+=1
                        containsForReduction1=containsForReduction(sequence2, sequence)
                        containsForReduction2=containsForReduction(sequence, sequence2)
                        if containsForReduction1>maxLeavesWcpd or containsForReduction2>maxLeavesWcpd:
                            minLen = min(containsForReduction1, containsForReduction2)    
#                         if contains(sequence2, sequence) or contains(sequence, sequence2):
#                             minLen = min(len(sequence), len(sequence2))                        
#                             if minLen>2:
#                                 print plan1.getRoot()._ch, plan2.getRoot()._ch
#                                 print containsForReduction(sequence2, sequence, True)
#                                 print containsForReduction(sequence, sequence2, True)
#                                 print sequence, " / ", sequence2
                            #print "here", answer
                            if maxLeavesWcpd<=minLen:
#                                 print plan2, ", ", plan1
#                                 print sequence2, "<", sequence
                                maxLeavesWcpd=minLen
                                witnessPlans=[node]        #                                 if maxLeavesWcpd==4:
                                witnessPlans.append(node2)
#                                 if maxLeavesWcpd==4:
#                                     print plan2, ", ", plan1
#                                     print sequence2, "<", sequence 
    #print "wcpd distinctiveness loops: plans=", iPlans, "sequences=", iSequences
    return maxLeavesWcpd if not returnWitnesses else (maxLeavesWcpd, witnessPlans)      
     
    
def contains(small, big, test=False):
    for i in range(min([len(small),len(big)])):
#         if test==True:
#             print "\t \t \t", small[i],big[i]
        if small[i]._ch!=big[i]._ch:
            return False
    return True      


def containsForReduction(small, big, test=False):
    for i in range(min([len(small),len(big)])):
        if test==True:
            print "\t \t \t", small[i],big[i]
        if small[i]._ch!=big[i]._ch:
            return i
    return min([len(small),len(big)])


 
def wcd_traversal_on_existing_tree(goals, removedRules, returnWitnesses=False):
    global openListWcd
    global closedListWcd

    
    openListWithoutRule=[]
    
    jointList = closedListWcd[:]
    jointList.extend(openListWcd)
    
    for node in jointList:      
        rulesUsed = [x._pid for x in node.getRules()]
        allRulesOk = True
        for removedRule in removedRules:
            if removedRule in rulesUsed:
                allRulesOk = False
                break
        
        if allRulesOk:
            openListWithoutRule.append(node)
    
        if not allGoalsReachables(removedRules):
            return -1 if not returnWitnesses else (-1, -1)
    
    return checkDistinctivenessForReduction(openListWithoutRule, returnWitnesses)


def wcpd_traversal_on_existing_tree(goals, removedRules, returnWitnesses=False):
    global openListWcpd
    global closedListWcpd
    
    #print "length of nodes before reduction=", len(openListWcpd)
    #print "removedRules=", len(removedRules)
    openListWithoutRule=[]
    
    jointList = closedListWcpd[:]
    jointList.extend(openListWcd)
    
    for node in jointList:
        rulesUsed = [x._pid for x in node.getRules()]
        allRulesOk = True
        for removedRule in removedRules:
            if removedRule in rulesUsed:
                allRulesOk = False
                break
        
        if allRulesOk:
            openListWithoutRule.append(node)
            
        if not allGoalsReachables(removedRules):
            return -1 if not returnWitnesses else (-1, -1)

    #print "length of nodes after reduction=", len(openListWithoutRule)
    return checkPlanDistinctivenessForReduction(openListWithoutRule, returnWitnesses)  

def extendAction(action, node, PL):
    tree = node.getTree()
    actionName = action[0].getRoot()
    actionIndex = action[1]
#     print "*************"
#     print "tree=", tree
#     print "action=", action
    newOpen = []
    #print "action[0]=",action[0].getRoot()
    #print "action[1]=", action[1]
    generatingSetForAction=PL.generatingSet([actionName])
    for item in generatingSetForAction:
        if actionIndex=="" or actionIndex=="-1":
            item.updateCompleteness()
            newNode = Node(item)
            newNode._rules = item.getRules()
            newNode._sequence = item.getObservations()
        else:
#             print "item=", item, item._isComplete
            newTree = tree.myCopy()
            newTree = newTree.substituteWithNode(item,action[1])
            newTree.updateCompleteness()
#             print "newTree=", newTree, newTree._isComplete
            newNode = node.myCopy()
            newNode._tree = newTree
            for rule in item.getRules():
                if rule not in newNode._rules:
                    newNode._rules.append(rule)
            for observation in item.getObservations():
                newNode._sequence.append(observation)
#         print "newNode=", newNode._tree, newNode._sequence
        newOpen.append(newNode)        
        
    #Now we need to combine between node and the newTrees that we got from the generating set.
    return newOpen             
                         
def calculateReachables(PL, goals):
    global reachables
    openList = deque()
    
    reachables = {}
    
    # init open with possible goals
    for goal in goals:
        g = Tree("Complex", goal, [], children=[], PL=PL)
        openList.append(Node(g))
    
    # extend one level in the open
    while len(openList)!=0:
        newOpen = deque()
        while len(openList)!=0:
            node = openList.popleft()
            tree = node.getTree()
            frontier = tree.getFrontier(withIndices=True)
            
            #New completed tree - add to reachable routes for goal
            if len(frontier)==0:
                if tree.getRoot().get() not in reachables.keys():
                    reachables[tree.getRoot().get()]=[]
                reachables[tree.getRoot().get()].append(map(lambda x: x._pid, node._rules))
                continue
            
            for action in frontier:
                resultedExtensions=extendAction(action, node, PL)
                newOpen.extend(resultedExtensions)
            
        openList=newOpen
        
#     for goal in reachables:
#         for path in reachables[goal]: 
#             print path
    allPlans=0
    for goal in reachables.keys():
        allPlans+=len(reachables[goal])
    print allPlans
    return #maxLeaves-1 if maxLeaves!=0 else 0 
                    
            
def wcd_init(PL, goals):
    global maxLeavesWcd
    global openListWcd
    global closedListWcd
    maxLeavesWcd = 0
    openListWcd = deque()
    closedListWcd = []
    
    # init open with possible goals
    for goal in goals:
        g = Tree("Complex", goal, [], children=[], PL=PL)
        openListWcd.append(Node(g))
    
    # extend one level in the open
    while not checkDistinctiveness(openListWcd):
        newOpen = deque()
        newNodesExtended = False
        while len(openListWcd)!=0:
            node = openListWcd.popleft()
            tree = node.getTree()
            frontier = tree.getFrontier(withIndices=True)
            if len(frontier)==0:# or node._expand==False:
                newOpen.append(node)
                continue
            else:
                newNodesExtended=True
            for action in frontier:
                resultedExtensions=extendAction(action, node, PL)
                newOpen.extend(resultedExtensions)
            
            inClosed=False
            for closedNode in closedListWcd:
                if closedNode==node:
                    inClosed=True
                    break
            if not inClosed and len(node.getRules())!=0:
                closedListWcd.append(node)
        openListWcd=newOpen

        if not newNodesExtended:
            return maxLeavesWcd
        
    return maxLeavesWcd #maxLeaves-1 if maxLeaves!=0 else 0   

def wcpd_init(PL, goals):
    global maxLeavesWcpd
    global openListWcpd
    global closedListWcpd
    maxLeavesWcpd = 0
    openListWcpd = deque()
    closedListWcpd = []
    
    # init open with possible goals
    for goal in goals:
        g = Tree("Complex", goal, [], children=[], PL=PL)
        openListWcpd.append(Node(g))
    
    # extend one level in the open
    while not checkPlanDistinctiveness(openListWcpd):
        newOpen = deque()
        newNodesExtended = False
        while len(openListWcpd)!=0:
            node = openListWcpd.popleft()
            tree = node.getTree()
            frontier = tree.getFrontier(withIndices=True)
            if len(frontier)==0:# or node._expand==False:
                newOpen.append(node)
                continue
            else:
                newNodesExtended=True
            for action in frontier:
                resultedExtensions=extendAction(action, node, PL)
                newOpen.extend(resultedExtensions)
                
            inClosed=False
            for closedNode in closedListWcpd:
                if closedNode==node:
                    inClosed=True
                    break
            if not inClosed and len(node.getRules())!=0:
                closedListWcpd.append(node)
        openListWcpd=newOpen
        
        if not newNodesExtended:
            return maxLeavesWcpd
        
    return maxLeavesWcpd #maxLeaves-1 if maxLeaves!=0 else 0   


#Wcd init which develops each node by one rule and not one observation
def wcd_init_oneRule(PL, goals):
    global maxLeavesWcd
    global openListWcd
    maxLeavesWcd = 0
    openListWcd = deque()
    closed = []
    
    # init open with possible goals
    for goal in goals:
        g = Tree("Complex", goal, [], children=[], PL=PL)
        openListWcd.append(Node(g))
    
    # extend one level in the open
    while not checkDistinctiveness(openListWcd):
        newOpen = deque()
        newNodesExtended = False
        while len(openListWcd)!=0:
            node = openListWcd.popleft()
            tree = node.getTree()
            frontier = tree.getFrontier(withIndices=True)
            if len(frontier)==0:# or node._expand==False:
                newOpen.append(node)
                continue
            else:
                newNodesExtended=True
            for action in frontier:
                actionName = action[0].getRoot()
                actionIndex = action[1]
                for rule in PL._P:
                    if rule._A._ch==actionName._ch:
                        newTree = tree.myCopy()
                        newNode = Node(newTree, node.getObservations()[:], node.getRules()[:])
                        newNode.addRule(rule._pid)
                        children=[]
                        for child in rule._alpha:
                            if type(child)==NT:
                                children.append(Tree("Complex", child, rule))
                            else:
                                childTree = Tree("Basic", child, rule)
                                childTree._isComplete=True
                                children.append(childTree)
                                newNode.addObservation(child)
                            
                        
                        newSubtree=Tree("Complex", actionName, rule, children)
                            
                        if actionIndex=='' or actionIndex=='-1':
                            newTree = newSubtree
                            newNode.setTree(newSubtree)
                        else:
                            newTree = newTree.substituteWithNode(newSubtree,actionIndex)
                        newOpen.append(newNode)
            if node not in closed:
                closed.append(node)
        openListWcd=newOpen

        if not newNodesExtended:
            return maxLeavesWcd
    return maxLeavesWcd #maxLeaves-1 if maxLeaves!=0 else 0   

def wcpd_init_oneRule(PL, goals):
    global maxLeavesWcpd
    global openListWcpd
    maxLeavesWcpd = 0
    openListWcpd = deque()
    closed = []
    
    # init open with possible goals
    for goal in goals:
        g = Tree("Complex", goal, [], children=[], PL=PL)
        openListWcpd.append(Node(g))
        
    # extend one level in the open
    while not checkPlanDistinctiveness(openListWcpd):
        newOpen = deque()
        newNodesExtended = False
        while len(openListWcpd)!=0:
            node = openListWcpd.popleft()
            tree = node.getTree()
            frontier = tree.getFrontier(withIndices=True)
            if len(frontier)==0:#  or node._expand==False:
                newOpen.append(node)
                continue
            else:
                newNodesExtended=True
            for action in frontier:
                actionName = action[0].getRoot()
                actionIndex = action[1]
                for rule in PL._P:
                    if rule._A._ch==actionName._ch:
                        newTree = tree.myCopy()
                        newNode = Node(newTree, node.getObservations()[:], node.getRules()[:])
                        newNode.addRule(rule._pid)
                        children=[]
                        for child in rule._alpha:
                            if type(child)==NT:
                                children.append(Tree("Complex", child, rule))
                            else:
                                childTree = Tree("Basic", child, rule)
                                childTree._isComplete=True
                                children.append(childTree)
                                newNode.addObservation(child)
                            
                        
                        newSubtree=Tree("Complex", actionName, rule, children)
                            
                        if actionIndex=='' or actionIndex=='-1':
                            newTree = newSubtree
                            newNode.setTree(newSubtree)
                        else:
                            newTree = newTree.substituteWithNode(newSubtree,actionIndex)
                        newOpen.append(newNode)
                        #print open
    #                     else:
    #                         print "Error - child name not as expected"
            if node not in closed:
                closed.append(node)
        openListWcpd=newOpen
        
        if not newNodesExtended:
            return maxLeavesWcpd #maxLeavesWcpd if maxLeavesWcpd !=0 else 0
    return maxLeavesWcpd #maxLeavesWcpd-1 if maxLeavesWcpd!=0 else 0
   
          
            
def createDomain(stringObs, instanceToRun):
    global AllNTs
    global AllRulesAsList
    
    Sigmas=[]
    NTs=[]
    Goals=[]
    i=0
    
    currentLine = stringObs[1:-1]
    delimiters = getDelimiters(currentLine)
    del1 = delimiters[0]-2
    del2 = delimiters[1]+1
    i=1
    while True:
        #currentLetter = 1
        #currentNumber = 1#{letter: 1 for letter in Letters2.split(" ")}
        singleProblem = currentLine[del1+2:del2]
#        print singleProblem
        
        probDels = getDelimiters(singleProblem)[0]
        recipeLibrary = singleProblem[:probDels]
        observations = singleProblem[probDels+4:-1]
        
        if i==instanceToRun:
            parseRecipeLibrary(recipeLibrary)
        
        i+=1
        del1=del2+1
        if i==len(delimiters)+1:
            break
        elif i==len(delimiters):
            del2=len(delimiters)-1
        else:        
            del2=delimiters[i]+1
        if i==len(delimiters):
            break
    
    for i in range(100):
        Sigmas.append(Sigma("A"+str(i+1)))
    
    for nt in AllNTs:
        if nt[0]=="*":
            Goals.append(NT(nt[1:]))
            NTs.append(NT(nt[1:]))
        else:
            NTs.append(NT(nt))
    
#     realGoal = Goals[int(stringObs[0][1:-1])]
#     for obs in stringObs[1:]:  
#         if len(obs)>1:
#             if obs[len(obs)-1]=='\n':
#                 obs = obs[:-1]
#             Observations.append(Sigma(obs))
#             print obs
            
    newPL = PL(Sigmas, NTs, Goals, AllRulesAsList)
    return newPL

def CBSWcdReduction(pl, goals, previouslyRemovedRules=[]):
    global basicWcd
    global basicPL
    global timeoutCount
    global timedoutFlagWcd
            
    bestWcd = basicWcd
    bestPL = pl 
    timedoutFlagWcd=False
    
    #PLsCheckList=Set()
    
    openListOfPLs = deque()
    openListOfPLs.append((pl, previouslyRemovedRules))  
    newOpen = deque()
    while len(openListOfPLs)!=0:
        if time.time()-timeoutCount>1800:
            timedoutFlagWcd=True
            return bestWcd, bestPL
        
        (currentPL, removedAlready) = openListOfPLs.pop()
        
        #CBS-n: allow only reductions of n rules or less
#         n=int(sys.argv[3])
#         if len(removedAlready)>n:
#             continue

        newWcd, witnesses = wcd_traversal_on_existing_tree(goals, removedAlready, returnWitnesses=True)
        if newWcd==-1:
            continue
        elif newWcd<bestWcd:            
#                 print "newBest=", newWcd
#                 print witnesses
#                 print map(lambda x: x.getObservations(), witnesses)
                bestWcd=newWcd
                bestPL=currentPL
                if bestWcd==0:
                    return bestWcd, bestPL
                
#         print "newWcd = ", newWcd
        rulesUsed=[]
        for witness in witnesses:
            for ruleInWitness in witness.getRules():
                if ruleInWitness not in rulesUsed:
                    rulesUsed.append(ruleInWitness)
        
        for ruleToRemove in filter(lambda x: x not in removedAlready, rulesUsed):
            newRemoved = removedAlready[:]
            newRemoved.append(ruleToRemove._pid)
            newPL = currentPL.differentRuleSetCopy(newRemoved)
#             print newRemoved
            newOpen.append((newPL, newRemoved))
        
        if len(newOpen)==0:
            break
        else:
            del openListOfPLs
            openListOfPLs=newOpen
            
    return bestWcd, bestPL


def CBSWcpdReduction(pl, goals, previouslyRemovedRules=[]):
    global basicWcpd
    global basicPL
    global timeoutCount
    global timedoutFlagWcpd
            
    bestWcpd = basicWcpd
    bestPL = pl 
    timedoutFlagWcpd=False
    #PLsCheckList=Set()
    
    openListOfPLs = deque()
    openListOfPLs.append((pl, previouslyRemovedRules))  
    newOpen = deque()
    while len(openListOfPLs)!=0:
        if time.time()-timeoutCount>1800:
            timedoutFlagWcpd=True
            return bestWcpd, bestPL
        (currentPL, removedAlready) = openListOfPLs.pop() 
        
        #CBS-n: allow only reductions of n rules or less
#         n=int(sys.argv[3])
#         if len(removedAlready)>n:
#             continue


        newWcpd, witnesses = wcpd_traversal_on_existing_tree(goals, removedAlready, returnWitnesses=True)
        if newWcpd==-1:
            continue
        elif newWcpd<bestWcpd:            
#                 print "newBest=", newWcpd
#                 print witnesses
#                 print map(lambda x: x.getObservations(), witnesses)
                bestWcpd=newWcpd
                bestPL=currentPL
                if bestWcpd==0:
                    return bestWcpd, bestPL
                
#         print "newWcd = ", newWcd
        rulesUsed=[]
        for witness in witnesses:
            for ruleInWitness in witness.getRules():
                if ruleInWitness not in rulesUsed:
                    rulesUsed.append(ruleInWitness)
        
        for ruleToRemove in filter(lambda x: x not in removedAlready, rulesUsed):
            newRemoved = removedAlready[:]
            newRemoved.append(ruleToRemove._pid)
            newPL = currentPL.differentRuleSetCopy(newRemoved)
#             print newRemoved
            newOpen.append((newPL, newRemoved))
        
        if len(newOpen)==0:
            break
        else:
            del openListOfPLs
            openListOfPLs=newOpen
            
    return bestWcpd, bestPL


def reduceDistinctivenessWcd(pl, goals, previouslyRemovedRules=[]):
    global basicWcd
    global basicPL
    bestWcd = basicWcd
    bestPL = pl
    
    #PLsCheckList=Set()
        
    openListOfPLs = deque()
    openListOfPLs.append((pl, previouslyRemovedRules))
    #PLsCheckList.add(pl.myHash(basicPL))    
    newOpen = deque()
    
    while len(openListOfPLs)!=0:
        (currentPL, removedAlready) = openListOfPLs.popleft()
        for i in range(len(currentPL._P)):
            newRemoved = removedAlready[:]
            newRemoved.append(currentPL._P[i]._pid)
            newPL = pl.differentRuleSetCopy(newRemoved)
            #print "removed ", newRemoved
            newWcd = wcd_traversal_on_existing_tree(goals, newRemoved)
            if len(newRemoved)<int(sys.argv[3]):
                newOpen.append((newPL, newRemoved))
            if newWcd!=-1 and newWcd<bestWcd:
                #Reduction of all rules
            #    if newWcd<bestWcd:
            #        newOpen = deque()
                
                bestWcd=newWcd
                bestPL=newPL
                if bestWcd==0:
                    return bestWcd, bestPL
 
        if len(newOpen)==0:
            break
        else:
            del openListOfPLs
            openListOfPLs=newOpen
            
    return bestWcd, bestPL

def reduceDistinctivenessWcpd(pl, goals, previouslyRemovedRules=[]):
    global basicWcpd
    global basicPL
    bestWcpd = basicWcpd
    bestPL = pl
            
    openListOfPLs = deque()
    openListOfPLs.append((pl, previouslyRemovedRules))
    newOpen = deque()
    
    while len(openListOfPLs)!=0:
        (currentPL, removedAlready) = openListOfPLs.popleft()
        for i in map(lambda x: x._pid, currentPL._P):
            newRemoved = removedAlready[:]
            newRemoved.append(i)
            newPL = pl.differentRuleSetCopy(newRemoved)
            newWcpd = wcpd_traversal_on_existing_tree(goals, newRemoved)
            if len(newRemoved)<int(sys.argv[3]):
                newOpen.append((newPL, newRemoved))
            if newWcpd!=-1 and newWcpd<bestWcpd:
                bestWcpd=newWcpd
                bestPL=newPL
                if bestWcpd==0:
                    return bestWcpd, bestPL
 
        if len(newOpen)==0:
            break
        else:
            del openListOfPLs
            openListOfPLs=newOpen
            
    return bestWcpd, bestPL
        
def main():
    global basicPL
    global basicWcd
    global basicWcpd
    global plansComparedWcd
    global plansComparedWcpd
    global timeoutCount
    global timedoutFlagWcd
    global timedoutFlagWcpd

    DebugFlag=False
    timeoutCount=time.time()
        
    domainFile = open("..\\ExampleDomain.txt", "r")
    domainString = domainFile.read()
    myPL = initPL()

    calculateReachables(myPL, myPL.getGoals())

    basicPL = myPL
    print basicPL
    print "len(basicPL._P)=",len(basicPL._P) 
    
    wcdFile = open("wcpdFile.csv", "a+")
    timeFile = open("timeFile.csv", "a+")
    start_time = time.time()
    basicWcd = wcd_init(basicPL, myPL.getGoals())
    middleTime1 = time.time()
    elapsed_time1 = middleTime1 - start_time  
    print "original Wcd=", basicWcd
    basicWcpd = wcpd_init(basicPL, myPL.getGoals())
    middleTime2 = time.time()
    elapsed_time2 = middleTime2 - middleTime1
    print "original Wcpd=", basicWcpd    
    print "before reductions"
    resWcd, resPLWcd = CBSWcdReduction(myPL, myPL.getGoals())
    middleTime3 = time.time()
    elapsed_time3 = middleTime3 - middleTime2
    print "after wcd reduction:", resWcd
    resWcpd, resPLWcpd = CBSWcpdReduction(myPL, myPL.getGoals())
    print "after wcpd reduction:", resWcpd
    elapsed_time4 = time.time() - middleTime3
    rulesRemovedForWcd=[x._pid for x in basicPL._P if x._pid not in map(lambda rule: rule._pid, resPLWcd._P)] #deepcopy(basicPL._P)
    resWcpdAccordingToWcd = wcpd_traversal_on_existing_tree(myPL.getGoals(), rulesRemovedForWcd)
    rulesRemovedForWcpd=[x._pid for x in basicPL._P if x._pid not in map(lambda rule: rule._pid, resPLWcpd._P)]
    resWcdAccordingToWcpd = wcd_traversal_on_existing_tree(myPL.getGoals(), rulesRemovedForWcpd)
    print "resWcd, resWcpdByWcd, len(resPL._P)=", resWcd, resWcpdAccordingToWcd, len(resPLWcd._P)
    print "resWcpd, resWcdByWcpd, len(resPL._P)=", resWcpd, resWcdAccordingToWcpd, len(resPLWcpd._P)
    print resPLWcd
    print "~_~_~_~"
    print resPLWcpd
    wcdFile.write(str(basicWcd)+","+str(basicWcpd)+","+str(len(basicPL._P))+","+str(plansComparedWcd)+","+str(plansComparedWcpd)+","+str(resWcd)+","+str(resWcpdAccordingToWcd)
                    +","+str(len(resPLWcd._P))+","+str(resWcpd)+","+str(resWcdAccordingToWcpd)+","+str(len(resPLWcpd._P))+","+str(timedoutFlagWcd)+","+str(timedoutFlagWcpd)+"\n")      
    wcdFile.close()
    timeFile.write(str(elapsed_time1)+","+str(elapsed_time2)+","+str(elapsed_time3)+","+str(elapsed_time4)+"\n")  
    timeFile.close()


 
if __name__ == '__main__': main()        