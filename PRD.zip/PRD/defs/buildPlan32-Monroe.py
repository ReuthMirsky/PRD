#!/usr/bin/env python
import sys
#import getopt
#import os
import re
import random

#import time
#import xlrd3
#import xml.dom
from xml.dom import minidom   
from copy import deepcopy
import math


#from xmlrpc.client import MAXINT
#from warnings import catch_warnings
import defs.Algorithm
import defs.Sigma
import defs.NT
import defs.Rule
import defs.PL

#-------------------------------Plan Library-----------------------------------------------------------------

def initPL():
    
    # Sigmas
    navegate_snowplow = defs.Sigma.Sigma('navegate_snowplow', ['person','veh','loc'])
    engage_plow = defs.Sigma.Sigma('engage_plow', ['person','plow'])
    disengage_plow = defs.Sigma.Sigma('disengage_plow', ['person','plow'])
    navegate_vehicle = defs.Sigma.Sigma('navegate_vehicle', ['person','veh','loc'])
    climb_in = defs.Sigma.Sigma('climb_in', ['obj','veh'])
    climb_out = defs.Sigma.Sigma('climb_out', ['obj','veh'])
    load = defs.Sigma.Sigma('load', ['person','obj','veh'])
    unload = defs.Sigma.Sigma('unload', ['person','obj','veh'])
    treat = defs.Sigma.Sigma('treat', ['emt','person'])
    treat_in_hospital = defs.Sigma.Sigma('treat_it_hospital', ['person','hospital'])
    call = defs.Sigma.Sigma('call', ['place',])
    remove_wire = defs.Sigma.Sigma('remove_wire', ['crew','lineloc'])
    string_wire = defs.Sigma.Sigma('string_wire', ['crew','lineloc'])
    carry_blockage_out_of_way = defs.Sigma.Sigma('carry_blockage_out_of_way', ['crew','stuff'])
    cut_tree = defs.Sigma.Sigma('cut_tree', ['crew','tree'])
    hook_up = defs.Sigma.Sigma('hook_up', ['obj','loc'])
    pour_into = defs.Sigma.Sigma('pour_into', ['obj','obj2'])
    turn_on = defs.Sigma.Sigma('turn_on', ['obj'])
    pay = defs.Sigma.Sigma('pay', ['loc'])
    pump_gas_into = defs.Sigma.Sigma('pump_gas_into', ['loc','obj'])
    turn_on_heat = defs.Sigma.Sigma('turn_on_heat', ['loc'])
    set_up_barricades = defs.Sigma.Sigma('set_up_barricades', ['police'])
    place_cones = defs.Sigma.Sigma('place_cones', ['police'])
    pickup_cones = defs.Sigma.Sigma('pickup_cones', ['police'])
    hook_to_tow_truck = defs.Sigma.Sigma('hook_to_tow_truck', ['ttruck','veh'])
    unhook_from_tow_truck = defs.Sigma.Sigma('unhook_from_tow_truck', ['ttruck','veh'])
    dig = defs.Sigma.Sigma('dig', ['backhoe','place'])
    fill_in = defs.Sigma.Sigma('fill_in', ['backhoe','place'])
    replace_pipe = defs.Sigma.Sigma('replace_pipe', ['crew','from','to'])
    clean_hazard = defs.Sigma.Sigma('clean_hazard', ['hazard_team','from','to'])
    
    #NTs
    set_up_shelter = defs.NT.NT('set_up_shelter', ['loc'])
    fix_water_main = defs.NT.NT('fix_water_main', ['from', 'to'])
    clear_road_hazard = defs.NT.NT('clear_road_hazard', ['from', 'to'])
    clear_road_wreck = defs.NT.NT('clear_road_wreck', ['from', 'to'])
    clear_road_tree = defs.NT.NT('clear_road_tree', ['from', 'to'])
    plow_road = defs.NT.NT('plow_road', ['from','to'])
    quell_riot = defs.NT.NT('quell_riot', ['loc'])
    provide_temp_heat = defs.NT.NT('provide_temp_heat', ['person'])
    fix_power_line = defs.NT.NT('fix_power_line', ['lineloc'])
    provide_medical_attention = defs.NT.NT('provide_medical_attention', ['person'])
    clean_up_hazard = defs.NT.NT('clean_up_hazard', ['from','to'])
    block_road = defs.NT.NT('block_road', ['from','to'])
    unblock_road = defs.NT.NT('unblock_road', ['from','to'])
    get_electricity = defs.NT.NT('get_electricity', ['loc'])
    repair_pipe = defs.NT.NT('repair_pipe', ['from','to'])
    open_hole = defs.NT.NT('open_hole', ['from','to'])
    close_hole = defs.NT.NT('close_hole', ['from','to'])
    set_up_cones = defs.NT.NT('set_up_cones', ['from','to'])
    take_down_cones = defs.NT.NT('take_down_cones', ['from','to'])
    clear_wreck = defs.NT.NT('clear_wreck', ['from','to'])
    tow_to = defs.NT.NT('tow_to', ['veh','to'])
    clear_tree = defs.NT.NT('clear_tree', ['tree'])
    remove_blockage = defs.NT.NT('remove_blockage', ['stuff'])
    declare_curfew = defs.NT.NT('declare_curfew', ['town'])
    generate_temp_electricity = defs.NT.NT('generate_temp_electricity', ['loc'])
    make_full_fuel = defs.NT.NT('make_full_fuel', ['gen'])
    add_fuel = defs.NT.NT('add_fuel', ['ss','obj'])
    repair_line = defs.NT.NT('repair_line', ['crew','lineloc'])
    shut_off_power = defs.NT.NT('shut_off_power', ['crew','lineloc'])
    turn_on_power = defs.NT.NT('turn_on_power', ['crew','loc'])
    shut_off_water = defs.NT.NT('shut_off_water', ['from','to'])
    turn_on_water = defs.NT.NT('turn_on_water', ['from','to'])
    emt_treat = defs.NT.NT('emt_treat', ['person'])
    stabilize = defs.NT.NT('stabilize', ['person'])
    get_to_obj = defs.NT.NT('get_to_obj', ['obj','place'])
    get_to_person = defs.NT.NT('get_to_person', ['person','place'])
    get_to_veh = defs.NT.NT('get_to_veh', ['veh','place'])
    drive_to = defs.NT.NT('drive_to', ['person','veh','loc'])
    get_in = defs.NT.NT('get_in', ['obj','veh'])
    get_out = defs.NT.NT('get_out', ['obj','veh'])
    
    # Rules
    rule1_1 = defs.Rule.Rule(set_up_shelter, [get_electricity, get_to_person, get_to_obj], [(0,1),(1,2)], [(-1,'loc',0,'loc'),(-1,'loc',1,'place'),(-1,'loc',2,'place')])
    rule1_2 = defs.Rule.Rule(set_up_shelter, [get_to_person, get_to_obj], [(0,1)], [(-1,'loc',0,'place'),(-1,'loc',1,'place')])
    rule1_3 = defs.Rule.Rule(set_up_shelter, [get_electricity, get_to_person], [(0,1)], [(-1,'loc',0,'loc'),(-1,'loc',1,'place')])
    rule1_4 = defs.Rule.Rule(set_up_shelter, [get_to_person], [], [(-1,'loc',0,'place')])
    rule2 = defs.Rule.Rule(fix_water_main, [shut_off_water, repair_pipe, turn_on_water], [(0,1),(1,2)], [(-1,'from',0,'from'),(-1,'from',1,'from'),(-1,'from',2,'from'),(-1,'to',0,'to'),(-1,'to',1,'to'),(-1,'to',2,'to')])
    rule3 = defs.Rule.Rule(clear_road_hazard, [block_road, clean_up_hazard, unblock_road], [(0,1),(1,2)], [(-1,'from',0,'from'),(-1,'from',1,'from'),(-1,'from',2,'from'),(-1,'to',0,'to'),(-1,'to',1,'to'),(-1,'to',2,'to')])
    rule4 = defs.Rule.Rule(clear_road_wreck, [set_up_cones, clear_wreck, take_down_cones], [(0,1),(1,2)], [(-1,'from',0,'from'),(-1,'from',1,'from'),(-1,'from',2,'from'),(-1,'to',0,'to'),(-1,'to',1,'to'),(-1,'to',2,'to')])
    rule5 = defs.Rule.Rule(clear_road_tree, [set_up_cones, clear_tree, take_down_cones], [(0,1),(1,2)], [(-1,'from',0,'from'),(-1,'from',2,'from'),(-1,'to',0,'to'),(-1,'to',2,'to')])
    rule6 = defs.Rule.Rule(plow_road, [get_to_person, navegate_snowplow, engage_plow, navegate_snowplow, disengage_plow], [(0,1),(1,2),(2,3),(3,4)], [(-1,'from',1,'loc'),(-1,'to',3,'loc'),(0,'person',1,'person'),(0,'person',2,'person'),(0,'person',3,'person'),(0,'person',4,'person'),(1,'veh',2,'plow'),(1,'veh',3,'veh'),(1,'veh',4,'plow')])
    rule7 = defs.Rule.Rule(quell_riot, [declare_curfew, get_to_person, get_to_person, set_up_barricades, set_up_barricades], [(0,1),(1,2),(2,3),(3,4)], [(-1,'loc',1,'place'),(-1,'loc',2,'place'),(1,'person',3,'police'),(2,'person',4,'police')])
    rule8 = defs.Rule.Rule(provide_temp_heat, [get_to_person], [], [(-1,'person',0,'person')])
    rule9 = defs.Rule.Rule(provide_temp_heat, [generate_temp_electricity, turn_on_heat], [(0,1)], [(0,'loc',1,'loc')])
    rule10 = defs.Rule.Rule(fix_power_line, [get_to_person, get_to_veh, repair_line], [(0,1),(1,2)], [(-1,'lineloc',0,'place'),(-1,'lineloc',1,'place'),(-1,'lineloc',2,'lineloc'),(0,'person',2,'crew')])
    rule11 = defs.Rule.Rule(provide_medical_attention, [get_to_person, treat_in_hospital], [(0,1)], [(-1,'person',0,'person'),(-1,'person',1,'person'),(0,'place',1,'hospital')])
    rule12 = defs.Rule.Rule(provide_medical_attention, [emt_treat], [], [(-1,'person',0,'person')])
    rule13 = defs.Rule.Rule(clean_up_hazard, [call], [], [])
    rule14 = defs.Rule.Rule(clean_up_hazard, [get_to_person, clean_hazard], [(0,1)], [(-1,'from',0,'place'),(-1,'from',1,'from'),(-1,'to',1,'to'),(0,'person',1,'hazard_team')])
    rule15 = defs.Rule.Rule(block_road, [set_up_cones, get_to_person], [], [(-1,'from',0,'from'),(-1,'from',1,'place'),(-1,'to',0,'to')])
    rule16 = defs.Rule.Rule(unblock_road, [take_down_cones], [], [(-1,'from',0,'from'),(-1,'to',0,'to')])
    rule17 = defs.Rule.Rule(get_electricity, [generate_temp_electricity], [], [(-1,'loc',0,'loc')])
    rule18 = defs.Rule.Rule(repair_pipe, [get_to_person, set_up_cones, open_hole, replace_pipe, close_hole, take_down_cones], [(0,1),(1,2),(2,3),(3,4),(4,5)], [(-1,'from',0,'place'),(-1,'from',1,'from'),(-1,'from',2,'from'),(-1,'from',3,'from'),(-1,'from',4,'from'),(-1,'from',5,'from'),
                                                                                                                                                                (-1,'to',1,'to'),(-1,'to',2,'to') ,(-1,'to',3,'to') ,(-1,'to',4,'to'),(-1,'to',5,'to'),(0,'person',3,'crew')])
    rule19 = defs.Rule.Rule(open_hole, [get_to_veh, dig], [(0,1)], [(-1,'from',0,'place'),(-1,'from',1,'place'),(0,'veh',1,'backhoe')])
    rule20 = defs.Rule.Rule(close_hole, [get_to_veh, fill_in], [(0,1)], [(-1,'from',0,'place'),(-1,'from',1,'place'),(0,'veh',1,'backhoe')])
    rule21 = defs.Rule.Rule(set_up_cones, [get_to_person, place_cones], [(0,1)], [(-1,'from',0,'place'),(0,'person',1,'police')])
    rule21_5 = defs.Rule.Rule(set_up_cones, [place_cones], [], [])
    rule22 = defs.Rule.Rule(take_down_cones, [get_to_person, pickup_cones], [(0,1)], [(-1,'from',0,'place'),(0,'person',1,'police')])
    rule23 = defs.Rule.Rule(clear_wreck, [tow_to], [], [(-1,'to',0,'to')])
    rule24 = defs.Rule.Rule(tow_to, [get_to_veh, hook_to_tow_truck, get_to_veh, unhook_from_tow_truck], [(0,1),(1,2),(2,3)], [(-1,'veh',1,'veh'),(-1,'veh',3,'veh'),(-1,'to',2,'place'),(0,'veh',1,'ttruck'),(0,'veh',2,'veh'),(0,'veh',3,'ttruck')])
    rule25_1 = defs.Rule.Rule(clear_tree, [get_to_person, cut_tree, remove_blockage], [(0,1),(1,2)], [(-1,'tree',1,'tree'),(-1,'tree',2,'stuff'),(0,'person',1,'crew')])
    rule25_2 = defs.Rule.Rule(clear_tree, [get_to_person, cut_tree], [(0,1)], [(-1,'tree',1,'tree'),(0,'person',1,'crew')])
    rule26 = defs.Rule.Rule(remove_blockage, [get_to_person, carry_blockage_out_of_way], [(0,1)], [(-1,'stuff',1,'stuff'),(0,'crew',1,'crew')])
    rule27 = defs.Rule.Rule(remove_blockage, [get_to_obj], [], [(-1,'stuff',0,'obj')])
    rule28 = defs.Rule.Rule(declare_curfew, [call, call], [], [])
    rule29_1 = defs.Rule.Rule(generate_temp_electricity, [make_full_fuel, get_to_obj, hook_up, turn_on], [(0,1),(1,2),(2,3),(3,4)], [(-1,'loc',1,'loc'),(-1,'loc',2,'loc'),(0,'gen',1,'obj'),(0,'gen',2,'obj'),(0,'gen',3,'obj')])
    rule29_2 = defs.Rule.Rule(generate_temp_electricity, [make_full_fuel, hook_up, turn_on], [(0,1),(1,2),(2,3)], [(-1,'loc',1,'loc'),(0,'gen',1,'obj'),(0,'gen',2,'obj')])
    rule30_1 = defs.Rule.Rule(make_full_fuel, [get_to_obj, add_fuel, get_to_obj, pour_into], [(0,1),(1,2),(2,3)], [(-1,'gen',3,'obj2'),(0,'obj',1,'obj'),(0,'obj',2,'obj'),(0,'obj',3,'obj'),(0,'loc',1,'ss')])
    rule30_2 = defs.Rule.Rule(make_full_fuel, [add_fuel, get_to_obj, pour_into], [(0,1),(1,2)], [(-1,'gen',2,'obj2'),(0,'obj',1,'obj'),(0,'obj',2,'obj')])
    rule30_3 = defs.Rule.Rule(make_full_fuel, [get_to_obj, add_fuel, pour_into], [(0,1),(1,2)], [(-1,'gen',2,'obj2'),(0,'obj',1,'obj'),(0,'obj',2,'obj'),(0,'loc',1,'ss')])
    rule30_4 = defs.Rule.Rule(make_full_fuel, [add_fuel, pour_into], [(0,1)], [(-1,'gen',1,'obj2'),(0,'obj',1,'obj')])
    rule31_1 = defs.Rule.Rule(make_full_fuel, [get_to_obj, add_fuel], [(0,1)], [(-1,'gen',0,'obj'),(-1,'gen',1,'obj'),(0,'loc',1,'ss')])
    rule31_2 = defs.Rule.Rule(make_full_fuel, [add_fuel], [], [(-1,'gen',0,'obj')])
    rule32 = defs.Rule.Rule(add_fuel, [pay, pump_gas_into], [], [(-1,'ss',0,'ss'),(-1,'ss',1,'loc'),(-1,'obj',1,'obj')])
    rule33 = defs.Rule.Rule(repair_line, [shut_off_power, clear_tree, remove_wire, string_wire, turn_on_power], [(0,1),(1,3),(2,3),(3,4)], [(-1,'lineloc',0,'lineloc'),(-1,'lineloc',2,'lineloc'),(-1,'lineloc',3,'lineloc'),(-1,'lineloc',4,'loc'),(-1,'crew',0,'crew'),(-1,'crew',2,'crew'),(-1,'crew',3,'crew'),(-1,'crew',4,'crew')])
    rule34 = defs.Rule.Rule(repair_line, [shut_off_power, remove_wire, string_wire, turn_on_power], [(0,1),(1,2),(2,3)], [(-1,'crew',0,'crew'),(-1,'crew',1,'crew'),(-1,'crew',2,'crew'),(-1,'crew',3,'crew'),(-1,'lineloc',0,'lineloc'),(-1,'lineloc',1,'lineloc'),(-1,'lineloc',2,'lineloc'),(-1,'lineloc',3,'loc')])
    rule35 = defs.Rule.Rule(shut_off_power, [call], [], [])
    rule36 = defs.Rule.Rule(turn_on_power, [call], [], [])
    rule37 = defs.Rule.Rule(shut_off_water, [call], [], [])
    rule38 = defs.Rule.Rule(turn_on_water, [call], [], [])
    rule39 = defs.Rule.Rule(emt_treat, [get_to_person, treat], [(0,1)], [(-1,'person',1,'person'),(0,'person',1,'emt')])
    rule40 = defs.Rule.Rule(stabilize, [emt_treat], [], [(-1,'person',0,'person')])
    rule41 = defs.Rule.Rule(get_to_person, [drive_to], [], [(-1,'person',0,'person'),(-1,'place',0,'loc')])
    rule42 = defs.Rule.Rule(get_to_veh, [drive_to], [], [(-1,'veh',0,'veh'),(-1,'place',0,'loc')])
    rule43 = defs.Rule.Rule(get_to_obj, [get_to_veh, get_in, get_to_veh, get_out], [(0,1),(1,2),(2,3)], [(-1,'obj',1,'obj'),(-1,'obj',3,'obj'),(-1,'place',2,'place'),(0,'veh',1,'veh'),(0,'veh',2,'veh'),(0,'veh',3,'veh')])
    rule44 = defs.Rule.Rule(get_to_obj, [get_to_veh, stabilize, get_in, get_to_veh, get_out], [(0,1),(1,2),(2,3),(3,4)], [(-1,'obj',1,'person'),(-1,'obj',2,'obj'),(-1,'obj',4,'obj'),(-1,'place',3,'place'),(0,'veh',2,'veh'),(0,'veh',3,'veh'),(0,'veh',4,'veh')])
    rule45 = defs.Rule.Rule(drive_to, [navegate_vehicle], [], [(-1,'loc',0,'loc'),(-1,'person',0,'person'),(-1,'veh',0,'veh')])
    rule46 = defs.Rule.Rule(get_in, [climb_in], [], [(-1,'obj',0,'obj'),(-1,'veh',0,'veh')])
    rule47 = defs.Rule.Rule(get_in, [get_to_person, load], [(0,1)], [(-1,'obj',1,'obj'),(-1,'veh',1,'veh'),(0,'person',1,'person')])
    rule48 = defs.Rule.Rule(get_out, [climb_out], [], [(-1,'obj',0,'obj'),(-1,'veh',0,'veh')])
    rule49 = defs.Rule.Rule(get_out, [get_to_person, unload], [(0,1)], [(-1,'obj',1,'obj'),(-1,'veh',1,'veh'),(0,'person',1,'person')])
    

    
    ########
    #    Full PL
    #########
    sigmas = [navegate_snowplow, engage_plow, disengage_plow, navegate_vehicle, climb_in, climb_out, load, unload, treat, 
    treat_in_hospital, call, remove_wire, string_wire, carry_blockage_out_of_way, cut_tree, hook_up, pour_into, turn_on, 
    pay, pump_gas_into, turn_on_heat, set_up_barricades, place_cones, pickup_cones, hook_to_tow_truck, unhook_from_tow_truck, 
    dig, fill_in, replace_pipe, clean_hazard]
    
    nts = [set_up_shelter, fix_water_main, clear_road_hazard, clear_road_wreck, clear_road_tree, plow_road, quell_riot,
    provide_temp_heat, fix_power_line, provide_medical_attention, clean_up_hazard, block_road, unblock_road, get_electricity,
    repair_pipe, open_hole, close_hole, set_up_cones, take_down_cones, clear_wreck, tow_to, clear_tree, remove_blockage,
    declare_curfew, generate_temp_electricity, make_full_fuel, add_fuel, repair_line, shut_off_power, turn_on_power,
    shut_off_water, turn_on_water, emt_treat, stabilize, get_to_obj, get_to_person, get_to_veh, drive_to, get_in, get_out]
    
    goals = [set_up_shelter, fix_water_main, clear_road_hazard, clear_road_wreck, clear_road_tree, plow_road, quell_riot,
    provide_temp_heat, fix_power_line, provide_medical_attention]
    
    rules = [rule1_1, rule1_2 ,rule1_3 ,rule1_4, rule2, rule3, rule4, rule5, rule6, rule7, rule8, rule9, rule10, rule11, rule12, 
             rule13, rule14, rule15, rule16, rule17, rule18, rule19, rule20, rule21, rule21_5, rule22, rule23, rule24, rule25_1, rule25_2,
              rule26, rule27, rule28, rule29_1, rule29_2, rule30_1, rule30_2, rule30_3, rule30_4, rule31_1, rule31_2, rule32, 
              rule33, rule34, rule35, rule36, rule37, rule38, rule39, rule40, rule41, rule42, rule43, rule44, rule45, rule46,
             rule47, rule48, rule49]
    
    return defs.PL.PL(sigmas, nts, goals, rules)


reuthObservations = []

#------------------------------- Main -----------------------------------------------------------------
import profile

def main():
    profile.run('myMain()')

def writeExp(exp):
    expAsStr="{ROOT"
    for tree in exp.getTrees():
        expAsStr+=reprTree(tree)
    expAsStr+="}"
    return expAsStr
    
def reprTree(tree):
    if [] == tree._children:
        sid=tree.getRoot().getParam("sid")
        if sid==None:
            sid="X"
        else:
            sid=sid[2:]
        did=tree.getRoot().getParam("did")
        if did==None:
            did="X"
        else:
            did=did[2:]
        if tree.isComplete():
            return sid+"-"+did
        else:
            return "{"+sid+"-"+did+"}"
    
    else:
        treeAsStr="{"
        for child in tree._children:
            treeAsStr+=reprTree(child)
        treeAsStr+="}"
        return treeAsStr
        
     
 
def myMain():
    probName = ""
    answer = ""

    sigma1 = defs.Sigma.Sigma('navegate_vehicle',['person','veh','loc'])
    sigma1.setParam('person', 'WCREW1')
    sigma1.setParam('veh', 'WTRUCK1')
    sigma1.setParam('loc', 'BRIGHTON-DUMP')
    sigma2 = defs.Sigma.Sigma('navegate_vehicle',['person','veh','loc'])
    sigma2.setParam('person', 'WCREW1')
    sigma2.setParam('veh', 'WTRUCK1')
    sigma2.setParam('loc', 'PITTSFORD-PLAZA')
    sigma3 = defs.Sigma.Sigma('place_cones',['police'])
    sigma3.setParam('police', 'TCREW1')
    sigma4 = defs.Sigma.Sigma('navegate_vehicle',['person','veh','loc'])
    sigma4.setParam('person', 'TTDRIVER1')
    sigma4.setParam('veh', 'TTRUCK1')
    sigma4.setParam('loc', 'PITTSFORD-PLAZA')
    sigma5 = defs.Sigma.Sigma('hook_to_tow_truck',['ttruck','veh'])
    sigma5.setParam('ttruck','TTRUCK1')
    sigma5.setParam('veh', 'VEHICLE-17807')
    sigma6 = defs.Sigma.Sigma('unhook_from_tow_truck',['ttruck','veh'])
    sigma6.setParam('ttruck','TTRUCK1')
    sigma6.setParam('veh', 'VEHICLE-17807')
    sigma7 = defs.Sigma.Sigma('navegate_vehicle',['person','veh','loc'])
    sigma7.setParam('person', 'PCREW1')
    sigma7.setParam('veh', 'VAN1')
    sigma7.setParam('loc', 'PITTSFORD-PLAZA')
    sigma8 = defs.Sigma.Sigma('pickup_cones',['police'])
    sigma8.setParam('police','PCREW1')
    
    
    reuthObservations=[sigma1, sigma2, sigma3, sigma4, sigma5, sigma6, sigma7, sigma8]
    print "ReuthObservations=", len(reuthObservations)    
    probabilities = {}
    
    #Parse 4th argument to filter actions
    # filterParams = sys.argv[4].split()
    #print "filter Actions = ", filterParams
    
    exps = defs.Algorithm.ExplainAndCompute(initPL(), reuthObservations)#, filterParams)
    if len(exps)==0:
        print "No Explnanations"    
    print "\n\n"    
    explanations = 0
    numOfExpsBySize = {0:0, 1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0, 8:0, 9:0}
    noFrontier = []
    allVectors=[]

    exps.sort(key=defs.Explanation.Explanation.getExpProbability)
#    expFileName="./exps/vectors-filtered.txt"
#    file = open(expFileName, 'w+')
    firstflag = True
    while not len(exps)==0:
        exp = exps.pop()
        if firstflag:
            print "-------------\n First Exp\n-----------------"
            print exp
            #print exp
            firstflag = False
        #exp.getExpProbability()
#        if probabilities[str(expProb)]==0:
#            probabilities[str(expProb)] = 1
#        else:
#            probabilities[str(expProb)] += 1
#            
        explanations+=1
        #print exp
        if exp.getSize()==1:
             print "-------------\n Exp With One Tree \n-----------------"
#             exp.printInMCSAForm()
             print exp

        if exp.getFrontierSize()==0:
            print "-------------\n Exp With Empty Frontier \n-----------------"
            print exp
            noFrontier.append(exp)

        if exp.getFrontierSize()==1:
            print "-------------\n Exp With Frontier of Size 1 \n-----------------"
            print exp
        numOfExpsBySize[exp.getFrontierSize()]+=1

        #print (exp)
        #file.write(str(exp.getFrontierSize())+","+str(exp.getSize())+","+str(exp.getAge())+"\n")
        #allVectors.append(vector)
        #file.write(vector)
#    mod = 0
    #file.write("0,#Trees,0,avgDepth\n");
    #file.close()
    #for exp in noFrontier:
#        if mod==0:
    #    print exp
#        mod+=1
#        mod = mod % 20
    
    print "Explanations: ", explanations
    print "No Frontier Explanations: ", len(noFrontier)
    #print probabilities
    print "Num of Exps by size:", numOfExpsBySize
 
# file.close()
    sys.exit()   
        

if __name__ == '__main__': main()