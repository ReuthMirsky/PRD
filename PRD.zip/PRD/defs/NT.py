import Sigma

class NT(Sigma.Letter):
    _type='NT'
