'''
Created on Mar 7, 2013

@author: Reuth
'''
from Queue import Queue
from copy import deepcopy 
from Explanation import Explanation
from Sigma import Letter, Sigma
from NT import NT
from Rule import Rule
from Tree import Tree
import random
from math import log
import sys
import xml.etree.ElementTree as ET
import time
from Probes import *
#from Probes import subtrees, subtreesID


#home
location = "Owner"
#office
#location = "dekelr"    


def writeExplanations(exps, explanations):
    expFileName="./exps/vectors-filered"
    expFileName+=str(explanations)
    expFileName+=".txt"
    filee = open(expFileName, 'w+')
    while not len(exps)==0:
        exp = exps.pop()
        #expProb = exp.getExpProbability()
#        if probabilities[str(expProb)]==0:
#            probabilities[str(expProb)] = 1
#        else:
#            probabilities[str(expProb)] += 1
#            

        #print (exp)
        filee.write(str(exp.getFrontierSize())+","+str(exp.getSize())+","+str(exp.getAge())+"\n")
    
    filee.write("0,2,0\n")
    filee.close()

def chooseRandomAmount(rangeList=[], threshold=0.5):
    #print "Range list before calc=", rangeList
    
    if rangeList== []:
        return []
    
    size = len(rangeList)
    picked = 0
    
    while picked<(size/2):
        newRand = random.randint(0,size-1)
        if rangeList[newRand]!=-1:
            rangeList[newRand]=-1
            picked+=1

    #print "Range list after calc=", rangeList            
    return rangeList

#PL is the plan library for this run, observations is a set of sigmas that needs to be explained
def ExplainAndCompute(PL, observations, filterParams=[], explanations=[]):
    global location
    myfile1 = open('C:\\Users\\'+location+'\\Desktop\\test2\\exps.csv', 'a+')
    #myfile2 = open('C:\\Users\\'+location+'\\Desktop\\test2\\time.csv', 'a+')
    #myfile1.write("\n"+sys.argv[2]+",")
    #myfile2.write("\n"+sys.argv[2]+",")
    myfile1.close()
    #myfile2.close()
    exps = explanations
    exps.append(Explanation())
    goalsGeneratingSet = PL.generatingSet(PL.getGoals())
    #print goalsGeneratingSet
    allGeneratingSet = {}
    filterInNextIteration = True
    timeBegin = time.clock()
    lastNum=0
                           
    #Set Filters
    if filterParams == []:
        filterBySizeStrict = False          #Size (int>=1) or False
        filterBySizeAverage = False           #True or False
        filterByAgeStrict = False            #Age (int>=1) or False
        filterByAgeAverage = False            #True or False
        filterByProbability = False           #True or False
        filterByFrontierSize = False          #Size (int>=1) or False
        filterByFrontierAverage = False           #True or False
        filterByRandomHalf = False
    else:
        filterBySizeStrict = filterParams[0]            #Size (int>=1) or False
        filterBySizeAverage = filterParams[1]           #True or False
        filterByAgeStrict = filterParams[2]                   #Age (int>=1) or False
        filterByAgeAverage = filterParams[3]            #True or False
        filterByProbability = filterParams[4]           #True or False
        filterByFrontierSize = filterParams[5]          #Size (int>=1) or False       
        filterByFrontierAverage = filterParams[6]       #True or False
    
    TreeAvgBound = 2.0
    ProbabilityAvg = 1.0
    AgeAvg = 1.0
    FrontierAvg = 1.0
    treesInAllGenSet = 0
    
    for nt in PL._NT:
        #print "Trees for ", nt
        allGeneratingSet[nt.get()] = PL.generatingSet([nt])
        treesInAllGenSet += len(allGeneratingSet[nt.get()])
#         for tree in allGeneratingSet[nt.get()]:
#             print tree
#    for tree in goalsGeneratingSet:
#        print ("tree in GS:")
#        print (tree)

    #Loop over all observations
    print "trees in genSet = ", treesInAllGenSet
    obsNum = 1
    for obs in observations:   
        print "handling obs number",obsNum  
#        print "avg. trees in exp=",TreeAvgBound
        expsTemp = []
        treesTotal = 0
        probabilityTotal = 0.0
        ageTotal = 0
        frontierTotal = 0
        numOfExps = 0.0
        oldExpNum = 0
        
#        if len(exps)==0:
#            print "No Exps"
#        else:
#            print "num of exps=",len(exps)

        #rangeList = chooseRandomAmount(range(0, len(exps)))
        #print rangeList
        #Loop over all the explanations in the queue
        
        #Measures for upper and lower bounds
        ProbabilityMin = 1.0
        ProbabilityMax = 0.0
        TreeAmountMin = 1000
        TreeAmountMax = 0
        AgeMin= 1000
        AgeMax = 0
        FrontierMin = 1000
        FrontierMax = 0
                
        for i in range(len(exps)):
            oldExpNum+=1
            #print "Old exp num=", oldExpNum
            currentExp = exps[i]
            #print currentExp
            
            #Filter Explanations
            currentExpProb = currentExp.getExpProbability()
            currentExpSize = currentExp.getSize()
            currentExpAge = currentExp.getAge()
            currentExpFrontier = currentExp.getFrontierSize()

            #Measures for upper and lower bounds
            if currentExpProb < ProbabilityMin:
                ProbabilityMin = currentExpProb
            if currentExpProb > ProbabilityMax:
                ProbabilityMax = currentExpProb
            if currentExpSize < TreeAmountMin:
                TreeAmountMin = currentExpSize
            if currentExpSize > TreeAmountMax:
                TreeAmountMax = currentExpSize
            if currentExpAge < AgeMin:
                AgeMin = currentExpAge
            if currentExpAge > AgeMax:
                AgeMax = currentExpAge
            if currentExpFrontier < FrontierMin:
                FrontierMin = currentExpFrontier
            if currentExpFrontier > FrontierMax:
                FrontierMax = currentExpFrontier
            
            if filterInNextIteration:
                if filterBySizeStrict and currentExpSize > filterBySizeStrict:
                    #print "Filtered by size strict"
                    continue
                if filterBySizeAverage and currentExpSize > TreeAvgBound:
                    #print "Filtered by size average"
                    continue
                if filterByAgeStrict and currentExpAge > filterByAgeStrict:
                    #print "Filtered by age strict"
                    continue
                if filterByAgeAverage and currentExpAge > AgeAvg:
                    #print "Filtered by age average"
                    continue
                if filterByProbability and currentExpProb < ProbabilityAvg:
                    #print "Filtered by probability"
                    continue
                if filterByFrontierSize and currentExpFrontier > filterByFrontierSize:
                    #print "Filtered by frontier strict"
                    continue
                if filterByFrontierAverage and currentExpFrontier > FrontierAvg:
                    #print "Filtered by frontier average"
                    #print "Frontier size=", currentExpFrontier
                    continue
                #if filterByRandomHalf and obsNum!=1 and -1==rangeList[oldExpNum-1]:
                #    continue
#             else:
#                 filterInNextIteration = True
            
           
            treeIndexInExp = 0

            #Consider all the existing plans the observation could extend
            for tree in currentExp.getTrees():
                treeFrontier = tree.getFrontier(withIndices=True)
                for (node, index) in treeFrontier:
                    #if obsNum==3 and node.getRoot().get()=="place_cones":
                        #print "1.1"
                        #print "**********************************************************************"
                        #print "node=", node.reprWithParams(), ", index=", index
                        #print "\n"
                    # Try to complete the frontier if it is a terminal letter, same as currentObs
#                   if type(node.getRoot())==Sigma and tree.sameParameters(obs, index):
#                       #if obsNum==3:
#                       #   print "1.2"
#                       newCopy = tree.myCopy()
#                       if newCopy.substitute(obs, index):
#                           newCopy.getDecendant(index)._isComplete = True
#                           newCopy.setID()
#                           newExp = currentExp.myCopy()
#                           newExp.setTree(newCopy, treeIndexInExp)
#                           newExp.updateLocalProbChoices(newCopy)
#                           newExp.resetAge()
#                           expsTemp.append(newExp)
#                           numOfExps += 1
#                           treesTotal += len(newExp.getTrees())
#                           probabilityTotal += newExp.getExpProbability()
#                           ageTotal += newExp.getAge()
#                           frontierTotal += newExp.getFrontierSize()
#                       else:
#                           del(newCopy)

                    #Try to complete the frontier by expanding the tree from this point
                    #First, create all trees that start in the frontier item and ends with obs
                    if type(node.getRoot()) == Sigma:
                        genSetForObs = []
                    else:
                        genSetTrees = []
                        for subtree in allGeneratingSet[node.getRoot().get()]:
                            genSetTrees.append(subtree.myCopy())
                        genSetForObs = PL.generatingSetForObs(genSetTrees, obs)
#                     print genSetForObs
#                     print "*******", len(genSetForObs), "**********"
                    #Then, try to see if the new sub-tree can be inserted instead of the frontier item
                    for newExpandedTree in genSetForObs:
                        #if obsNum==3:
                            #print "2.1"
                        if tree.sameParameters(newExpandedTree.getRoot(), index):
                            #if obsNum==3:
                                #print "2.2"
                            newCopy = tree.myCopy()
                            newCopy.setNodeByFrontierIndex(index, newExpandedTree)
                            if newCopy.substitute(newExpandedTree.getRoot(), index):
                                newCopy.setID()
                                newExp = currentExp.myCopy()
                                newExp.setTree(newCopy, treeIndexInExp)
                                newExp.updateLocalProbChoices(newCopy)
                                newExp.resetAge()
                                expsTemp.append(newExp)
                                #print "2"
                                #print newExpandedTree
                                numOfExps += 1
                                treesTotal += len(newExp.getTrees())
                                probabilityTotal += newExp.getExpProbability()
                                ageTotal += newExp.getAge()
                                frontierTotal += newExp.getFrontierSize()
                            else:
                                print "Threw tree:", newCopy.reprWithParams()
                                print "index=", index
                                del(newCopy)
#                       else:
#                           print("tree=",tree.getNodeByFrontierIndex(index).getRoot())
#                           print("node=",newExpandedTree.getRoot())
                treeIndexInExp+=1
                            
            #Consider all the new plans the observation could introduce
            for possTree in goalsGeneratingSet:
                treeFrontier = possTree.getFrontier(withIndices=True)
                for (node, index) in treeFrontier:
                    #if obsNum==3:
                    #   print "3.1"  
                    if possTree.sameParameters(obs, index):
                        #if obsNum==3:
                        #   print "3.2"
                        newCopy = possTree.myCopy()
                        newCopy.setID()
                        if newCopy.substitute(obs, index):
                                newExp = currentExp.myCopy()
                                newExp.setTree(newCopy)
                                newExp.backpatchPS(allGeneratingSet[possTree.getRoot().get()])
                                newExp.updateLocalProbChoices(newCopy)
                                newExp.updateLocalProbRoots(PL.getRootProb())
                                newExp.incrementAge()
                                expsTemp.append(newExp)
                                numOfExps += 1
                                treesTotal += len(newExp.getTrees())
                                probabilityTotal += newExp.getExpProbability()
                                ageTotal += newExp.getAge()
                                frontierTotal += newExp.getFrontierSize()
#                                 if newCopy.getID()==2888 or newCopy.getID()==2887:
#                                     print "here, ", newCopy.getID(), possTree.getID(), node, index
                        else:
                            del(newCopy)
                        
        if expsTemp == []:
            filterInNextIteration = False
            print "Cannot Combine Observation Number", obsNum, ": ", obs 
        else:
            del[exps]
            exps=expsTemp
            
        #writeExplanations(deepcopy(exps), obsNum)
        TreeAvgBound = treesTotal / numOfExps if 0!=numOfExps else 1000
        ProbabilityAvg = probabilityTotal / numOfExps if 0!=numOfExps else 1.0
        AgeAvg = ageTotal / numOfExps if 0!=numOfExps else 1.0
        FrontierAvg = frontierTotal / numOfExps if 0!=numOfExps else 1.0
        timeCurrent = time.clock()

        #Print Measurements:
        print ProbabilityMin, ",", ProbabilityMax, ",", TreeAmountMin, ",", TreeAmountMax, ",", AgeMin, ",", AgeMax, ",", FrontierMin, ",", FrontierMax, numOfExps
        print "time elapsed=", timeCurrent
        
        myfile1 = open('C:\\Users\\'+location+'\\Desktop\\test2\\exps.csv', 'a+')
        myfile2 = open('C:\\Users\\'+location+'\\Desktop\\test2\\time.csv', 'a+')
        if (numOfExps!=0):
            myfile1.write(str(numOfExps)+",")
            lastNum = str(numOfExps)
        else:
            myfile1.write(str(lastNum)+",")
        
        myfile2.write(str(timeCurrent)+",")
         
        myfile1.close()
        myfile2.close()
#       
        global oldNum
        global result
  
        if 5==obsNum:
            myfile2 = open('C:\\Users\\'+location+'\\Desktop\\test2\\time.csv', 'a+')
            #print "Time - first", time.clock()
            uniteIDs(exps)
            myfile2.write(str(time.clock())+",")
            #print "Time - after ID uni", time.clock()
            createMatrices(exps)
            myfile2.write(str(time.clock())+",")
            #print "Time - after matrices", time.clock()
            exps = query(exps, [], probeByEntropySub)
            myfile2.write(str(time.clock())+"\n")
            #print "Time - after queries", time.clock()
            myfile2.close()
            return exps
        obsNum += 1
        
    return exps


def uniteIDs(exps):
    global subtrees
    global subtreesID
    accumulatedTrees=0    
    
    trees = []
    for exp in exps:
        for tree in exp.getTrees():
            accumulatedTrees+=1
            #newID=getFirstTree(tree, trees) 
            if tree not in subtrees:#newID==-1: #and tree not in subtrees: #
                trees.append(tree)
                subtrees.append(tree)
                subtreesID.append(tree.getID())
#                 if tree in subtrees:
#                     print tree.reprWithParams()
#                     print "----"
#                     print subtrees[subtrees.index(tree)].reprWithParams()
#                     print tree is subtrees[subtrees.index(tree)]
#                     print tree==subtrees[subtrees.index(tree)]
                newSubtrees = rootSubTrees(tree)
                for subtree in newSubtrees:
                    #newSubID=getFirstTree(subtree, subtrees)
                    if subtree not in subtrees: #newSubID==-1:# and tree not in subtrees: # 
                        subtrees.append(subtree)
                        subtreesID.append(subtree.getID())
                    else:
                        subtree.setID(getFirstTree(subtree, subtrees)) 
                    #print tree.getID(), "->", newID
                    #subtrees.append(tree)
                    
                    #print tree.getID(), ":", subtrees.count(tree)
                    #subtreesID.append(tree.getID())
            else:
                    #print tree.getID(), "->", newID
                tree.setID(getFirstTree(tree, subtrees))

                    
    subtrees = list(set(subtrees))
    subtreesID = list(set(subtreesID))
    
    myfile3 = open('C:\\Users\\'+location+'\\Desktop\\test2\\plansUnification.csv', 'a+')          
    myfile3.write(str(accumulatedTrees)+","+str(len(trees))+","+str(len(subtrees))+"\n")
    myfile3.close()      
        #print "subtrees=", subtrees
        #return []
#     else:
#         trees=[]
#         ids=[]
#         for exp in exps:
#             for tree in exp.getTrees():
#                 if tree.getID() not in ids:
#                     trees.append(tree)
#                     ids.append(tree.getID())     