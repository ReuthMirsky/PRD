from PL import PL
from Tree import Tree
from Sigma import Sigma
from NT import NT
from Rule import Rule
from SearchNode import Node
from ParseLispToGramma import parseRecipeLibrary, AllNTs, AllRulesAsList, getDelimiters
from SoccerDomain import initPL
#from defs import SoccerDomain
from collections import deque
import itertools
import sys
import time
from Probes import Refines, Match
# This function will go over all nodes in the open list, for each goal it will count the different OBS sequences that this plan can describe
# return "True" iff each goal has a distinguished set of observation sequences 
dummy=0
maxLeaves=0
goalsExpanded=0
 
def initPL():
            
    # Sigmas
    navegate_snowplow = Sigma('navegate_snowplow', ['person','veh','loc'])
    engage_plow = Sigma('engage_plow', ['person','plow'])
    disengage_plow = Sigma('disengage_plow', ['person','plow'])
    navegate_vehicle = Sigma('navegate_vehicle', ['person','veh','loc'])
    climb_in = Sigma('climb_in', ['obj','veh'])
    climb_out = Sigma('climb_out', ['obj','veh'])
    load = Sigma('load', ['person','obj','veh'])
    unload = Sigma('unload', ['person','obj','veh'])
    treat = Sigma('treat', ['emt','person'])
    treat_in_hospital = Sigma('treat_it_hospital', ['person','hospital'])
    call = Sigma('call', ['place',])
    remove_wire = Sigma('remove_wire', ['crew','lineloc'])
    string_wire = Sigma('string_wire', ['crew','lineloc'])
    carry_blockage_out_of_way = Sigma('carry_blockage_out_of_way', ['crew','stuff'])
    cut_tree = Sigma('cut_tree', ['crew','tree'])
    hook_up = Sigma('hook_up', ['obj','loc'])
    pour_into = Sigma('pour_into', ['obj','obj2'])
    turn_on = Sigma('turn_on', ['obj'])
    pay = Sigma('pay', ['loc'])
    pump_gas_into = Sigma('pump_gas_into', ['loc','obj'])
    turn_on_heat = Sigma('turn_on_heat', ['loc'])
    set_up_barricades = Sigma('set_up_barricades', ['police'])
    place_cones = Sigma('place_cones', ['police'])
    pickup_cones = Sigma('pickup_cones', ['police'])
    hook_to_tow_truck = Sigma('hook_to_tow_truck', ['ttruck','veh'])
    unhook_from_tow_truck = Sigma('unhook_from_tow_truck', ['ttruck','veh'])
    dig = Sigma('dig', ['backhoe','place'])
    fill_in = Sigma('fill_in', ['backhoe','place'])
    replace_pipe = Sigma('replace_pipe', ['crew','from','to'])
    clean_hazard = Sigma('clean_hazard', ['hazard_team','from','to'])
            
    #NTs
    set_up_shelter = NT('set_up_shelter', ['loc'])
    fix_water_main = NT('fix_water_main', ['from', 'to'])
    clear_road_hazard = NT('clear_road_hazard', ['from', 'to'])
    clear_road_wreck = NT('clear_road_wreck', ['from', 'to'])
    clear_road_tree = NT('clear_road_tree', ['from', 'to'])
    plow_road = NT('plow_road', ['from','to'])
    quell_riot = NT('quell_riot', ['loc'])
    provide_temp_heat = NT('provide_temp_heat', ['person'])
    fix_power_line = NT('fix_power_line', ['lineloc'])
    provide_medical_attention = NT('provide_medical_attention', ['person'])
    clean_up_hazard = NT('clean_up_hazard', ['from','to'])
    block_road = NT('block_road', ['from','to'])
    unblock_road = NT('unblock_road', ['from','to'])
    get_electricity = NT('get_electricity', ['loc'])
    repair_pipe = NT('repair_pipe', ['from','to'])
    open_hole = NT('open_hole', ['from','to'])
    close_hole = NT('close_hole', ['from','to'])
    set_up_cones = NT('set_up_cones', ['from','to'])
    take_down_cones = NT('take_down_cones', ['from','to'])
    clear_wreck = NT('clear_wreck', ['from','to'])
    tow_to = NT('tow_to', ['veh','to'])
    clear_tree = NT('clear_tree', ['tree'])
    remove_blockage = NT('remove_blockage', ['stuff'])
    declare_curfew = NT('declare_curfew', ['town'])
    generate_temp_electricity = NT('generate_temp_electricity', ['loc'])
    make_full_fuel = NT('make_full_fuel', ['gen'])
    add_fuel = NT('add_fuel', ['ss','obj'])
    repair_line = NT('repair_line', ['crew','lineloc'])
    shut_off_power = NT('shut_off_power', ['crew','lineloc'])
    turn_on_power = NT('turn_on_power', ['crew','loc'])
    shut_off_water = NT('shut_off_water', ['from','to'])
    turn_on_water = NT('turn_on_water', ['from','to'])
    emt_treat = NT('emt_treat', ['person'])
    stabilize = NT('stabilize', ['person'])
    get_to_obj = NT('get_to_obj', ['obj','place'])
    get_to_person = NT('get_to_person', ['person','place'])
    get_to_veh = NT('get_to_veh', ['veh','place'])
    drive_to = NT('drive_to', ['person','veh','loc'])
    get_in = NT('get_in', ['obj','veh'])
    get_out = NT('get_out', ['obj','veh'])
            
    # Rules
    rule1_1 = Rule(set_up_shelter, [get_electricity, get_to_person, get_to_obj], [(0,1),(1,2)], [(-1,'loc',0,'loc'),(-1,'loc',1,'place'),(-1,'loc',2,'place')])
    rule1_2 = Rule(set_up_shelter, [get_to_person, get_to_obj], [(0,1)], [(-1,'loc',0,'place'),(-1,'loc',1,'place')])
    rule1_3 = Rule(set_up_shelter, [get_electricity, get_to_person], [(0,1)], [(-1,'loc',0,'loc'),(-1,'loc',1,'place')])
    rule1_4 = Rule(set_up_shelter, [get_to_person], [], [(-1,'loc',0,'place')])
    rule2 = Rule(fix_water_main, [shut_off_water, repair_pipe, turn_on_water], [(0,1),(1,2)], [(-1,'from',0,'from'),(-1,'from',1,'from'),(-1,'from',2,'from'),(-1,'to',0,'to'),(-1,'to',1,'to'),(-1,'to',2,'to')])
    rule3 = Rule(clear_road_hazard, [block_road, clean_up_hazard, unblock_road], [(0,1),(1,2)], [(-1,'from',0,'from'),(-1,'from',1,'from'),(-1,'from',2,'from'),(-1,'to',0,'to'),(-1,'to',1,'to'),(-1,'to',2,'to')])
    rule4 = Rule(clear_road_wreck, [set_up_cones, clear_wreck, take_down_cones], [(0,1),(1,2)], [(-1,'from',0,'from'),(-1,'from',1,'from'),(-1,'from',2,'from'),(-1,'to',0,'to'),(-1,'to',1,'to'),(-1,'to',2,'to')])
    rule5 = Rule(clear_road_tree, [set_up_cones, clear_tree, take_down_cones], [(0,1),(1,2)], [(-1,'from',0,'from'),(-1,'from',2,'from'),(-1,'to',0,'to'),(-1,'to',2,'to')])
    rule6 = Rule(plow_road, [get_to_person, navegate_snowplow, engage_plow, navegate_snowplow, disengage_plow], [(0,1),(1,2),(2,3),(3,4)], [(-1,'from',1,'loc'),(-1,'to',3,'loc'),(0,'person',1,'person'),(0,'person',2,'person'),(0,'person',3,'person'),(0,'person',4,'person'),(1,'veh',2,'plow'),(1,'veh',3,'veh'),(1,'veh',4,'plow')])
    rule7 = Rule(quell_riot, [declare_curfew, get_to_person, get_to_person, set_up_barricades, set_up_barricades], [(0,1),(1,2),(2,3),(3,4)], [(-1,'loc',1,'place'),(-1,'loc',2,'place'),(1,'person',3,'police'),(2,'person',4,'police')])
    rule8 = Rule(provide_temp_heat, [get_to_person], [], [(-1,'person',0,'person')])
    rule9 = Rule(provide_temp_heat, [generate_temp_electricity, turn_on_heat], [(0,1)], [(0,'loc',1,'loc')])
    rule10 = Rule(fix_power_line, [get_to_person, get_to_veh, repair_line], [(0,1),(1,2)], [(-1,'lineloc',0,'place'),(-1,'lineloc',1,'place'),(-1,'lineloc',2,'lineloc'),(0,'person',2,'crew')])
    rule11 = Rule(provide_medical_attention, [get_to_person, treat_in_hospital], [(0,1)], [(-1,'person',0,'person'),(-1,'person',1,'person'),(0,'place',1,'hospital')])
    rule12 = Rule(provide_medical_attention, [emt_treat], [], [(-1,'person',0,'person')])
    rule13 = Rule(clean_up_hazard, [call], [], [])
    rule14 = Rule(clean_up_hazard, [get_to_person, clean_hazard], [(0,1)], [(-1,'from',0,'place'),(-1,'from',1,'from'),(-1,'to',1,'to'),(0,'person',1,'hazard_team')])
    rule15 = Rule(block_road, [set_up_cones, get_to_person], [], [(-1,'from',0,'from'),(-1,'from',1,'place'),(-1,'to',0,'to')])
    rule16 = Rule(unblock_road, [take_down_cones], [], [(-1,'from',0,'from'),(-1,'to',0,'to')])
    rule17 = Rule(get_electricity, [generate_temp_electricity], [], [(-1,'loc',0,'loc')])
    rule18 = Rule(repair_pipe, [get_to_person, set_up_cones, open_hole, replace_pipe, close_hole, take_down_cones], [(0,1),(1,2),(2,3),(3,4),(4,5)], [(-1,'from',0,'place'),(-1,'from',1,'from'),(-1,'from',2,'from'),(-1,'from',3,'from'),(-1,'from',4,'from'),(-1,'from',5,'from'),
                                                                                                                                                                (-1,'to',1,'to'),(-1,'to',2,'to') ,(-1,'to',3,'to') ,(-1,'to',4,'to'),(-1,'to',5,'to'),(0,'person',3,'crew')])
    rule19 = Rule(open_hole, [get_to_veh, dig], [(0,1)], [(-1,'from',0,'place'),(-1,'from',1,'place'),(0,'veh',1,'backhoe')])
    rule20 = Rule(close_hole, [get_to_veh, fill_in], [(0,1)], [(-1,'from',0,'place'),(-1,'from',1,'place'),(0,'veh',1,'backhoe')])
    rule21 = Rule(set_up_cones, [get_to_person, place_cones], [(0,1)], [(-1,'from',0,'place'),(0,'person',1,'police')])
    rule21_5 = Rule(set_up_cones, [place_cones], [], [])
    rule22 = Rule(take_down_cones, [get_to_person, pickup_cones], [(0,1)], [(-1,'from',0,'place'),(0,'person',1,'police')])
    rule23 = Rule(clear_wreck, [tow_to], [], [(-1,'to',0,'to')])
    rule24 = Rule(tow_to, [get_to_veh, hook_to_tow_truck, get_to_veh, unhook_from_tow_truck], [(0,1),(1,2),(2,3)], [(-1,'veh',1,'veh'),(-1,'veh',3,'veh'),(-1,'to',2,'place'),(0,'veh',1,'ttruck'),(0,'veh',2,'veh'),(0,'veh',3,'ttruck')])
    rule25_1 = Rule(clear_tree, [get_to_person, cut_tree, remove_blockage], [(0,1),(1,2)], [(-1,'tree',1,'tree'),(-1,'tree',2,'stuff'),(0,'person',1,'crew')])
    rule25_2 = Rule(clear_tree, [get_to_person, cut_tree], [(0,1)], [(-1,'tree',1,'tree'),(0,'person',1,'crew')])
    rule26 = Rule(remove_blockage, [get_to_person, carry_blockage_out_of_way], [(0,1)], [(-1,'stuff',1,'stuff'),(0,'crew',1,'crew')])
    rule27 = Rule(remove_blockage, [get_to_obj], [], [(-1,'stuff',0,'obj')])
    rule28 = Rule(declare_curfew, [call, call], [], [])
    rule29_1 = Rule(generate_temp_electricity, [make_full_fuel, get_to_obj, hook_up, turn_on], [(0,1),(1,2),(2,3)], [(-1,'loc',1,'loc'),(-1,'loc',2,'loc'),(0,'gen',1,'obj'),(0,'gen',2,'obj'),(0,'gen',3,'obj')])
    rule29_2 = Rule(generate_temp_electricity, [make_full_fuel, hook_up, turn_on], [(0,1),(1,2)], [(-1,'loc',1,'loc'),(0,'gen',1,'obj'),(0,'gen',2,'obj')])
    rule30_1 = Rule(make_full_fuel, [get_to_obj, add_fuel, get_to_obj, pour_into], [(0,1),(1,2),(2,3)], [(-1,'gen',3,'obj2'),(0,'obj',1,'obj'),(0,'obj',2,'obj'),(0,'obj',3,'obj'),(0,'loc',1,'ss')])
    rule30_2 = Rule(make_full_fuel, [add_fuel, get_to_obj, pour_into], [(0,1),(1,2)], [(-1,'gen',2,'obj2'),(0,'obj',1,'obj'),(0,'obj',2,'obj')])
    rule30_3 = Rule(make_full_fuel, [get_to_obj, add_fuel, pour_into], [(0,1),(1,2)], [(-1,'gen',2,'obj2'),(0,'obj',1,'obj'),(0,'obj',2,'obj'),(0,'loc',1,'ss')])
    rule30_4 = Rule(make_full_fuel, [add_fuel, pour_into], [(0,1)], [(-1,'gen',1,'obj2'),(0,'obj',1,'obj')])
    rule31_1 = Rule(make_full_fuel, [get_to_obj, add_fuel], [(0,1)], [(-1,'gen',0,'obj'),(-1,'gen',1,'obj'),(0,'loc',1,'ss')])
    rule31_2 = Rule(make_full_fuel, [add_fuel], [], [(-1,'gen',0,'obj')])
    rule32 = Rule(add_fuel, [pay, pump_gas_into], [], [(-1,'ss',0,'ss'),(-1,'ss',1,'loc'),(-1,'obj',1,'obj')])
    rule33 = Rule(repair_line, [shut_off_power, clear_tree, remove_wire, string_wire, turn_on_power], [(0,1),(1,3),(2,3),(3,4)], [(-1,'lineloc',0,'lineloc'),(-1,'lineloc',2,'lineloc'),(-1,'lineloc',3,'lineloc'),(-1,'lineloc',4,'loc'),(-1,'crew',0,'crew'),(-1,'crew',2,'crew'),(-1,'crew',3,'crew'),(-1,'crew',4,'crew')])
    rule34 = Rule(repair_line, [shut_off_power, remove_wire, string_wire, turn_on_power], [(0,1),(1,2),(2,3)], [(-1,'crew',0,'crew'),(-1,'crew',1,'crew'),(-1,'crew',2,'crew'),(-1,'crew',3,'crew'),(-1,'lineloc',0,'lineloc'),(-1,'lineloc',1,'lineloc'),(-1,'lineloc',2,'lineloc'),(-1,'lineloc',3,'loc')])
    rule35 = Rule(shut_off_power, [call], [], [])
    rule36 = Rule(turn_on_power, [call], [], [])
    rule37 = Rule(shut_off_water, [call], [], [])
    rule38 = Rule(turn_on_water, [call], [], [])
    rule39 = Rule(emt_treat, [get_to_person, treat], [(0,1)], [(-1,'person',1,'person'),(0,'person',1,'emt')])
    rule40 = Rule(stabilize, [emt_treat], [], [(-1,'person',0,'person')])
    rule41 = Rule(get_to_person, [drive_to], [], [(-1,'person',0,'person'),(-1,'place',0,'loc')])
    rule42 = Rule(get_to_veh, [drive_to], [], [(-1,'veh',0,'veh'),(-1,'place',0,'loc')])
    rule43 = Rule(get_to_obj, [get_to_veh, get_in, get_to_veh, get_out], [(0,1),(1,2),(2,3)], [(-1,'obj',1,'obj'),(-1,'obj',3,'obj'),(-1,'place',2,'place'),(0,'veh',1,'veh'),(0,'veh',2,'veh'),(0,'veh',3,'veh')])
    rule44 = Rule(get_to_obj, [get_to_veh, stabilize, get_in, get_to_veh, get_out], [(0,1),(1,2),(2,3),(3,4)], [(-1,'obj',1,'person'),(-1,'obj',2,'obj'),(-1,'obj',4,'obj'),(-1,'place',3,'place'),(0,'veh',2,'veh'),(0,'veh',3,'veh'),(0,'veh',4,'veh')])
    rule45 = Rule(drive_to, [navegate_vehicle], [], [(-1,'loc',0,'loc'),(-1,'person',0,'person'),(-1,'veh',0,'veh')])
    rule46 = Rule(get_in, [climb_in], [], [(-1,'obj',0,'obj'),(-1,'veh',0,'veh')])
    rule47 = Rule(get_in, [get_to_person, load], [(0,1)], [(-1,'obj',1,'obj'),(-1,'veh',1,'veh'),(0,'person',1,'person')])
    rule48 = Rule(get_out, [climb_out], [], [(-1,'obj',0,'obj'),(-1,'veh',0,'veh')])
    rule49 = Rule(get_out, [get_to_person, unload], [(0,1)], [(-1,'obj',1,'obj'),(-1,'veh',1,'veh'),(0,'person',1,'person')])
            
        
            
    ########
    #    Full PL
    #########
    sigmas = [navegate_snowplow, engage_plow, disengage_plow, navegate_vehicle, climb_in, climb_out, load, unload, treat, 
    treat_in_hospital, call, remove_wire, string_wire, carry_blockage_out_of_way, cut_tree, hook_up, pour_into, turn_on, 
    pay, pump_gas_into, turn_on_heat, set_up_barricades, place_cones, pickup_cones, hook_to_tow_truck, unhook_from_tow_truck, 
    dig, fill_in, replace_pipe, clean_hazard]
            
    nts = [fix_water_main, clear_road_hazard, clear_road_wreck, clear_road_tree, plow_road, quell_riot,
    provide_temp_heat, fix_power_line, provide_medical_attention, clean_up_hazard, block_road, unblock_road, get_electricity,
    repair_pipe, open_hole, close_hole, set_up_cones, take_down_cones, clear_wreck, tow_to, clear_tree, remove_blockage,
    declare_curfew, generate_temp_electricity, make_full_fuel, add_fuel, repair_line, shut_off_power, turn_on_power,
    shut_off_water, turn_on_water, emt_treat, stabilize, get_to_obj, get_to_person, get_to_veh, drive_to, get_in, get_out]
            
    goals = [set_up_shelter, fix_water_main, clear_road_hazard, clear_road_wreck, clear_road_tree, plow_road, quell_riot,
    provide_temp_heat, fix_power_line, provide_medical_attention]
            
    rules = [rule1_1, rule1_2 ,rule1_3 ,rule1_4, rule2, rule3, rule4, rule5, rule6, rule7, rule8, rule9, rule10, rule11, rule12, 
             rule13, rule14, rule15, rule16, rule17, rule18, rule19, rule20, rule21, rule21_5, rule22, rule23, rule24, rule25_1, rule25_2,
              rule26, rule27, rule28, rule29_1, rule29_2, rule30_1, rule30_2, rule30_3, rule30_4, rule31_1, rule31_2, rule32, 
              rule33, rule34, rule35, rule36, rule37, rule38, rule39, rule40, rule41, rule42, rule43, rule44, rule45, rule46,
             rule47, rule48, rule49]
            
    return PL(sigmas, nts, goals, rules)

def checkDistinctivenessDummy(open):
    global dummy
    if dummy==3:
        return True
    else:
        dummy+=1
        return False
#                 
# def createPermutationsNoInterleaving(obsPerChild, rule):
#     print obsPerChild
#     if len(rule._order)==0:
#         allPerm =  itertools.permutations(obsPerChild)
#         allObs = []
#         for permutation in allPerm:
#             print permutation
#             newSequence = ""
#             for token in permutation:
#                 if token==[-1]:
#                     continue
#                 newSequence += token
#             allObs.append(newSequence)
#         return allObs
#     else:
#         if checkDistinctivenessDummy([]):
#             return ["a"]
#         else:
#             return ["b"] 
    
# def canExplain(node, sequence): 
#     if len(sequence)==1:
#         return True
#     rule = node._rule
#     #This means this node is not yet expanded
#     if rule==[]:
#         return True
#     if rule==():
#         return False
#     #orderingConstraints=node._rule._order
#     leavesLen = [0]
#     for child in node._children:
#         leavesLen.append(leavesLen[-1]+len(getLeaves(child)))
#     i=0
#     print leavesLen
#     while i+1<len(leavesLen):
#         if not canExplain(node._children[i], sequence[leavesLen[i]:leavesLen[i+1]]):
#             print "cannot explain"
#             return False
#         i+=1
#     return True
     
def getLeaves(node):
    if node._actionType=="Basic":
        return [node.getRoot().get()]
    
    if len(node._children)==0:
        return []
    res=[]
    for child in node._children:
        #childSequences = getLeaves(child)
        res.extend(getLeaves(child))
    return res   
    
def getObservations(node):
    global maxLeaves
    basicSequence = getLeaves(node)
    return basicSequence
#     allSequences = itertools.permutations(basicSequence)
#     allPossibleSequences = []
#     for sequence in allSequences:
#         if sequence!=():
#             if canExplain(node, sequence):
#                 allPossibleSequences.append(sequence)
#     return allPossibleSequences 
        

def checkPlanDistinctiveness(open):
    global maxLeaves
    global goalsExpanded
    global basicPL
    plans = {}
    goals = []
    answer=False
    goalsExpanded=0
    plGoals = basicPL._R
    
    for node in open:

        goal = node.getTree()#.getRoot().get()
        if not plans.has_key(goal):
            plans[goal]=[]
        #Else - no need to add the key, can just extend the existing list
        observations = node.getObservations()
        #This means that there are no observable actions yet
        if len(observations)==0:
            continue
        
        if node.getTree().getRoot().get() not in goals:
            goals.append(node.getTree().getRoot().get())
            goalsExpanded+=1
        
        plans[goal].append(observations)
    
    if len(plGoals)!=len(goals):
        return False    

    answer=True    
    for goal in plans.keys():
        if len(plans[goal])==0:
            return False
        for sequence in plans[goal]:
            if len(sequence)<maxLeaves:
                continue
            if len(sequence)==maxLeaves and answer==False:
                continue
            for goal2 in plans.keys():
                if goal2!=goal:
                    for sequence2 in plans[goal2]:
                        #print sequence2, " / ", sequence, "=", contains(sequence2, sequence)
                        if contains(sequence2, sequence) and not Match(goal, goal2):
                            #print "here", answer
                            minLen = min(len(sequence), len(sequence2))+1
                            if maxLeaves<minLen:
#                                 print goal2, ", ", goal
#                                 print sequence2, "<", sequence
                                maxLeaves=minLen
                            answer=False    
    return answer     

def checkDistinctiveness(open):
    global maxLeaves
    global goalsExpanded
    global basicPL
    plans = {}
    goals = []
    answer=False
    goalsExpanded=0
    plGoals = basicPL._R
    
    for node in open:

        goal = node.getTree()#.getRoot().get()
        if not plans.has_key(goal):
            plans[goal]=[]
        #Else - no need to add the key, can just extend the existing list
        observations = node.getObservations()
        #This means that there are no observable actions yet
        if len(observations)==0:
            continue
        
        if node.getTree().getRoot().get() not in goals:
            goals.append(node.getTree().getRoot().get())
            goalsExpanded+=1
        
        plans[goal].append(observations)
    
    if len(plGoals)!=len(goals):
        return False    

    answer=True    
    for goal in plans.keys():
        if len(plans[goal])==0:
            return False
        for sequence in plans[goal]:
            if len(sequence)<maxLeaves:
                continue
            if len(sequence)==maxLeaves and answer==False:
                continue
            for goal2 in plans.keys():
                if goal2!=goal:
                    for sequence2 in plans[goal2]:
                        #print sequence2, " / ", sequence, "=", contains(sequence2, sequence)
                        if contains(sequence2, sequence):
                            #print "here", answer
                            minLen = min(len(sequence), len(sequence2))+1
                            if maxLeaves<minLen:
                                print goal2, ", ", goal
                                print sequence2, "<", sequence
                                maxLeaves=minLen
                            answer=False    
    return answer         

def checkDistinctiveness2(open):
    global maxLeaves
    global goalsExpanded
    goals = {}
    goalsExpanded=0
    
    for node in open:
        #print node
        #print node.getObservations()
        #node = node.getTree()
        goal = node.getTree().getRoot().get()
        if not goals.has_key(goal):
            goals[goal]=[]
        #Else - no need to add the key, can just extend the existing list
        observations = node.getObservations()
        #This means that there are no observable actions yet
        if len(observations)==0:
            continue

        goals[goal].append(observations)
    
    answer=True
    for goal in goals.keys():
        if len(goals[goal])==0:
            return False
        else:
            goalsExpanded+=1
        for sequence in goals[goal]:
            #Optimization - if sequence is not longer than maxLeaves, it's a shame to search all possibilities.
            if len(sequence)<=maxLeaves:
                continue
            for goal2 in goals.keys():
                if goal2!=goal:
                    for sequence2 in goals[goal2]:
                        if contains(sequence2, sequence):
                            minLen = min(len(sequence), len(sequence2))+1
                            print minLen
                            print goal, ", ", goal2
                            print sequence, sequence2
                            if maxLeaves<minLen:
                                print goal, ", ", goal2
                                print goal2, ", ", goal
                                print sequence2, "<", sequence
                                maxLeaves=minLen
                            answer=False
            
    return answer        
    
def contains(small, big):
    for i in range(min([len(small),len(big)])):
        #print small[i],big[i]
        if small[i].get()!=big[i].get():
            return False
    return True      

    
def wcd(PL, goals):
    global maxLeaves
    maxLeaves = 0
    openList = deque()
    closed = []
    
    # init open with possible goals
    for goal in goals:
        g = Tree("Complex", goal, [], children=[], PL=PL)
        openList.append(Node(g))
    i=0
        
    # extend one level in the open
    while not checkDistinctiveness(openList):
        #print "Here1"
        newOpen = deque()
        newNodesExtended = False
        while len(openList)!=0:
            node = openList.popleft()
            tree = node.getTree()
            frontier = tree.getFrontier(withIndices=True)
            if len(frontier)==0:
                newOpen.append(node)
                continue
            else:
                newNodesExtended=True
            for action in frontier:
                actionName = action[0].getRoot()
                actionIndex = action[1]
                for rule in PL._P:
                    if rule._A.get()==actionName.get():
                        newTree = tree.myCopy()
                        newNode = Node(newTree, node.getObservations()[:])
     #                   print "newTree=", newTree                    
                        children=[]
                        for child in rule._alpha:
                            if type(child)==NT:
                                children.append(Tree("Complex", child, rule))
                            else:
                                childTree = Tree("Basic", child, rule)
                                childTree._isComplete=True
                                children.append(childTree)
                                newNode.addObservation(child)
                            
                        
                        newSubtree=Tree("Complex", actionName, rule, children)
                            
                        if actionIndex=='' or actionIndex=='-1':
                            newTree = newSubtree
                            newNode.setTree(newSubtree)
                        else:
                            newTree = newTree.substituteWithNode(newSubtree,actionIndex)
                        newOpen.append(newNode)
                        #print open
    #                     else:
    #                         print "Error - child name not as expected"
            if node not in closed:
                closed.append(node)
        openList=newOpen
#         print len(newOpen)
        
        expandedFile = open("C:\Users\Owner\Desktop\expanded.csv", "a+")
        res = len(newOpen)
        expandedFile.write(","+str(res))
        expandedFile.close()
        
        if not newNodesExtended:
            return maxLeaves
        i+=1
    
    return maxLeaves

def wcpd(PL, goals):
    global maxLeaves
    maxLeaves = 0
    openList = deque()
    closed = []
    
    # init open with possible goals
    for goal in goals:
        g = Tree("Complex", goal, [], children=[], PL=PL)
        openList.append(Node(g))
    i=0
        
    # extend one level in the open
    while not checkPlanDistinctiveness(openList):
        #print "Here1"
        newOpen = deque()
        newNodesExtended = False
        while len(openList)!=0:
            node = openList.popleft()
            tree = node.getTree()
            frontier = tree.getFrontier(withIndices=True)
            if len(frontier)==0:
                newOpen.append(node)
                continue
            else:
                newNodesExtended=True
            for action in frontier:
                actionName = action[0].getRoot()
                actionIndex = action[1]
                for rule in PL._P:
                    if rule._A.get()==actionName.get():
                        newTree = tree.myCopy()
                        newNode = Node(newTree, node.getObservations()[:])
     #                   print "newTree=", newTree                    
                        children=[]
                        for child in rule._alpha:
                            if type(child)==NT:
                                children.append(Tree("Complex", child, rule))
                            else:
                                childTree = Tree("Basic", child, rule)
                                childTree._isComplete=True
                                children.append(childTree)
                                newNode.addObservation(child)
                            
                        
                        newSubtree=Tree("Complex", actionName, rule, children)
                            
                        if actionIndex=='' or actionIndex=='-1':
                            newTree = newSubtree
                            newNode.setTree(newSubtree)
                        else:
                            newTree = newTree.substituteWithNode(newSubtree,actionIndex)
                        newOpen.append(newNode)
                        #print open
    #                     else:
    #                         print "Error - child name not as expected"
            if node not in closed:
                closed.append(node)
        openList=newOpen
        #print len(newOpen)
        
        expandedFile = open("C:\Users\Owner\Desktop\expanded.csv", "a+")
        res = len(newOpen)
        expandedFile.write(","+str(res))
        expandedFile.close()
        
        if not newNodesExtended:
            return maxLeaves
        i+=1
    
    return maxLeaves
   
def createDomain(stringObs, instanceToRun):
    global AllNTs
    global AllRulesAsList
    
    Sigmas=[]
    NTs=[]
    Goals=[]
    i=0
    
    currentLine = stringObs[1:-1]
    delimiters = getDelimiters(currentLine)
    del1 = delimiters[0]-2
    del2 = delimiters[1]+1
    i=1
    while True:
        #currentLetter = 1
        #currentNumber = 1#{letter: 1 for letter in Letters2.split(" ")}
        singleProblem = currentLine[del1+2:del2]
#        print singleProblem
        
        probDels = getDelimiters(singleProblem)[0]
        recipeLibrary = singleProblem[:probDels]
        observations = singleProblem[probDels+4:-1]
        
        if i==instanceToRun:
            parseRecipeLibrary(recipeLibrary)
        
        i+=1
        del1=del2+1
        if i==len(delimiters)+1:
            break
        elif i==len(delimiters):
            del2=len(delimiters)-1
        else:        
            del2=delimiters[i]+1
        if i==len(delimiters):
            break
    
    for i in range(100):
        Sigmas.append(Sigma("A"+str(i+1)))
    
    for nt in AllNTs:
        if nt[0]=="*":
            Goals.append(NT(nt[1:]))
            NTs.append(NT(nt[1:]))
        else:
            NTs.append(NT(nt))
    
#     realGoal = Goals[int(stringObs[0][1:-1])]
#     for obs in stringObs[1:]:  
#         if len(obs)>1:
#             if obs[len(obs)-1]=='\n':
#                 obs = obs[:-1]
#             Observations.append(Sigma(obs))
#             print obs
            
    newPL = PL(Sigmas, NTs, Goals, AllRulesAsList)
    return newPL
    

def reduceDistinctiveness(pl, goals):
    global goalsExpanded
    basicWcd = wcpd(pl, goals)
    bestWcd = basicWcd
    bestPL = pl
    openList = deque()
    openList.append(pl)
    depth=len(pl._P)
    while depth!=len(pl._P)-1:
        wcdFile = open("C:\Users\Owner\Desktop\wcpdFile.csv", "a+")
        wcdFile.write(str(depth)+",")
        wcdFile.close()
        #print "Here2"
        depth-=1
        newOpen = deque()
        #while len(openList)!=0:
            #print "Here3"
        currentPL = openList.popleft()
        for i in range(len(currentPL._P)):
            print i
            print currentPL._P[i]
            newPL = currentPL.halfShallowCopy()
            del newPL._P[i]
            newWcd = wcpd(newPL, goals)
                #print newWcd
                #print currentPL._P[i]
                #print goalsExpanded
#                if goalsExpanded==len(goals):
            if newWcd<bestWcd and goalsExpanded==len(goals):
                bestWcd=newWcd
                bestPL=newPL
                print bestPL
                if bestWcd==0:
                    return bestWcd, bestPL 
            newOpen.append(newPL)

        if len(newOpen)==0:
            break
        else:
            #print len(newOpen)
            openList=newOpen
            
    return bestWcd, bestPL

    
def mainReduction():#main():#
    global basicPL
    domainFile = open("C:\\Users\\Owner\\Desktop\\ExampleDomain.txt", "r")
    domainString = domainFile.read()
    myPL = createDomain(domainString, int(sys.argv[1]))
    #myPL = initPL()
    basicPL=myPL
    print basicPL
    
    start_time = time.time()
    wcdFile = open("C:\Users\Owner\Desktop\wcpdFile.csv", "a+")
    timeFile = open("C:\\Users\\Owner\\Desktop\\timeFile.csv", "a+")
    PLFile = open("C:\Users\Owner\Desktop\pl.txt", "a+")

    resWcd, resPL = reduceDistinctiveness(myPL, myPL.getGoals())
    elapsed_time = time.time() - start_time  
    resWcpd = wcpd(resPL, myPL.getGoals())  
    wcdFile.write(str(sys.argv[1])+","+str(resWcd)+","+str(resWcpd)+"\n")  
    wcdFile.close()
    timeFile.write(str(sys.argv[1])+","+str(elapsed_time)+"\n")  
    timeFile.close()
    PLFile.write(str(resPL))
    PLFile.close()

def main():#mainWCD_WCPD():
    global maxLeaves
    global basicPL
    #domainFile = open("C:\\Users\\Owner\\Desktop\\ExampleDomain.txt", "r")
    #domainString = domainFile.read()
    #myPL = createDomain(domainString, int(sys.argv[1]))
    myPL = initPL()

    basicPL=myPL
    #print myPL
    #print "*************************"
    #     
    #     obsPerChild=[["Position"], ["TurnWithBall", "TurnWithoutBall"]]
    #     rule = myPL._P[10]
    #     createPermutationsNoInterleaving(obsPerChild, rule)
    start_time = time.time()
    wcdFile = open("C:\Users\Owner\Desktop\wcpdFile.csv", "a+")
    timeFile = open("C:\\Users\\Owner\\Desktop\\timeFile.csv", "a+")
    res = wcd(myPL, myPL.getGoals())
    elapsed_time = time.time() - start_time
    print "wcd, time=", res, elapsed_time
    res = wcpd(myPL, myPL.getGoals())
    elapsed_time = time.time() - elapsed_time
    print "wcpd, time=", res, elapsed_time
    
    wcdFile.write(str(sys.argv[1])+","+str(res)+"\n")  
    wcdFile.close()
    timeFile.write(str(sys.argv[1])+","+str(elapsed_time)+"\n")  
    timeFile.close()
    expandedFile = open("C:\Users\Owner\Desktop\expanded.csv", "a+")
    expandedFile.write("\n")
    expandedFile.close()

   
if __name__ == '__main__': main()        