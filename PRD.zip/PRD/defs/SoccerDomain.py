import Algorithm
import Explanation
import Sigma
import NT
import Rule
import PL

def initPL():
    
    # Sigmas
    sigma_Clear = Sigma.Sigma('Clear', [])
    sigma_ApproachBall = Sigma.Sigma('ApproachBall', [])
    sigma_TurnWithBall = Sigma.Sigma('TurnWithBall', [])
    sigma_TurnWithoutBall = Sigma.Sigma('TurnWithoutBall', [])
    sigma_Pass = Sigma.Sigma('Pass', [])
    sigma_Kick = Sigma.Sigma('Kick', [])
    sigma_Position = Sigma.Sigma('Position', [])
    

    # NTs
    NT_Defend = NT.NT('Defend', [])
    NT_Tactic = NT.NT('Tactic', [])
    NT_Position = NT.NT('Position', [])
    NT_Pass = NT.NT('Pass', [])
    NT_Kick = NT.NT('Kick', [])
    NT_Charge = NT.NT('Charge', [])
    NT_Goal = NT.NT('Goal', [])
    NT_Attack = NT.NT('Attack', [])
    NT_Score = NT.NT('Score', [])
    NT_Turn = NT.NT('Turn', [])
    
    # Real Rules
    #Defend -> Position, Turn, Tactic, Position
    rule1 = Rule.Rule(NT_Defend, [NT_Position, NT_Turn, NT_Tactic, NT_Position], [(0,1),(1,2),(2,3)], [])
    #Tactic -> Clear
    rule2 = Rule.Rule(NT_Tactic, [sigma_Clear], [], [])
    #Tactic -> ApproachBall
    rule3 = Rule.Rule(NT_Tactic, [sigma_ApproachBall], [], [])
    #Turn -> TurnWithBall
    rule4 = Rule.Rule(NT_Turn, [sigma_TurnWithBall], [], [])
    #Turn -> TurnWithoutBall
    rule5 = Rule.Rule(NT_Turn, [sigma_TurnWithoutBall], [], [])
    #Pass -> Pass
    rule6 = Rule.Rule(NT_Pass, [sigma_Pass], [], [])
    #Kick -> Kick
    rule7 = Rule.Rule(NT_Kick, [sigma_Kick], [], [])
    #Position -> Position
    rule8 = Rule.Rule(NT_Position, [sigma_Position], [], [])
    #Charge -> Attack
    rule9 = Rule.Rule(NT_Charge, [NT_Attack], [], [])
    #Goal -> Attack, Score
    rule10 = Rule.Rule(NT_Goal, [NT_Attack, NT_Score], [(0,1)], [])
    #Attack -> Position, Turn
    rule11 = Rule.Rule(NT_Attack, [NT_Position, NT_Turn], [(0,1)], [])
    #Attack -> Pass
    rule12 = Rule.Rule(NT_Attack, [NT_Pass], [], [])
    #Score -> Position, Turn
    rule13 = Rule.Rule(NT_Score, [NT_Position, NT_Turn], [(0,1)], [])
    #Score -> Kick
    rule14 = Rule.Rule(NT_Score, [NT_Kick], [], [])
    
    sigmas = [sigma_Clear, sigma_ApproachBall, sigma_TurnWithBall, sigma_TurnWithoutBall, sigma_Pass, sigma_Kick, sigma_Position]
    nts = [NT_Defend, NT_Tactic, NT_Position, NT_Pass, NT_Kick, NT_Charge, NT_Goal, NT_Attack, NT_Turn, NT_Score]
    goals = [NT_Defend, NT_Charge, NT_Goal]
    rules = [rule1, rule2, rule3, rule4, rule5, rule6, rule7, rule8, rule9, rule10, rule11, rule12, rule13]
    return PL.PL(sigmas, nts, goals, rules)


def main():
    sigma1 = Sigma.Sigma('Position')
    sigma2 = Sigma.Sigma('TurnWithoutBall')
    sigma3 = Sigma.Sigma('Clear')
    
    exps = Algorithm.ExplainAndCompute(initPL(), [sigma1, sigma2, sigma3])
    
    for exp in exps:
        print exp
    
    
    
    
    
if __name__ == '__main__': main()