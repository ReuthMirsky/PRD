from copy import deepcopy
class Node(object):

	
	def __init__(self, tree, seq=[], rules=[]):
		self._tree = tree  
		self._sequence = seq
		self._rules = rules

	def __repr__(self, *args, **kwargs):
		strToPrint = "Node:"
		strToPrint+=str(self._tree)
		return strToPrint
	
	def __eq__(self, other):
		if len(self._tree.getRules())!=len(other._tree.getRules()):
			return False
		for rule in self._tree.getRules():
			if rule not in other._tree.getRules():
				return False
		return True
		
	def myCopy(self):
		newone = type(self)(self._tree.myCopy())
		#for obs in self._sequence:
		newone._sequence = self._sequence[:]
		newone._rules = self._rules[:]
		return newone
			
	def getTree(self):
		return self._tree
	
	def setTree(self, tree):
		self._tree = tree
	
	def addObservation(self, obs):
		self._sequence.append(obs)
		
	def getObservations(self):
		return self._sequence
	
	def addRule(self, rule):
		self._rules.append(rule)
		
	def getRules(self):
		return self._rules
		
	def getExpand(self):
		return self.getExpand()
	
	def setExpand(self, boolVal):
		return self.setExpand(boolVal)