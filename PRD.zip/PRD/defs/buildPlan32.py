#!/usr/bin/env python
import sys
#import getopt
#import os
import re
import random

#import time
#import xlrd3
#import xml.dom
from xml.dom import minidom   
from copy import deepcopy
import math


#from xmlrpc.client import MAXINT
#from warnings import catch_warnings
from Algorithm import Algorithm
from Sigma import Sigma
from NT import NT
from Rule import Rule
from PL import PL
from Explanation import Explanation

#---------------------------------classes----------------------------------------------------------------------
class action:
    def __init__(self, name, ids, pcons, remove):
        self.name = name # is the name of an action
        self.ids = ids # is a dictionary from ids to their values
        self.pcons = pcons # is a list of precondition action indices in the rhs of the recipe
        self.children = [] # is a list of children actions (used in tree outputting)
        self.index = 0 # index into the log, for low level ones
        self.minIndexBelow = 0 # min index into the log, for high level ones
        self.remove=remove #remove indicates whether the action should be removed from the log after being matched to a recipe
        self.id_num=0
        self.uniqueID=random.randint(1,100000)
        self.posInSM = 0
        
    def __str__(self):
        ret = '%s[' %self.name
        for key in self.ids:
            if self.ids[key]:
                ret += '%s:%s,' %(key, self.ids[key]) # if key[1] not None
            else:
                ret += '%s,' %key
        if ret[-1] == ',': ret = ret[:-1]
        ret = '%s]' %ret
        return ret
    
    def __eq__(self, other):
        if (other.uniqueID==self.uniqueID):
            return 1
        else:
            return 0
        
    def toxml(self):
        ret = '<%s ' %self.name
        ids = list(self.ids.keys())
        ids.sort()
        for key in ids:
            ret += '%s=\"%s\" ' %(key, self.ids[key]) # if key[1] not None
        ret += 'pos=\"%d\">' %(self.getIndex()-1) # swapna uses 0-based indices
        return ret
        
    def toxmlleaf(self):
        ret = '<%s ' %self.name
        ids = list(self.ids.keys())
        ids.sort()
        for key in ids:
            ret += '%s=\"%s\" ' %(key, self.ids[key]) # if key[1] not None
        ret += 'pos=\"%d\"/>' %(self.getIndex()-1) # swapna uses 0-based indices
        return ret
    
    def getIndex(self):
        if self.index: return self.index
        elif self.minIndexBelow: return self.minIndexBelow
        else: raise
    
    def addChild(self, child):
        self.children.append(child)
        index = child.getIndex()
        #id_num = child.id_num
        if self.minIndexBelow == 0 or self.minIndexBelow > index:
            self.minIndexBelow = index
            
        
class recipe:
    def __init__(self, lhs, rhs, num,cons, effects):
        self.lhs = lhs # is an action object
        self.rhs = rhs # is a list of action objects
        self.num=num
        self.cons = cons #constraints between actions
        self.effects = effects #effects on the complex action
        
        
    def __str__(self):
        ret = '%s -> ' %(self.lhs.__str__())
        for x in self.rhs: ret += '%s ' %(x.__str__())
        return ret[:-1]
    
#    def checkDependencies(self):
#        for i in range(len(self.rhs)):
#            for j in range(i+1, len(self.rhs)):
#                intersection=[x for x in self.rhs[j].ids if x in self.rhs[i].ids]
                

class match:
    """The match class is composed of a dictionary of the actions in the match and their indices in the recipe they match"""
    #constructor
    def __init__(self, lastIndex):
        self.actions={}
        self.lastIndex=lastIndex
        
    #adds an action to the match    
    def addAction(self, action, index):
        self.actions[index]=action
        if (action.id_num>self.lastIndex):
            self.lastIndex=action.id_num
            
    def removeAction(self, index):
        del self.actions[index]
            
    #checks if the match already contains an action which fulfills the recipe action with specified index
    def containsIndex(self, index):
        return index in list(self.actions.keys())
   
   
class priorityQueueOfMatches:
    def __init__(self):
        self.heap = []
        
  
    def parent(self, index):
        """
        Parent will be at math.floor(index/2). Since integer division
        simulates the floor function, we don't explicitly use it
        """
        return math.floor(index / 2)
    
    
    def left_child(self, index):
        """ 1 is added because array begins at index 0 """
        return 2 * index + 1


    def right_child(self, index):
        return 2 * index + 2
    

    def max_heapify(self, index):
        """
        Responsible for maintaining the heap property of the heap.
        This function assumes that the subtree located at left and right
        child satisfies the max-heap property. But the tree at index
        (current node) does not. O(log n)
        """
        left_index = self.left_child(index)
        right_index = self.right_child(index)
        
        largest = index
        if left_index < len(self.heap) and ((self.heap[left_index][0][0] < self.heap[index][0][0]) or (self.heap[left_index][0][0] == self.heap[index][0][0] and self.heap[left_index][0][1] < self.heap[index][0][1])):
            largest = left_index
        if right_index < len(self.heap) and ((self.heap[right_index][0][0] < self.heap[largest][0][0]) or (self.heap[right_index][0][0] == self.heap[largest][0][0] and self.heap[right_index][0][1] < self.heap[largest][0][1])):
            largest = right_index
            
        if largest != index:
            self.heap[index], self.heap[largest] = self.heap[largest], self.heap[index]
            self.max_heapify(largest)


    def build_max_heap(self):
        """
        Responsible for building the heap bottom up. It starts with the lowest non-leaf nodes
        and calls heapify on them. This function is useful for initialising a heap with an
        unordered array. O(n)
        """
        for i in range(len(self.heap)/2, -1, -1):
            self.max_heapify(i)


    def heap_sort(self):
        """ The heap-sort algorithm with a time complexity O(n log n) """
        self.build_max_heap()
        output = []
        for i in range(len(self.heap)-1, 0, -1):
            self.heap[0], self.heap[i] = self.heap[i], self.heap[0]
            output.append(self.heap.pop())
            self.max_heapify(0)
        output.append(self.heap.pop())
        self.heap = output
  
        
    def propagate_up(self, index):
        """ Compares index with parent and swaps node if larger O(log(n)) """
        while index != 0 and ((self.heap[self.parent(index)][0][0] > self.heap[index][0][0]) or (self.heap[self.parent(index)][0][0] == self.heap[index][0][0] and self.heap[self.parent(index)][0][1] > self.heap[index][0][1])):
            self.heap[index], self.heap[self.parent(index)] = self.heap[self.parent(index)], self.heap[index]
            index = self.parent(index)    


    def add(self, key):
        """ Adds an element in the heap O(ln(n)) """
        self.heap.append(key)
        self.propagate_up(len(self.heap) - 1) # Index value is 1 less than length


    def extract_min(self):
        """
        Part of the Priority Queue, extracts the element on the top of the heap
        and then re-heapifies. O(log n)
        """
        maxVal = self.heap[0]
        data = self.heap.pop()
        if len(self.heap) > 0:
            self.heap[0] = data
            self.max_heapify(0)
        return maxVal


    def increment(self, key, value):
        """ Increments key by the input value. O(log n) """
        for i in range(len(self.heap)):
            if self.heap[i][1] == key[1]:
                self.heap[i][0] += value
                self.propagate_up(i)
                break

#---------------------------------classes end----------------------------------------------------------------------
    
#-------------------------------algorithm methods----------------------------------------------------
def checkActionsConstraints(match, new_action, recipe, index):
    
    #check constraints with respect to recipe
    rec_act= recipe.rhs[index]
    for param in rec_act.ids:
        if (rec_act.ids[param] is not None):
            if not (new_action.ids[param]==rec_act.ids[param]):
                return False
            
    #action fits recipe, if no other actions are already in match - nothing more to check        
    if (len(match.actions)==0):
        return True
    
    #go over constraints between actions
    
    cons = recipe.cons
    for con in cons:
        left = con[0]
        right = con[1]
        #check if new action fits one of the constraints
        if (index==int(right[0])):
            if int(left[0]) in list(match.actions.keys()):
                act = match.actions[int(left[0])]
                if (not right[1] in new_action.ids):
                    continue #asfadsf=3434
                if new_action.ids[right[1]]!=act.ids[left[1]]:
                    return False
        elif index==int(left[0]):
            if int(right[0]) in list(match.actions.keys()):
                act = match.actions[int(right[0])]
                if new_action.ids[left[1]]!=act.ids[right[1]]:
                    return False
    return True

def extends(action, match, recipe):
    """recives an action, current match and recipe. checks if the action can extend the match"""
    res=False
    ext=True
    for i in range(len(recipe.rhs)):
        curr_act=recipe.rhs[i]
        if(action.name==curr_act.name):
            index=i
            if (match is not None):
                if not (match.containsIndex(i)): #checks that the matching action in the recipe has not yet been fulfilled 
                    #check that all preconditions for this action are fulfilled
                    for j in range(len(curr_act.pcons)):
                        if not (match.containsIndex(j)):
                            ext=False
                            break;
                    if (ext==False):
                        break;
                    #check constraints in respect with other actions in the match
                    res=checkActionsConstraints(match, action, recipe, index)
                    if res is True:
                        return index
                
    return -1

def fulfills(match, recipe):
    """check if the recipe is fulfilled by the match"""
    if match is None:
        return False
        
    for i in range(len(recipe.rhs)):
        if not (match.containsIndex(i)):
                return False
    return True
    
                    
def findMatch(rc, ol, priorityMatches):
    """depth first search for actions in the log which match the given recipe"""
    ol_new=deepcopy(ol)
    #go over actions in log, for each action, try to add it to the current match. backtrack if failed
    for act in ol:
        mc = match(0)
        curr_act=findAction(act, ol_new)
        ol_new.remove(curr_act)
        index=extends(curr_act, mc, rc)
        if (index>-1):
            #the action can be added to the match, update its parameters (ie make sid sid_1, etc.)
            for param in list(curr_act.ids.keys()):
                for rec_param in rc.rhs[index].ids:
                    if (param==rec_param):
                        curr_act.ids[rec_param]=curr_act.ids[param]
                        if not (rec_param==param):
                            del curr_act.ids[param]
                        break
            mc.addAction(curr_act,index )
            if (fulfills(mc, rc)):
                priorityMatches.add(((computeDistance(mc),mc.lastIndex),(mc,rc)))
                continue;   
            
            for newAct in ol_new:
                newMc = deepcopy(mc)
                curr_act=findAction(newAct, ol_new)
                index=extends(curr_act, newMc, rc)
                if (index>-1):
                    #the action can be added to the match, update its parameters (ie make sid sid_1, etc.)
                    for param in list(curr_act.ids.keys()):
                        for rec_param in rc.rhs[index].ids:
                            if (param==rec_param):
                                curr_act.ids[rec_param]=curr_act.ids[param]
                                if not (rec_param==param):
                                    del curr_act.ids[param]
                                break
                    newMc.addAction(curr_act,index )
                    if (fulfills(newMc, rc)  and (newMc.actions[0].id_num <= newMc.actions[1].id_num)):
                        priorityMatches.add(((computeDistance(newMc),newMc.lastIndex),(newMc,rc)))



def findMatchForAction(rc, ol, priorityMatches, currAct):
    """depth first search for actions in the log which match the given recipe"""
    ol_new=deepcopy(ol)
    
    mc = match(0)
    curr_act=findAction(currAct, ol_new)
    ol_new.remove(curr_act)
    index=extends(curr_act, mc, rc)
    if (index>-1):
        #the action can be added to the match, update its parameters (ie make sid sid_1, etc.)
        for param in list(curr_act.ids.keys()):
            for rec_param in rc.rhs[index].ids:
                if (param==rec_param):
                    curr_act.ids[rec_param]=curr_act.ids[param]
                    if not (rec_param==param):
                        del curr_act.ids[param]
                    break
        mc.addAction(curr_act,index )
        if (fulfills(mc, rc)):
            priorityMatches.add(((computeDistance(mc),mc.lastIndex),(mc,rc))) 
        else:    
            for newAct in ol_new:
                newMc = deepcopy(mc)
                curr_act=findAction(newAct, ol_new)
                index=extends(curr_act, newMc, rc)
                if (index>-1):
                    #the action can be added to the match, update its parameters (ie make sid sid_1, etc.)
                    for param in list(curr_act.ids.keys()):
                        for rec_param in rc.rhs[index].ids:
                            if (param==rec_param):
                                curr_act.ids[rec_param]=curr_act.ids[param]
                                if not (rec_param==param):
                                    del curr_act.ids[param]
                                break
                    newMc.addAction(curr_act,index )
                    if (fulfills(newMc, rc) and (newMc.actions[0].id_num <= newMc.actions[1].id_num)):
                        priorityMatches.add(((computeDistance(newMc),newMc.lastIndex),(newMc,rc)))
                        
    ol_new=deepcopy(ol)
    #remove the currAct from the ol.
    curr_actInOL=findAction(currAct, ol_new)
    ol_new.remove(curr_actInOL)
    #go over actions in log, for each action, try to add it to the current match. backtrack if failed
    for act in ol_new:
        mc = match(0)
        curr_act=findAction(act, ol_new)
        index=extends(curr_act, mc, rc)
        if (index>-1):
            #the action can be added to the match, update its parameters (ie make sid sid_1, etc.)
            for param in list(curr_act.ids.keys()):
                for rec_param in rc.rhs[index].ids:
                    if (param==rec_param):
                        curr_act.ids[rec_param]=curr_act.ids[param]
                        if not (rec_param==param):
                            del curr_act.ids[param]
                        break
            mc.addAction(curr_act,index )  
            
            newMc = deepcopy(mc)
            index=extends(curr_actInOL, newMc, rc)
            if (index>-1):
                #the action can be added to the match, update its parameters (ie make sid sid_1, etc.)
                for param in list(curr_actInOL.ids.keys()):
                    for rec_param in rc.rhs[index].ids:
                        if (param==rec_param):
                            curr_actInOL.ids[rec_param]=curr_actInOL.ids[param]
                            if not (rec_param==param):
                                del curr_actInOL.ids[param]
                            break
                newMc.addAction(curr_actInOL,index )
                if (fulfills(newMc, rc) and (newMc.actions[0].id_num <= newMc.actions[1].id_num)):
                    priorityMatches.add(((computeDistance(newMc),newMc.lastIndex),(newMc,rc)))

def buildPlan(recipes, log):
    """calls findMatch to match actions with recipes, iteratively builds a plan"""
    priorityMatches = priorityQueueOfMatches()
    p={}
    p[0]=deepcopy(log)
    ol=deepcopy(p[0])
    numAct = 1;
    for act in ol:
        act.posInSM = numAct
        numAct = numAct + 1
    i=1
    for rc in recipes:
        findMatch(rc, ol, priorityMatches)
        
    if (len(priorityMatches.heap) > 0):
        thereMatches = True
    else:
        thereMatches = False
        
    actionsUsed = []    
    while (thereMatches):   
        mc,rc = priorityMatches.extract_min()[1]
                     
        if (len(priorityMatches.heap) > 0):
            thereMatches = True
        else:
            thereMatches = False
            
        #check if the actions were used already
        isUsed = False
        for a in mc.actions: #iterates over the children of the complex action in the match
            if (not findAction(mc.actions[a], actionsUsed) is None):
                isUsed = True
        if(isUsed == True):
            continue
        
        c=deepcopy(rc.lhs)
        updateParams(c, mc, rc) # updates the parameters of the complex action
        c.id_num=mc.lastIndex
        
        p[i]=deepcopy(p[i-1])
        ol=deepcopy(p[i-1])
        
        p[i].insert(findActionIndex(mc.lastIndex,p[i])+1, c) # inserts the complex action to the current "P" (i.e. current list of actions)
        ol.insert(findActionIndex(mc.lastIndex,ol)+1, c) # inserts complex action to the current open list we're modifying
        for a in mc.actions: #iterates over the children of the complex action in the match
            actionsUsed.append(mc.actions[a])
            c.addChild(mc.actions[a]) # add child to complex action
            #need to add the remove attribute, and make sure it appears in the action that goes in to the match
            if (rc.rhs[a].remove is True): #check if this action is supposed to stay in log - Oriel, this condition is always true (we used to have situation where it wasn't but not relevant now)
                toRemove=findAction(mc.actions[a], p[i])
                p[i].remove(toRemove) # remove the action from the current plan 
                ol.remove(toRemove) # remove the action from current open linst
                
        for rc in recipes:
            findMatchForAction(rc, ol, priorityMatches, c)
        i=i+1

    return p    

#-------------------------------algorithm methods end----------------------------------------------------


#-------------------------------utility methods----------------------------------------------------
def computeDistance(mc):
    dist = 0
    if (len(mc.actions) > 0):
        minIndex = mc.actions[0].posInSM
        maxIndex = mc.actions[0].posInSM
        for a in mc.actions: #iterates over the children of the complex action in the match
            pos = mc.actions[a].posInSM
            if (pos > maxIndex):
                maxIndex = pos
            if (pos < minIndex):
                minIndex = pos
        dist = maxIndex - minIndex
    return dist
                    

#def findIndexOfAction(action, ol):
#    for act in ol:
#        sad
#    return index


def findAction(action, _list):
    for ac in _list:
        if (action==ac):
            return ac
    return None
    
def findActionIndex(num, _list):
    for ac in _list:
        if (num==ac.id_num):
            return _list.index(ac)
    return None

def updateParams(comp_action, match, rc):
    """when a match is found, need to update the parameters of the complex action created"""
    j=0;
    comp_action.uniqueID=random.randint(0,100000)
    """
    compName = "C"
    if (len(rc.cons) >0):
        leftCons=['0','did']
        rightCons=['1','sid']
        if (leftCons == rc.cons[0][0] and rightCons == rc.cons[0][1]):
            compName = "D"
        else:
            leftCons=['0','did']
            rightCons=['1','did']
            if (leftCons == rc.cons[0][0] and rightCons == rc.cons[0][1]):
                compName = "C"
    if (compName=='C' and len(match.actions)==2):
        a=float(match.actions[0].ids['vol'])
        b=float(match.actions[1].ids['vol'])
        comp_action.ids['vol']=float(match.actions[0].ids['vol'])+float(match.actions[1].ids['vol'])
    """
  
    """  
    if(compName=="D"):
        k=5
    """
    comp_action.posInSM = 0
    for action in list(match.actions.values()):
        for param in list(action.ids.keys()):
            if (param in comp_action.ids):
                del comp_action.ids[param];
                comp_action.ids[param]=action.ids[param]
                j=j+1
        comp_action.posInSM = max(comp_action.posInSM,action.posInSM)   
    #apply the effects
    for eff in rc.effects:
        actionsOfMatch = list(match.actions.values())
        #print(actionsOfMatch[int(eff[1][0][0])])
        #print(comp_action.ids[eff[0][0]])
        #print(actionsOfMatch[int(eff[1][0][0])].ids[eff[1][1][0]])
        comp_action.ids[eff[0][0]] = actionsOfMatch[int(eff[1][0][0])].ids[eff[1][1][0]]
        if (len(eff) > 2):
            for index in range(2, len(eff)):
                comp_action.ids[eff[0][0]] =  float(comp_action.ids[eff[0][0]]) + float(actionsOfMatch[int(eff[index][0][0])].ids[eff[index][1][0]])
        #ads=123
    
    return

def findLastIndex(mc,ol):
    index=0
    for a in mc.actions:
        i=ol.index(a)
        if (i<index):
            index=i
    return index

# print tree by xml
def printXML(log, start):
    for a in log:
        if a.name == start:
            printXML2(a, 0)
    
def printXML2(a, indent):
    print('%s%s' %('\t'*indent, a.toxml()))

    indices = []
    for child in a.children:
        indices.append(child.getIndex())
    d = {}
    for i in range(len(indices)):
        d[indices[i]] = i
    indices.sort()
        
    # to output in the order in the recipes simply do:
    # for child in a.children():
    
    for index in indices:
        child = a.children[d[index]]
        if child.children: # if you have grand children
            printXML2(child, indent+1)
        else: # if your child is a leaf
            print('%s%s' %('\t'*(indent+1), child.toxmlleaf()))

    print('%s</%s>' %('\t'*indent, a.name))

        
        
# str is something like A[x_1,y][0,1]
# which represents an action A parametrized by x_1 and y and has the precondition actions indexed 0 and 1 in the recipe
# so this action A should have index >= 2 in the recipe
# if the thing is not parametrized or has preconditions then A[][] should work for str
def parseAction(my_str):
    
    remove=True
    pat = re.compile('([A-Za-z0-9]+)\[(.*?)\]\[(.*?)\]')
    my_str = pat.sub('\g<1>~\g<2>~\g<3>', my_str)
    my_str = my_str.split('~')
    name = my_str[0]
    
    d = {} # dictionary for ids
    if my_str[1]:
        ids = my_str[1].split(',')
        for x in ids:
            if x.find(':') != -1: (x1,x2) = x.split(':') # (like [x:R])
            else: (x1,x2) = (x,None) # (like [x])
            
            j = x1.find('_')
            if j != -1: d[x1[:j]] = x2 # (like [x_1: ... ])
            else: d[x1] = x2 # (like [x: ... ])
    
    if 'leave' in d:
        remove=False
    l = [] # list for preconditions
    if my_str[2]:
        pcons = my_str[2].split(',')
        for p in pcons:
            l.append(int(p))
    
    return action(name, d, l, remove)
    
#-------------------------------utility methods end----------------------------------------------------

#-------------------------------log processing methods--
class actionForLog:
    def __init__(self, name, ids, pcons):
        self.name = name # is the name of an action
        self.ids = ids # is a dictionary from ids to their values
        self.pcons = pcons # is a list of precondition action indices in the rhs of the recipe
        self.children = [] # is a list of children actions (used in tree outputting)
        self.index = 0 # index into the log, for low level ones
        self.minIndexBelow = 0 # min index into the log, for high level ones
        
    def __str__(self):
        ret = '( %s' %self.name
        for key in self.ids:
            if self.ids[key]:
                ret += ' , %s=%s' %(key, self.ids[key]) # if key[1] None
            else:
                if key: ret += '%s' %(key)
                else: ret += '%s' %key
        if ret[-1] == ' , ': ret = ret[:-1]
        ret = '%s )' %ret
        return ret
        
    def toxml(self):
        ret = '<%s ' %self.name
        ids = list(self.ids.keys())
        ids.sort()
        for key in ids:
            if self.ids[key]:
                if key[1]: ret += '%s=\"%s\" ' %(key, self.ids[key]) # if key[1] not None
                else: ret += '%s=\"%s\" ' %(key, self.ids[key]) # if key[1] None
            else:
                if key[1]: ret += '%s ' %(key)
                else: ret += '%s ' %key
        ret += 'pos=\"%d\">' %(self.getIndex()-1) # swapna uses 0-based indices
        return ret
        
    def toxmlleaf(self):
        ret = '<%s ' %self.name
        ids = list(self.ids.keys())
        ids.sort()
        for key in ids:
            if self.ids[key]:
                if key: ret += '%s=\"%s\" ' %(key, self.ids[key]) # if key[1] not None
                else: ret += '%s=\"%s\" ' %(key, self.ids[key]) # if key[1] None
            else:
                if key[1]: ret += '%s ' %(key)
                else: ret += '%s ' %key
        ret += 'pos=\"%d\"/>' %(self.getIndex()-1) # swapna uses 0-based indices
        return ret
    
    def getIndex(self):
        if self.index: return self.index
        elif self.minIndexBelow: return self.minIndexBelow
        else: raise
    
    def addChild(self, child):
        self.children.append(child)
        index = child.getIndex()
        if self.minIndexBelow == 0 or self.minIndexBelow > index:
            self.minIndexBelow = index
    def getName(self):
        return self.name
    def getParams(self):
        return self.ids
            

def parseSolMix(line):
    
    params={}
    words=line.split()
    params["vol"]=words[0]
    st_start=words.index("from")+1
    s_type=words[st_start]
    for i in range(st_start+1, len(words)):
        if not(words[i].startswith("(")):
            s_type=s_type+" "+words[i]
        else:
            sid=words[i].strip("(,)")
            break
        
    params["st"]=s_type
    params["sid"]=sid
    s_con_det=""
    sc_start=words.index("contains")+1
    s_con=words[sc_start]
    for i in range(sc_start+1, len(words)):
        if not(words[i].startswith("(")):
            s_con=s_con+"_"+words[i]
        else:
            for j in range(i, len(words)):
                if not(words[j].endswith(";")):
                    s_con_det=s_con_det+" "+words[j].strip("(")
                else:
                    s_con_det=s_con_det+" "+words[j].strip(";")
                    break
            break
    params["sc"]=s_con
    params["scd"]=s_con_det
    params["svol"] = words[j+1].strip("V=");
    
    dt_start=words.index("into")+1
    d_type=words[dt_start]
    for i in range(dt_start+1, len(words)):
        if not(words[i].startswith("(")):
            d_type=d_type+" "+words[i]
        else:
            did=words[i].strip("(,)")
            break
        
    params["dt"]=d_type
    params["did"]=did
    
    words.remove("contains")
    dc_start=words.index("contains")+1
    d_con=words[dc_start]
    d_con_det=""
    for i in range(dc_start+1, len(words)):
        if not(words[i].startswith("(")):
            d_con=d_con+" "+words[i]
        else:
            for j in range(i, len(words)):
                if not(words[j].endswith(";")):
                    d_con_det=d_con_det+" "+words[j].strip("(")
                else:
                    d_con_det=d_con_det+" "+words[j].strip(";")
                    break
            break
        
    params["dc"]=d_con
    if (d_con_det != " ("):
        params["dcd"]=d_con_det
    else:
        params["dcd"]="Empty"
    params["dvol"] = words[j+1].strip("V=");
    rc_start=words.index("resulting")+1
    r_con_det=""
    for i in range(rc_start+1, len(words)):
        if (words[i].startswith("(")):
            for j in range(i, len(words)):
                if not(words[j].endswith(";")):
                    r_con_det=r_con_det+" "+words[j].strip("(")
                else:
                    r_con_det=r_con_det+" "+words[j].strip(";")
                    break
            break
        
    params["rcd"]=r_con_det
    
    params["rvol"] = words[j+1].strip("V=");
    
    ret=actionForLog("SM", params, [])
    parseForReuth('sm', params)
    return ret

def parseForReuth(name, params):
    obsSigma = Sigma('sm', ['sid','did','vol', 'scd', 'svol', 'dcd', 'dvol', 'rcd', 'rvol'])
    obsSigma.setParam('vol', params["vol"])
    obsSigma.setParam('sid', params["sid"])
    obsSigma.setParam('scd', params["scd"])
    obsSigma.setParam('svol', params["svol"])
    obsSigma.setParam('did', params["did"])
    obsSigma.setParam('dcd', params["dcd"])
    obsSigma.setParam('dvol', params["dvol"])
    obsSigma.setParam('rcd', params["rcd"])
    obsSigma.setParam('rvol', params["rvol"])
    print "mixC (", obsSigma.getParam("sid"), ", ", obsSigma.getParam("did"), "), "
    reuthObservations.append(obsSigma) 

def parseMoveObj(line):
    params={}
    words=line.split()
    ot_start=words.index("component/s:")+1
    o_type=words[ot_start]
    for i in range(ot_start+1, len(words)):
        if not(words[i].startswith("(")):
            o_type=o_type+" "+words[i]
        else:
            oid=words[i].strip("(,)")
            break
    
    params["t"]=o_type
    params["id"]=oid    
    ret=actionForLog("MO", params, [])
    return ret

def parseFlaskCon(line):
    
    params={}
    words=line.split()
    st_start=1
    s_type=words[1]
    for i in range(st_start+1, len(words)):
        if not(words[i].startswith("(")):
            s_type=s_type+" "+words[i]
        else:
            sid=words[i].strip("(,)")
            break
        
    params["st"]=s_type
    params["sid"]=sid
        
    dt_start=words.index("the")+1
    d_type=words[dt_start]
    for i in range(dt_start+1, len(words)):
        if not(words[i].startswith("(")):
            d_type=d_type+" "+words[i]
        else:
            did=words[i].strip("(,),.")
            break
        
    params["dt"]=d_type
    params["did"]=did
    ret=actionForLog("FC", params, [])
    return ret

def parseAddSol(line):
    params={}
    words=line.split()
    st_start=1
    empty=0
    if (words[st_start]=="empty"):
        st_start=st_start+1
        empty=1
    s_type=words[st_start]
    for i in range(st_start+1, len(words)):
        if not(words[i].startswith("(")):
            s_type=s_type+" "+words[i]
        else:
            sid=words[i].strip("(,)")
            break
        
    if (empty==1):
        params["c"]="empty"
    else:
        c_start=words.index("is:")+1
        c=words[c_start]
        for i in range(c_start+1, len(words)):
            if not(words[i].startswith("(")):
                c=c+"_"+words[i]
            else:
                break
        params["c"]=c
        
        
    params["t"]=s_type
    params["id"]=sid
    ret=actionForLog("AF", params, [])
    return ret

def parseLoadProb(line):
    params={}
    words=line.split()
    params["p"]=words[2]
    ret=actionForLog("LP", params, [])
    return ret


def parseProblemStart(line):
    params={}
    words=line.split(': ')
    params["p"]=words[1]
    ret=actionForLog("PS", params, [])
    return ret

def parseFormCheck(line):
    params={}
#    indexBegin=0
#    indexLast = 0
    params["c"]="correct"
    if (line.find("Correct")==-1):
        params["c"]="wrong"
    indexBegin = line.find("The correct value is") + 21
    newLine = line[indexBegin:len(line)]
    indexLast = newLine.find(".")
    answer = newLine[0:indexLast]
    index = newLine.find("-->")
    if (index > -1):
        newLine = newLine[0:index] + " = " + newLine[index+3:indexLast]
        words = newLine.split('  ')
        answer = words[0]
        i=1
        while (words[i] != '='):
            answer = answer + " + " + words[i]
            i = i+1
        i=i+2
        answer = answer + " CREATE: " + words[i-1]
        while (i < len(words)):
            answer = answer + " + " + words[i]
            i=i+1
    params["realAnswer"] = answer
    ret=actionForLog("FOC", params, [])
    return ret

def parseRemove(line):
    
    params={}
    words=line.split()
    st_start=1
    s_type=words[1]
    for i in range(st_start+1, len(words)):
        if not(words[i].startswith("(")):
            s_type=s_type+" "+words[i]
        else:
            sid=words[i].strip("(,)")
            break
        
    params["t"]=s_type
    params["id"]=sid
    ret= actionForLog("RM", params, [])
    return ret

def parseSetThermal(line):
    params={}
    words=line.split()
    st_start=1
    for i in range(st_start, len(words)):
        if (words[i].endswith(")")):
            idlong=words[i].strip("(,)")
            j=idlong.find("ID")
            my_id=idlong[j:len(idlong)]
            st_start=i
            break
        
    
    temp=words[st_start+8].strip(".");
    if (words[st_start+13]=="insulated."):
        ins = "true"
    else:
        ins="false"
    

    params["my_id"]=my_id
    params["temp"]=temp
    params["insulated"]=ins
    ret=actionForLog("ST", params, [])
    return ret

def parseActionForLog(actionForLog, actionType):
    
    takeaction = {
            "WORKBENCH_ADD_FLASK": parseAddSol,
            "SOLUTION_MIX": parseSolMix,
            "WORKBENCH_MOVE_OBJECT": parseMoveObj,
            "WORKBENCH_FLASKS_CONNECT": parseFlaskCon,
            "VLAB_LOAD_PROBLEM": parseLoadProb,
            "PROBLEM_START": parseProblemStart,
            "WORKBENCH_REMOVE": parseRemove,
            "SOLUTION_SET_THERMAL":parseSetThermal,
            "FORM_CHECK": parseFormCheck}
    
    #due to problem with form_check actions xml in all logs, parsed differently
    if (actionType=="FORM_CHECK"):
        a=parseFormCheck(actionForLog)    
        return a
    
    file1 = open("action.xml","w+")
    file1.write(actionForLog)
    file1.close()
    xmldoc=minidom.parse('action.xml')
    desc=xmldoc.getElementsByTagName("description")[0]
    
    if (actionType in takeaction):
        a=takeaction.get(actionType)(desc.childNodes[0].data)
        return a
    else:
        return None
    

#def readXlsLogs(log):
#    wb=xlrd3.open_workbook(log)
#    sh = wb.sheet_by_index(0)
#    log_id = sh.cell(0,1).value
#    #print id
#    i=0
#    index=1
#    actions=[] 
##    prob_name=""
#    while not (i==sh.nrows):
#        log_id = sh.cell(i,1).value
#        while (sh.cell(i,1).value==log_id):
#            a=parseActionForLog(sh.cell(i,9).value, sh.cell(i,5).value)
#            
#            if not (a==None):
#                if (a.getName()=="LP"):
#                    continue #prob_name=a.ids["p"]           
#                actions.append(a)
#                #print a        
#            i=i+1
#            #print i
#            if (i==sh.nrows):
#                break
#            
#        file = open("log.txt",'w+')
#        for act in actions:
#            file.write(str(act))
#            file.write("\n")
#        file.close()
#        del actions[:]
#        #print i
#        index=index+1
#        
#    return file

def readTxtLogs(log):
    logfile = open(log,'rt')
    actions=[] 
    for line in logfile:
        line = line.replace('"','')
        lineValues=line.split('\t')
        a=parseActionForLog(lineValues[9], lineValues[5])
        
        if not (a==None):
            if (a.getName()=="LP"):
                continue #prob_name=a.ids["p"]            
            actions.append(a)

    file = open("log.txt",'w+')
    for act in actions:
        file.write(str(act))
        file.write("\n")
    file.close()
    del actions[:]
        #print i
        
    return file

#-------------------------------log processing methods end--

#-------------------------------main-----------------------------------------------------------------
def initPL_Strategies():
 
    #Basic Actions
    sigmaAB = NT('AB', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    sigmaAC = NT('AC', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    sigmaAD = NT('AD', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    sigmaBC = NT('BC', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    sigmaBD = NT('BD', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    sigmaCD = NT('CD', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    sigmaABC = NT('ABC', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    sigmaABD = NT('ABD', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    sigmaACD = NT('ACD', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    sigmaBCD = NT('BCD', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    sigmaABCD = NT('ABCD', ['sc','dc','sid','did','vol','svol','dvol','rvol'])   #For example, here 
  
    #Actions of pouring substances together
    AB = NT('AB', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    AC = NT('AC', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    AD = NT('AD', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    BC = NT('BC', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    BD = NT('BD', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    CD = NT('CD', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    ABC = NT('ABC', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    ABD = NT('ABD', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    ACD = NT('ACD', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    BCD = NT('BCD', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    ABCD = NT('ABCD', ['sc','dc','sid','did','vol','svol','dvol','rvol'])   #For example, here 

    #Goals
    FourWay = NT('FourWay', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    TwoWay = NT('TwoWay', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    
    #Strategies
    ### This set needs to be duplicated 5 times: <AB,CD>, <AC,BD>, <AD,BC>, <BC,AD>, <BD,AC>. Currently shows only the rules for the first tuple, <AB,CD>
    #<AB,CD>
    fourWayRule1 = Rule(FourWay, [AB,CD, ABCD], [(0,2),(1,2)], [(0,'sc','A'),(0,'dc','B'),(1,'sc','C'),(1,'dc','D'),(2,'sc','AB'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule2 = Rule(FourWay, [AB,CD, ABCD], [(0,2),(1,2)], [(0,'sc','A'),(0,'dc','B'),(1,'sc','C'),(1,'dc','D'),(2,'sc','CD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule3 = Rule(FourWay, [AB,CD, ABCD], [(0,2),(1,2)], [(0,'sc','B'),(0,'dc','A'),(1,'sc','C'),(1,'dc','D'),(2,'sc','AB'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule4 = Rule(FourWay, [AB,CD, ABCD], [(0,2),(1,2)], [(0,'sc','B'),(0,'dc','A'),(1,'sc','C'),(1,'dc','D'),(2,'sc','CD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule5 = Rule(FourWay, [AB,CD, ABCD], [(0,2),(1,2)], [(0,'sc','A'),(0,'dc','B'),(1,'sc','D'),(1,'dc','C'),(2,'sc','AB'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule6 = Rule(FourWay, [AB,CD, ABCD], [(0,2),(1,2)], [(0,'sc','A'),(0,'dc','B'),(1,'sc','D'),(1,'dc','C'),(2,'sc','CD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule7 = Rule(FourWay, [AB,CD, ABCD], [(0,2),(1,2)], [(0,'sc','B'),(0,'dc','A'),(1,'sc','D'),(1,'dc','C'),(2,'sc','AB'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule8 = Rule(FourWay, [AB,CD, ABCD], [(0,2),(1,2)], [(0,'sc','B'),(0,'dc','A'),(1,'sc','D'),(1,'dc','C'),(2,'sc','CD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    #<AC,BD>
    fourWayRule9 = Rule(FourWay, [AC,BD, ABCD], [(0,2),(1,2)], [(0,'sc','A'),(0,'dc','C'),(1,'sc','B'),(1,'dc','D'),(2,'sc','AC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule10 = Rule(FourWay, [AC,BD, ABCD], [(0,2),(1,2)], [(0,'sc','A'),(0,'dc','C'),(1,'sc','B'),(1,'dc','D'),(2,'sc','BD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule11 = Rule(FourWay, [AC,BD, ABCD], [(0,2),(1,2)], [(0,'sc','C'),(0,'dc','A'),(1,'sc','B'),(1,'dc','D'),(2,'sc','AC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule12 = Rule(FourWay, [AC,BD, ABCD], [(0,2),(1,2)], [(0,'sc','C'),(0,'dc','A'),(1,'sc','B'),(1,'dc','D'),(2,'sc','BD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule13 = Rule(FourWay, [AC,BD, ABCD], [(0,2),(1,2)], [(0,'sc','A'),(0,'dc','C'),(1,'sc','D'),(1,'dc','B'),(2,'sc','AC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule14 = Rule(FourWay, [AC,BD, ABCD], [(0,2),(1,2)], [(0,'sc','A'),(0,'dc','C'),(1,'sc','D'),(1,'dc','B'),(2,'sc','BD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule15 = Rule(FourWay, [AC,BD, ABCD], [(0,2),(1,2)], [(0,'sc','C'),(0,'dc','A'),(1,'sc','D'),(1,'dc','B'),(2,'sc','AC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule16 = Rule(FourWay, [AC,BD, ABCD], [(0,2),(1,2)], [(0,'sc','C'),(0,'dc','A'),(1,'sc','D'),(1,'dc','B'),(2,'sc','BD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    #<AD,BC>
    fourWayRule17 = Rule(FourWay, [AD,BC, ABCD], [(0,2),(1,2)], [(0,'sc','A'),(0,'dc','D'),(1,'sc','B'),(1,'dc','C'),(2,'sc','AD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule18 = Rule(FourWay, [AD,BC, ABCD], [(0,2),(1,2)], [(0,'sc','A'),(0,'dc','D'),(1,'sc','B'),(1,'dc','C'),(2,'sc','BC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule19 = Rule(FourWay, [AD,BC, ABCD], [(0,2),(1,2)], [(0,'sc','D'),(0,'dc','A'),(1,'sc','B'),(1,'dc','C'),(2,'sc','AD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule20 = Rule(FourWay, [AD,BC, ABCD], [(0,2),(1,2)], [(0,'sc','D'),(0,'dc','A'),(1,'sc','B'),(1,'dc','C'),(2,'sc','BC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule21 = Rule(FourWay, [AD,BC, ABCD], [(0,2),(1,2)], [(0,'sc','A'),(0,'dc','D'),(1,'sc','C'),(1,'dc','B'),(2,'sc','AD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule22 = Rule(FourWay, [AD,BC, ABCD], [(0,2),(1,2)], [(0,'sc','A'),(0,'dc','D'),(1,'sc','C'),(1,'dc','B'),(2,'sc','BC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule23 = Rule(FourWay, [AD,BC, ABCD], [(0,2),(1,2)], [(0,'sc','D'),(0,'dc','A'),(1,'sc','C'),(1,'dc','B'),(2,'sc','AD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule24 = Rule(FourWay, [AD,BC, ABCD], [(0,2),(1,2)], [(0,'sc','D'),(0,'dc','A'),(1,'sc','C'),(1,'dc','B'),(2,'sc','BC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    #<BC,AD>
    fourWayRule25 = Rule(FourWay, [BC,AD, ABCD], [(0,2),(1,2)], [(0,'sc','B'),(0,'dc','C'),(1,'sc','A'),(1,'dc','D'),(2,'sc','BC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule26 = Rule(FourWay, [BC,AD, ABCD], [(0,2),(1,2)], [(0,'sc','B'),(0,'dc','C'),(1,'sc','A'),(1,'dc','D'),(2,'sc','AD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule27 = Rule(FourWay, [BC,AD, ABCD], [(0,2),(1,2)], [(0,'sc','C'),(0,'dc','B'),(1,'sc','A'),(1,'dc','D'),(2,'sc','BC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule28 = Rule(FourWay, [BC,AD, ABCD], [(0,2),(1,2)], [(0,'sc','C'),(0,'dc','B'),(1,'sc','A'),(1,'dc','D'),(2,'sc','AD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule29 = Rule(FourWay, [BC,AD, ABCD], [(0,2),(1,2)], [(0,'sc','B'),(0,'dc','C'),(1,'sc','D'),(1,'dc','A'),(2,'sc','BC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule30 = Rule(FourWay, [BC,AD, ABCD], [(0,2),(1,2)], [(0,'sc','B'),(0,'dc','C'),(1,'sc','D'),(1,'dc','A'),(2,'sc','AD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule31 = Rule(FourWay, [BC,AD, ABCD], [(0,2),(1,2)], [(0,'sc','C'),(0,'dc','B'),(1,'sc','D'),(1,'dc','A'),(2,'sc','BC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule32 = Rule(FourWay, [BC,AD, ABCD], [(0,2),(1,2)], [(0,'sc','C'),(0,'dc','B'),(1,'sc','D'),(1,'dc','A'),(2,'sc','AD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    #<BD,AC>
    fourWayRule33 = Rule(FourWay, [BD,AC, ABCD], [(0,2),(1,2)], [(0,'sc','B'),(0,'dc','D'),(1,'sc','A'),(1,'dc','C'),(2,'sc','BD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule34 = Rule(FourWay, [BD,AC, ABCD], [(0,2),(1,2)], [(0,'sc','B'),(0,'dc','D'),(1,'sc','A'),(1,'dc','C'),(2,'sc','AC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule35 = Rule(FourWay, [BD,AC, ABCD], [(0,2),(1,2)], [(0,'sc','D'),(0,'dc','B'),(1,'sc','A'),(1,'dc','C'),(2,'sc','BD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule36 = Rule(FourWay, [BD,AC, ABCD], [(0,2),(1,2)], [(0,'sc','D'),(0,'dc','B'),(1,'sc','A'),(1,'dc','C'),(2,'sc','AC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule37 = Rule(FourWay, [BD,AC, ABCD], [(0,2),(1,2)], [(0,'sc','B'),(0,'dc','D'),(1,'sc','C'),(1,'dc','A'),(2,'sc','BD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule38 = Rule(FourWay, [BD,AC, ABCD], [(0,2),(1,2)], [(0,'sc','B'),(0,'dc','D'),(1,'sc','C'),(1,'dc','A'),(2,'sc','AC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule39 = Rule(FourWay, [BD,AC, ABCD], [(0,2),(1,2)], [(0,'sc','D'),(0,'dc','B'),(1,'sc','C'),(1,'dc','A'),(2,'sc','BD'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    fourWayRule40 = Rule(FourWay, [BD,AC, ABCD], [(0,2),(1,2)], [(0,'sc','D'),(0,'dc','B'),(1,'sc','C'),(1,'dc','A'),(2,'sc','AC'),
                                                                (2,'sid',0,'did'),(2,'did',1,'did')])
    # ((A+B)+C)+D Rules
    fourWayRule41 = Rule(FourWay, [AB,ABC, ABCD], [(0,1),(1,2)], [(0,'sc','A'),(0,'dc','B'),(1,'sc','AB'),(1,'dc','C'),(2,'dc','D'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])
    fourWayRule42 = Rule(FourWay, [AB,ABC, ABCD], [(0,1),(1,2)], [(0,'sc','B'),(0,'dc','A'),(1,'sc','AB'),(1,'dc','C'),(2,'dc','D'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])
    fourWayRule43 = Rule(FourWay, [AB,ABD, ABCD], [(0,1),(1,2)], [(0,'sc','A'),(0,'dc','B'),(1,'sc','AB'),(1,'dc','D'),(2,'dc','C'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])
    fourWayRule44 = Rule(FourWay, [AB,ABD, ABCD], [(0,1),(1,2)], [(0,'sc','B'),(0,'dc','A'),(1,'sc','AB'),(1,'dc','D'),(2,'dc','C'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])
    fourWayRule45 = Rule(FourWay, [AC,ABC, ABCD], [(0,1),(1,2)], [(0,'sc','A'),(0,'dc','C'),(1,'sc','AC'),(1,'dc','B'),(2,'dc','D'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])
    fourWayRule46 = Rule(FourWay, [AC,ABC, ABCD], [(0,1),(1,2)], [(0,'sc','C'),(0,'dc','A'),(1,'sc','AC'),(1,'dc','B'),(2,'dc','D'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])
    fourWayRule47 = Rule(FourWay, [AC,ACD, ABCD], [(0,1),(1,2)], [(0,'sc','A'),(0,'dc','C'),(1,'sc','AC'),(1,'dc','D'),(2,'dc','B'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])
    fourWayRule48 = Rule(FourWay, [AC,ACD, ABCD], [(0,1),(1,2)], [(0,'sc','C'),(0,'dc','A'),(1,'sc','AC'),(1,'dc','D'),(2,'dc','B'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])
    fourWayRule49 = Rule(FourWay, [AD,ABD, ABCD], [(0,1),(1,2)], [(0,'sc','A'),(0,'dc','D'),(1,'sc','AD'),(1,'dc','B'),(2,'dc','C'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])
    fourWayRule50 = Rule(FourWay, [AD,ABD, ABCD], [(0,1),(1,2)], [(0,'sc','D'),(0,'dc','A'),(1,'sc','AD'),(1,'dc','B'),(2,'dc','C'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])
    fourWayRule51 = Rule(FourWay, [AD,ACD, ABCD], [(0,1),(1,2)], [(0,'sc','A'),(0,'dc','D'),(1,'sc','AD'),(1,'dc','C'),(2,'dc','B'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])
    fourWayRule52 = Rule(FourWay, [AD,ACD, ABCD], [(0,1),(1,2)], [(0,'sc','D'),(0,'dc','A'),(1,'sc','AD'),(1,'dc','C'),(2,'dc','B'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])                                                                
    fourWayRule53 = Rule(FourWay, [BC,ABC, ABCD], [(0,1),(1,2)], [(0,'sc','C'),(0,'dc','B'),(1,'sc','BC'),(1,'dc','A'),(2,'dc','D'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])
    fourWayRule54 = Rule(FourWay, [BC,ABC, ABCD], [(0,1),(1,2)], [(0,'sc','B'),(0,'dc','C'),(1,'sc','BC'),(1,'dc','A'),(2,'dc','D'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])                                                                
    fourWayRule55 = Rule(FourWay, [BC,BCD, ABCD], [(0,1),(1,2)], [(0,'sc','C'),(0,'dc','B'),(1,'sc','BC'),(1,'dc','D'),(2,'dc','A'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])
    fourWayRule56 = Rule(FourWay, [BC,BCD, ABCD], [(0,1),(1,2)], [(0,'sc','B'),(0,'dc','C'),(1,'sc','BC'),(1,'dc','D'),(2,'dc','A'),
                                                                (0,'did',1,'sid'),(1,'did',2,'sid')])                                                                
    
    twoWayRule = Rule(TwoWay, [AB, AC, AD, BC, BD, CD], [], [])
    
    #Rules from sigmas to NTs:
    ruleAB = Rule(AB, [sigmaAB], [], [(-1,'sid',0,'sid'),(-1,'did',0,'did'),(-1,'vol',0,'vol'),(-1,'svol',0,'svol'),(-1,'dvol',0,'dvol'),(-1,'rvol',0,'rvol')])
    ruleAC = Rule(AC, [sigmaAC], [], [(-1,'sid',0,'sid'),(-1,'did',0,'did'),(-1,'vol',0,'vol'),(-1,'svol',0,'svol'),(-1,'dvol',0,'dvol'),(-1,'rvol',0,'rvol')])
    ruleAD = Rule(AD, [sigmaAD], [], [(-1,'sid',0,'sid'),(-1,'did',0,'did'),(-1,'vol',0,'vol'),(-1,'svol',0,'svol'),(-1,'dvol',0,'dvol'),(-1,'rvol',0,'rvol')])
    ruleBC = Rule(BC, [sigmaBC], [], [(-1,'sid',0,'sid'),(-1,'did',0,'did'),(-1,'vol',0,'vol'),(-1,'svol',0,'svol'),(-1,'dvol',0,'dvol'),(-1,'rvol',0,'rvol')])
    ruleBD = Rule(BD, [sigmaBD], [], [(-1,'sid',0,'sid'),(-1,'did',0,'did'),(-1,'vol',0,'vol'),(-1,'svol',0,'svol'),(-1,'dvol',0,'dvol'),(-1,'rvol',0,'rvol')])
    ruleCD = Rule(CD, [sigmaCD], [], [(-1,'sid',0,'sid'),(-1,'did',0,'did'),(-1,'vol',0,'vol'),(-1,'svol',0,'svol'),(-1,'dvol',0,'dvol'),(-1,'rvol',0,'rvol')])
    ruleABC = Rule(ABC, [sigmaABC], [], [(-1,'sid',0,'sid'),(-1,'did',0,'did'),(-1,'vol',0,'vol'),(-1,'svol',0,'svol'),(-1,'dvol',0,'dvol'),(-1,'rvol',0,'rvol')])
    ruleABD = Rule(ABD, [sigmaABD], [], [(-1,'sid',0,'sid'),(-1,'did',0,'did'),(-1,'vol',0,'vol'),(-1,'svol',0,'svol'),(-1,'dvol',0,'dvol'),(-1,'rvol',0,'rvol')])
    ruleACD = Rule(ACD, [sigmaACD], [], [(-1,'sid',0,'sid'),(-1,'did',0,'did'),(-1,'vol',0,'vol'),(-1,'svol',0,'svol'),(-1,'dvol',0,'dvol'),(-1,'rvol',0,'rvol')])
    ruleBCD = Rule(BCD, [sigmaBCD], [], [(-1,'sid',0,'sid'),(-1,'did',0,'did'),(-1,'vol',0,'vol'),(-1,'svol',0,'svol'),(-1,'dvol',0,'dvol'),(-1,'rvol',0,'rvol')])
    ruleABCD = Rule(ABCD, [sigmaABCD], [], [(-1,'sid',0,'sid'),(-1,'did',0,'did'),(-1,'vol',0,'vol'),(-1,'svol',0,'svol'),(-1,'dvol',0,'dvol'),(-1,'rvol',0,'rvol')])
    
    sigmas = [sigmaAB,sigmaAC,sigmaAD,sigmaBC,sigmaBD,sigmaCD,sigmaABC,sigmaABD,sigmaACD,sigmaBCD,sigmaABCD]
    nts = [AB,AC,AD,BC,BD,CD,ABC,ABD,ACD,BCD,ABCD]
    goals = [FourWay, TwoWay]
    rules = [fourWayRule1,fourWayRule2,fourWayRule3,fourWayRule4,fourWayRule5,fourWayRule6,fourWayRule7,fourWayRule8,fourWayRule9,fourWayRule10,fourWayRule11,fourWayRule12,fourWayRule13,fourWayRule14,fourWayRule15,fourWayRule16,fourWayRule17
             ,fourWayRule18,fourWayRule19,fourWayRule20,fourWayRule21,fourWayRule22,fourWayRule23,fourWayRule24,fourWayRule25,fourWayRule26,fourWayRule27,fourWayRule28,fourWayRule29,fourWayRule30,fourWayRule31,fourWayRule32,fourWayRule33,
             fourWayRule34,fourWayRule35,fourWayRule36,fourWayRule37,fourWayRule38,fourWayRule39,fourWayRule40,fourWayRule41,fourWayRule42,fourWayRule43,fourWayRule44,fourWayRule45,fourWayRule46,fourWayRule47,fourWayRule48,fourWayRule49,
             fourWayRule50,fourWayRule51,fourWayRule52,fourWayRule52,fourWayRule53,fourWayRule54,fourWayRule55,fourWayRule56
             ,twoWayRule,ruleAB,ruleAC,ruleAD,ruleBC,ruleBD,ruleCD,ruleABC,ruleABD,ruleACD,ruleBCD,ruleABCD]
    return PL(sigmas, nts, goals, rules)

    
def initPL_VL():
    sigma1 = Sigma('sm', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    
    nt1 = NT('C', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    nt2 = NT('SM', ['sc','dc','sid','did','vol','svol','dvol','rvol'])
    
    # SM -> sm | []
    #    SM.sid=sm.sid, SM.did=sm.did, SM.sc=sm.sc,SM.dc=sm.dc,SM.vol=sm.vol,sM.rcd=sm.rcd,SM.scd=sm.scd,SM.dcd=sm.dcd,SM.svol=sm.svol,SM.dvol=sm.dvol,SM.rvol=sm.rvol
    rule1 = Rule(nt2, [sigma1], [], [(-1,'sid',0,'sid'),(-1,'did',0,'did')], 0.1)#,(-1,'vol',0,'vol'),(-1,'svol',0,'svol'),(-1,'dvol',0,'dvol'),(-1,'rvol',0,'rvol')])
#    # C -> SM1 SM2 | []
#    # C1.did=C2.did, C1.rcd=C2.dcd, C1.rvol=C2.dvol, C.did=C1.did
#    rule2 = Rule.Rule(nt1, [nt2, nt2], [], [(0,'did',1,'did'),(0,'rcd',1,'dcd'),(0,'rvol',1,'dvol'),(-1,'did',0,'did')])
#    # C -> SM1 SM2 | []
#    # SM1.did=SM2.sid SM1.rcd=SM2.scd SM1.rvol=SM2.svol
#    # C.sc=SM1.sc C.dc=SM2.dc C.sid=SM1.sid, C.did=SM2.did C.vol=SM2.vol C.rcd=SM2.rcd C.scd=SM2.scd C.dcd=SM2.dcd C.svol=SM2.svol C.dvol=SM2.dvol C.rvol=SM2.rvol
#    rule3 = Rule.Rule(nt1, [nt2, nt2], [], [(0,'did',1,'sid'),(0,'rcd',1,'scd'),(0,'rvol',1,'svol'),(-1,'sc',0,'sc'),(-1,'dc',1,'dc'),(-1,'sid',0,'sid'),(-1,'did',1,'did'),(-1,'vol',1,'vol'),(-1,'rcd',1,'rcd'),(-1,'scd',1,'scd'),(-1,'dcd',1,'dcd'),(-1,'svol',1,'svol'),(-1,'dvol',1,'dvol'),(-1,'rvol',1,'rvol')])
#    # SM -> MS1 SM2 | []
#    # SM1.did=SM2.did, SM1.rcd=SM2.dcd, SM1.rvol=SM2.dvol
#    rule4 = Rule.Rule(nt2, [nt2, nt2], [], [(0,'did',1,'did'),(0,'rcd',1,'dcd'),(0,'rvol',1,'dvol')])
#    # SM -> SM1 SM2 | []
#    # SM1.did=SM2.sid SM1.rcd=SM2.scd SM1.rvol=SM2.svol
#    # SM.sc=SM1.sc SM.dc=SM2.dc SM.sid=SM1.sid, SM.did=SM2.did SM.vol=SM2.vol SM.rcd=SM2.rcd SM.scd=SM2.scd SM.dcd=SM2.dcd SM.svol=SM2.svol SM.dvol=SM2.dvol SM.rvol=SM2.rvol
#    rule5 = Rule.Rule(nt2, [nt2, nt2], [], [(0,'did',1,'sid'),(0,'rcd',1,'scd'),(0,'rvol',1,'svol'),(-1,'sc',0,'sc'),(-1,'dc',1,'dc'),(-1,'sid',0,'sid'),(-1,'did',1,'did'),(-1,'vol',1,'vol'),(-1,'rcd',1,'rcd'),(-1,'scd',1,'scd'),(-1,'dcd',1,'dcd'),(-1,'svol',1,'svol'),(-1,'dvol',1,'dvol'),(-1,'rvol',1,'rvol')])
    # C -> SM1 SM2 | []
    # SM1.did=SM2.did C.scd=SM2.scd C.dcd=SM2.dcd C.rcd=SM2.dcd C.did=SM1.did 
    rule6 = Rule(nt1, [nt2, nt2], [(0,1)], [(0,'did',1,'did'),(-1,'did',0,'did')], 0.4)#,(-1,'scd',0,'scd')
    # C -> SM1 SM2 | []
    # SM1.did=SM2.sid C.sc=SM1.sc C.dcd=SM2.dcd C.rcd=SM2.rcd C.did=SM2.did C.sid=SM1.sid
    rule7 = Rule(nt1, [nt2, nt2], [(0,1)], [(0,'did',1,'sid'),(-1,'sid',0,'sid'),(-1,'did',1,'did'),(-1,'sid',0,'sid')], 0.05)
    # SM -> SM1 SM2 | []
    # SM1.did=SM2.did SM.scd=SM2.scd SM.dcd=SM2.dcd SM.rcd=SM2.dcd SM.did=SM1.did
    rule8 = Rule(nt2, [nt2, nt2], [(0,1)], [(0,'did',1,'did'),(-1,'did',0,'did')], 0.4)#,(-1,'scd',0,'scd')
    # SM -> SM1 SM2 | []
    # SM1.did=SM2.sid SM.sc=SM1.sc SM.dcd=SM2.dcd SM.rcd=SM2.rcd SM.did=SM2.did, SM.sid=SM1.sid
    rule9 = Rule(nt2, [nt2, nt2], [(0,1)], [(0,'did',1,'sid'),(-1,'sid',0,'sid'),(-1,'did',1,'did'),(-1,'sid',0,'sid')], 0.05)
    
    
    ########
    #    Rules for Oracle Problem: 1, 2, 3, 4, 5
    #    Rules for unknown-acid  - 1, 6, 7, 8, 9
    #########
    sigmas = [sigma1]
    nts = [nt1, nt2]
    goals = [nt1]
    rules = [rule1, rule6, rule7, rule8, rule9]
    return PL(sigmas, nts, goals, rules)

reuthObservations = []
    
import profile
# def main():
#     profile.run('myMain()')

def writeExp(exp):
    expAsStr="{ROOT"
    for tree in exp.getTrees():
        expAsStr+=reprTree(tree)
    expAsStr+="}"
    return expAsStr
    
def reprTree(tree):
    if [] == tree._children:
        sid=tree.getRoot().getParam("sid")
        if sid==None:
            sid="X"
        else:
            sid=sid[2:]
        did=tree.getRoot().getParam("did")
        if did==None:
            did="X"
        else:
            did=did[2:]
        if tree.isComplete():
            return sid+"-"+did
        else:
            return "{"+sid+"-"+did+"}"
    
    else:
        treeAsStr="{"
        for child in tree._children:
            treeAsStr+=reprTree(child)
        treeAsStr+="}"
        return treeAsStr
        
from Algorithm import location     
 
def main():
    global location

    sys.argv.append(sys.argv[1])
    sys.stdout = open("C:\\Users\\"+location+"\\Desktop\\test2\\"+sys.argv[1]+".txt", "w+")
    probName = ""
    answer = ""
    log = str("C:\\Users\\"+location+"\\Dropbox (BGU)\\Reuth-new\\Online Plan Recognition\\Domains\\VirtualLabs-Recipe+Logs\\Logs\\"+sys.argv[1]+".log")
    print log
    if log.endswith('.log'):
        log = readTxtLogs(log)
    elif log.endswith('.txt'):
        log = readTxtLogs(log)

    else:
        print ('invalid file format')
        return
        
            

    ''' READ LOG FILE '''
    L = [] # log file stored here
    count = 1
    # filename="C:\\Oracle_log_97_20060125213817_5368836.txt" #location for log file
    #filename="C:\\coffee\\Coffee1_log_41_20080131184454_1858034.txt"
    file = open('log.txt', 'r')
    for line in file: 
        line = line[2:-2].strip()
        i = line.find(',')
        name = line[:i-1]
        ids = line[i+2:].split(' , ')
        if (name == 'LP'):
            probName = ids[0].split('=')[1]
        if (name == 'PS' and probName == ""):
            probName = ids[0].split('=')[1]
        if (name == "FOC" and answer == ""):
            answer= ids[0].split('=')[1] 
        d = {}
        
        for x in ids:
            (my_id, val) = tuple(x.split('='))
            d[my_id] = val
        
        a = action(name, d, [], True) # log actions don't have preconditions whatsoever
        a.index = count # yet, they have indices into the log
        a.id_num = count 
        L.append(a)
        count += 1
        #print(line)
        #print count
    
    #L.reverse()
    #plan=buildPlan(R, L)
    #a='ss ss'
    #print a
    # outFile = open(outputFile, 'w+')
    #outFile.write('RRRR')
    #outFile.write(printXML(plan[len(plan)-1], rootAction))
    #print('<ROOT probName="' + probName + '" answer="' +answer+  '">')
    #printXML(plan[len(plan)-1], rootAction)
    #print('</ROOT>')
    #print filename
    #print time.clock()-start
    
    
    print "ReuthObservations=", len(reuthObservations)    
    probabilities = {}
    
    #Parse 4th argument to filter actions
    # filterParams = sys.argv[4].split()
    #print "filter Actions = ", filterParams
    
    exps = Algorithm.ExplainAndCompute(initPL_Strategies(), reuthObservations)#, filterParams)
    if len(exps)==0:
        print "No Explnanations"    
    print "\n\n"    
    explanations = 0
    noFrontier = []
    allVectors=[]

    exps.sort(key=Explanation.getExpProbability)
#    expFileName="./exps/vectors-filtered.txt"
#    file = open(expFileName, 'w+')
    firstflag = True
    while not len(exps)==0:
        exp = exps.pop()
        if firstflag:
            print "-------------\n First Exp\n-----------------"
            exp.printInMCSAForm()
            #print exp
            firstflag = False
        #exp.getExpProbability()
#        if probabilities[str(expProb)]==0:
#            probabilities[str(expProb)] = 1
#        else:
#            probabilities[str(expProb)] += 1
#            
        explanations+=1
#         if exp.getSize()==1:
#             print "-------------\n Exp With One Tree \n-----------------"
#             exp.printInMCSAForm()
#             print exp

        if exp.getFrontierSize()==0:
            print "-------------\n Exp With Empty Frontier \n-----------------"
            exp.printInMCSAForm()
            print exp
            noFrontier.append(exp)

        #print (exp)
        #file.write(str(exp.getFrontierSize())+","+str(exp.getSize())+","+str(exp.getAge())+"\n")
        #allVectors.append(vector)
        #file.write(vector)
#    mod = 0
    #file.write("0,#Trees,0,avgDepth\n");
    #file.close()
    #for exp in noFrontier:
#        if mod==0:
    #    print exp
#        mod+=1
#        mod = mod % 20
    
    print "Explanations: ", explanations
    print "No Frontier Explanations: ", len(noFrontier)
    print probabilities
 
# file.close()
    sys.exit()   
        

if __name__ == '__main__': main()