#!/usr/bin/env python
import sys
import getopt
import os
import re
import random
import time
#import xlrd3
import xml.dom
from xml.dom import minidom   
from copy import deepcopy
import math
#from xmlrpc.client import MAXINT
from warnings import catch_warnings
import Algorithm
import Explanation
import Sigma
import NT
import Rule
import PL

#---------------------------------classes----------------------------------------------------------------------
class action:
    def __init__(self, name, ids, pcons, remove):
        self.name = name # is the name of an action
        self.ids = ids # is a dictionary from ids to their values
        self.pcons = pcons # is a list of precondition action indices in the rhs of the recipe
        self.children = [] # is a list of children actions (used in tree outputting)
        self.index = 0 # index into the log, for low level ones
        self.minIndexBelow = 0 # min index into the log, for high level ones
        self.remove=remove #remove indicates whether the action should be removed from the log after being matched to a recipe
        self.id_num=0
        self.uniqueID=random.randint(1,100000)
        self.firstPos = 9999999
        self.lastPos = 0
        self.recipeNode = -1
        
    def __str__(self):
        ret = '%s[' %self.name
        for key in self.ids:
            if self.ids[key]:
                ret += '%s:%s,' %(key, self.ids[key]) # if key[1] not None
            else:
               ret += '%s,' %key
        if ret[-1] == ',': ret = ret[:-1]
        ret = '%s]' %ret
        return ret
    
    def __eq__(self, other):
        if (other.uniqueID==self.uniqueID):
            return 1
        else:
            return 0
        
    def toxml(self):
        ret = '<%s ' %self.name
        ids = list(self.ids.keys())
        ids.sort()
        for key in ids:
            ret += '%s=\"%s\" ' %(key, self.ids[key]) # if key[1] not None
        ret += 'pos=\"%d\">' %(self.getIndex()-1) # swapna uses 0-based indices
        return ret
        
    def toxmlleaf(self):
        ret = '<%s ' %self.name
        ids = list(self.ids.keys())
        ids.sort()
        for key in ids:
            ret += '%s=\"%s\" ' %(key, self.ids[key]) # if key[1] not None
        ret += 'pos=\"%d\"/>' %(self.getIndex()-1) # swapna uses 0-based indices
        return ret
    
    def getIndex(self):
        if self.index: return self.index
        elif self.minIndexBelow: return self.minIndexBelow
        else: raise
    
    def addChild(self, child):
        self.children.append(child)
        index = child.getIndex()
        id_num = child.id_num
        if self.minIndexBelow == 0 or self.minIndexBelow > index:
            self.minIndexBelow = index
            
        
class recipe:
    def __init__(self, lhs, rhs, num):
        self.lhs = lhs # is an action object
        self.rhs = rhs # is a list of action objects
        self.num=num
        
        
    def __str__(self):
        ret = '%s -> ' %(self.lhs.__str__())
        for x in self.rhs: ret += '%s ' %(x.__str__())
        return ret[:-1]
    
    def checkDependencies(self):
        for i in range(len(self.rhs)):
            for j in range(i+1, len(self.rhs)):
                intersection=[x for x in self.rhs[j].ids if x in self.rhs[i].ids]
                

class match:
    """The match class is composed of a dictionary of the actions in the match and their indices in the recipe they match"""
    #constructor
    def __init__(self, lastIndex):
        self.actions={}
        self.lastIndex=lastIndex
        self.firstPos = 9999999
        self.lastPos = 0
        
        
    #adds an action to the match    
    def addAction(self, action, index):
        self.actions[index]=action
        action.recipeNode = index
        if (action.id_num>self.lastIndex):
            self.lastIndex=action.id_num
            
    def removeAction(self, index):
        self.actions[index] = -1
        del self.actions[index]
            
    #checks if the match already contains an action which fulfills the recipe action with specified index
    def containsIndex(self, index):
        return index in list(self.actions.keys())
   
   
class priorityQueueOfMatches:
    def __init__(self):
        self.heap = []
        
  
    def parent(self, index):
        """
        Parent will be at math.floor(index/2). Since integer division
        simulates the floor function, we don't explicitly use it
        """
        return math.floor((index-1) / 2)
    
    
    def left_child(self, index):
        """ 1 is added because array begins at index 0 """
        return 2 * index + 1


    def right_child(self, index):
        return 2 * index + 2
    

    def min_heapify(self, index):
        """
        Responsible for maintaining the heap property of the heap.
        This function assumes that the subtree located at left and right
        child satisfies the max-heap property. But the tree at index
        (current node) does not. O(log n)
        """
        left_index = self.left_child(index)
        right_index = self.right_child(index)
        
        smallest = index
        if left_index < len(self.heap) and ((self.heap[left_index][0][0] < self.heap[index][0][0]) or (self.heap[left_index][0][0] == self.heap[index][0][0] and self.heap[left_index][0][1] < self.heap[index][0][1])):
            smallest = left_index
        if right_index < len(self.heap) and ((self.heap[right_index][0][0] < self.heap[smallest][0][0]) or (self.heap[right_index][0][0] == self.heap[smallest][0][0] and self.heap[right_index][0][1] < self.heap[smallest][0][1])):
            smallest = right_index
            
        if smallest != index:
            self.heap[index], self.heap[smallest] = self.heap[smallest], self.heap[index]
            self.min_heapify(smallest)


    def build_min_heap(self):
        """
        Responsible for building the heap bottom up. It starts with the lowest non-leaf nodes
        and calls heapify on them. This function is useful for initialising a heap with an
        unordered array. O(n)
        """
        for i in xrange(len(self.heap)/2, -1, -1):
            self.min_heapify(i)


    def heap_sort(self):
        """ The heap-sort algorithm with a time complexity O(n log n) """
        self.build_max_heap()
        output = []
        for i in xrange(len(self.heap)-1, 0, -1):
            self.heap[0], self.heap[i] = self.heap[i], self.heap[0]
            output.append(self.heap.pop())
            self.min_heapify(0)
        output.append(self.heap.pop())
        self.heap = output
  
        
    def propagate_up(self, index):
        """ Compares index with parent and swaps node if larger O(log(n)) """
        while index != 0 and ((self.heap[self.parent(index)][0][0] > self.heap[index][0][0]) or (self.heap[self.parent(index)][0][0] == self.heap[index][0][0] and self.heap[self.parent(index)][0][1] > self.heap[index][0][1])):
            self.heap[index], self.heap[self.parent(index)] = self.heap[self.parent(index)], self.heap[index]
            index = self.parent(index)    


    def add(self, key):
        """ Adds an element in the heap O(ln(n)) """
        self.heap.append(key)
        self.propagate_up(len(self.heap) - 1) # Index value is 1 less than length


    def extract_min(self):
        """
        Part of the Priority Queue, extracts the element on the top of the heap
        and then re-heapifies. O(log n)
        """
        min = self.heap[0]
        data = self.heap.pop()
        if len(self.heap) > 0:
            self.heap[0] = data
            self.min_heapify(0)
        return min


    def increment(self, key, value):
        """ Increments key by the input value. O(log n) """
        for i in xrange(len(self.heap)):
            if self.heap[i][1] == key[1]:
                self.heap[i][0] += value
                self.propagate_up(i)
                break

#---------------------------------classes end----------------------------------------------------------------------
    
#-------------------------------algorithm methods----------------------------------------------------
def checkActionsConstraints(match, new_action, recipe, index):
    
    #check constraints with respect to recipe
    rec_act= recipe.rhs[index]
    for param in rec_act.ids:
        if (rec_act.ids[param] is not None):           
            j = param.find('_')
            if j != -1:
                paramForCheck = param[:j]
            else:
                paramForCheck = param
            if not (new_action.ids[paramForCheck]==rec_act.ids[param]):
                return False
            
    #action fits recipe, if no other actions are already in match - nothing more to check        
    if (len(match.actions)==0):
        return True
    
    #go over constraints between actions
    '''preCons = rec_act.pcons
    for con in preCons:
        if (len(match.actions)>con):
            act = match.actions[con]
            if (new_action.lastPos < act.lastPos):
                return False
        else:
            return False'''
    
    #go over the parameters
    for param in rec_act.ids:
        j = param.find('_')
        if j != -1:
            paramForCheck = param[:j]
        else:
            paramForCheck = param
        for act in match.actions:
            for act_param in recipe.rhs[match.actions[act].recipeNode].ids:
                j = act_param.find('_')
                if j != -1:
                    paramForCheckTwo = act_param[:j]
                else:
                        paramForCheckTwo = act_param
                if ((rec_act.ids[param] is None) and (recipe.rhs[match.actions[act].recipeNode].ids[act_param] is None) and (param==act_param)):
                    if (new_action.ids[paramForCheck] != match.actions[act].ids[paramForCheckTwo]):
                        return False;
    
    return True

def extends(action, match, recipe):
    """recives an action, current match and recipe. checks if the action can extend the match"""
    res=False
    ext=True
    for i in range(len(recipe.rhs)):
        curr_act=recipe.rhs[i]
        if(action.name==curr_act.name):
            index=i
            if (match is not None):
                if not (match.containsIndex(i)): #checks that the matching action in the recipe has not yet been fulfilled 
                    #check that all preconditions for this action are fulfilled
                    for j in curr_act.pcons:
                            if (match.containsIndex(j)):
                                preCons = recipe.rhs[index].pcons
                                for con in preCons:
                                    if (len(match.actions)>con):
                                        act = None
                                        for a in list(match.actions.values()):
                                            if (a.recipeNode == con):
                                                act = a
                                        if (act is not None):
                                            if (action.lastPos < act.lastPos):
                                                ext=False
                                                break;
                                    else:
                                        ext=False
                                        break;
                    #check that the rest actions are ok
                    for act in list(match.actions.values()):
                        for conCheck in recipe.rhs[act.recipeNode].pcons:
                            if (conCheck == index):
                                if (action.lastPos > act.lastPos):
                                        ext=False
                                        break;
                                       
                    if (ext==False):
                        break;
                    #check constraints in respect with other actions in the match
                    res=checkActionsConstraints(match, action, recipe, index)
                    if res is True:
                        return index
                
    return -1


def tryExtends(action, match, recipe, lastIndex):
    """recives an action, current match ,recipe and last index try. checks if the action can extend the match in other index"""
    res=False
    ext=True
    if (lastIndex < len(recipe.rhs)-1):
        for i in range(lastIndex+1,len(recipe.rhs)):
            curr_act=recipe.rhs[i]
            if(action.name==curr_act.name):
                index=i
                if (match is not None):
                    if not (match.containsIndex(i)): #checks that the matching action in the recipe has not yet been fulfilled 
                        #check that all preconditions for this action are fulfilled
                        for j in curr_act.pcons:
                            if (match.containsIndex(j)):
                                preCons = recipe.rhs[index].pcons
                                for con in preCons:
                                    if (len(match.actions)>con):
                                        act = None
                                        for a in list(match.actions.values()):
                                            if (a.recipeNode == con):
                                                act = a
                                        if (act is not None):
                                            if (action.lastPos < act.lastPos):
                                                ext=False
                                                break;
                                    else:
                                        ext=False
                                        break;
                    #check that the rest actions are ok
                    for act in list(match.actions.values()):
                        for conCheck in recipe.rhs[act.recipeNode].pcons:
                            if (conCheck == index):
                                if (action.lastPos > act.lastPos):
                                        ext=False
                                        break;
                                       
                    if (ext==False):
                        break;
                    #check constraints in respect with other actions in the match
                    res=checkActionsConstraints(match, action, recipe, index)
                    if res is True:
                        return index
                
    return -1

def fulfills(match, recipe):
    """check if the recipe is fulfilled by the match"""
    if match is None:
        return False
        
    for i in range(len(recipe.rhs)):
        if not (match.containsIndex(i)):
                return False
    return True
    
                    
def findMatch(rc, ol, priorityMatches, mc):
    """depth first search for actions in the log which match the given recipe"""
    ol_new=deepcopy(ol)
    newMc = deepcopy(mc)
    #go over actions in log, for each action, try to add it to the current match. backtrack if failed
    for logIndex in range(0, len(ol)):
        mc = deepcopy(newMc)
        act = deepcopy(ol[logIndex])
        curr_act=findAction(act, ol_new)
        ol_new.remove(curr_act)
        index=extends(curr_act, mc, rc)
        if (index>-1):
            #the action can be added to the match, update its parameters (ie make sid sid_1, etc.)
            for param in list(curr_act.ids.keys()):
                for rec_param in rc.rhs[index].ids:
                    j = rec_param.find('_')
                    if j != -1:
                        paramForCheck = rec_param[:j]
                    else:
                        paramForCheck = rec_param
                    if (param==paramForCheck):
                        curr_act.ids[paramForCheck]=curr_act.ids[param]
                        if not (paramForCheck==param):
                            del curr_act.ids[param]
                        break
            if (not findAction(curr_act, list(mc.actions.values())) is None):
                asd= true;
            mc.addAction(curr_act,index)
            if (fulfills(mc, rc)):
                priorityMatches.add((getPosInLog(mc),(mc,rc)))
            else:
                newOlActions = []
                for newIndex in range(logIndex+1, len(ol)):
                    newOlActions.append(deepcopy(ol[newIndex]))
                findMatch(rc, newOlActions, priorityMatches, mc)


def findMatchForAction(rc, ol, priorityMatches, mc, currAct):
    """depth first search for actions in the log which match the given recipe"""
    ol_new=deepcopy(ol)
    mc = match(0)
    curr_act=findAction(currAct, ol_new)
    ol_new.remove(curr_act)
    indexExtendes = tryExtends(curr_act, mc, rc, -1);
    while (indexExtendes!= -1):
        for param in list(curr_act.ids.keys()):
                for rec_param in rc.rhs[indexExtendes].ids:
                    j = rec_param.find('_')
                    if j != -1:
                        paramForCheck = rec_param[:j]
                    else:
                        paramForCheck = rec_param
                    if (param==paramForCheck):
                        curr_act.ids[paramForCheck]=curr_act.ids[param]
                        if not (paramForCheck==param):
                            del curr_act.ids[param]
                        break
        if (not findAction(curr_act, list(mc.actions.values())) is None):
                asd= True;
        mc.addAction(curr_act,indexExtendes)
        if (fulfills(mc, rc)):
            priorityMatches.add((getPosInLog(mc),(mc,rc)))
        else:
            findMatchForActionRec(rc, ol_new, priorityMatches, mc)
            
        mc = match(0)
        indexExtendes = tryExtends(curr_act, mc, rc, indexExtendes);
                

def findMatchForActionRec(rc, ol, priorityMatches, mc):
    """depth first search for actions in the log which match the given recipe"""
    ol_new=deepcopy(ol)
    newMc = deepcopy(mc)
    #go over actions in log, for each action, try to add it to the current match. backtrack if failed
    for logIndex in range(0, len(ol)):
        mc = deepcopy(newMc)
        act = deepcopy(ol[logIndex])
        curr_act=findAction(act, ol_new)
        ol_new.remove(curr_act)
        index=extends(curr_act, mc, rc)
        if (index>-1):
            #the action can be added to the match, update its parameters (ie make sid sid_1, etc.)
            for param in list(curr_act.ids.keys()):
                for rec_param in rc.rhs[index].ids:
                    j = rec_param.find('_')
                    if j != -1:
                        paramForCheck = rec_param[:j]
                    else:
                        paramForCheck = rec_param
                    if (param==paramForCheck):
                        curr_act.ids[paramForCheck]=curr_act.ids[param]
                        if not (paramForCheck==param):
                            del curr_act.ids[param]
                        break
            if (not findAction(curr_act, list(mc.actions.values())) is None):
                asd= true;
            mc.addAction(curr_act,index)
            if (fulfills(mc, rc)):
                priorityMatches.add((getPosInLog(mc),(mc,rc)))
            else:
                newOlActions = []
                for newIndex in range(logIndex+1, len(ol)):
                    newOlActions.append(deepcopy(ol[newIndex]))
                findMatchForActionRec(rc, newOlActions, priorityMatches, mc)



def checkMatchBetween(recipes, ol, oldOl,plan, actionsUsed, oldPM):
    """function that check if there match between first and last index and update the plan respectively"""
    PM = priorityQueueOfMatches()
    for rc in recipes:
        mc = match(0)
        findMatch(rc, ol, PM, mc)
        
    if (len(PM.heap) > 0):
        thereMatches = True
    else:
        thereMatches = False
        
    while (thereMatches):  
        minMatch = PM.extract_min()
        firstIndex, lastIndex = minMatch[0]
        mc,rc = minMatch[1]
                        
                        
        #check matches between the actions composed this match:
        if (firstIndex != lastIndex):
            newOl = []
            firstAction = mc.actions[0]
            lastAction = mc.actions[len(mc.actions)-1]
            for act in ol:
                if (act.firstPos > firstIndex and act.lastPos <= lastIndex):
                    newOl.append(act)
            if (len(newOl) > 0):
                checkMatchBetween(recipes, newOl, oldOl, plan, actionsUsed, oldPM)
                
        
        
        if (len(PM.heap) > 0):
            thereMatches = True
        else:
            thereMatches = False  
        #check if the actions were used already
        isUsed = False
        for a in mc.actions: #iterates over the children of the complex action in the match
            if (not findAction(mc.actions[a], actionsUsed) is None):
                isUsed = True
        if(isUsed == True):
            continue
        
        c=deepcopy(rc.lhs)
        updateParams(c, mc, rc) # updates the parameters of the complex action
        c.id_num=mc.lastIndex
             
        plan.insert(findActionIndex(mc.lastIndex,plan)+1, c) # inserts the complex action to the current "P" (i.e. current list of actions)
        oldOl.insert(findActionIndex(mc.lastIndex,oldOl)+1, c) # inserts complex action to the current open list we're modifying
        ol.insert(findActionIndex(mc.lastIndex,ol)+1, c)
        for a in mc.actions: #iterates over the children of the complex action in the match
            actionsUsed.append(mc.actions[a])
            c.addChild(mc.actions[a]) # add child to complex action
            #need to add the remove attribute, and make sure it appears in the action that goes in to the match
            if (rc.rhs[a].remove is True): #check if this action is supposed to stay in log - Oriel, this condition is always true (we used to have situation where it wasn't but not relevant now)
                toRemove=findAction(mc.actions[a], plan)
                plan.remove(toRemove) # remove the action from the current plan 
                oldOl.remove(toRemove) # remove the action from current open linst
                ol.remove(toRemove)
                
        for rc in recipes:
            mc = match(0)
            findMatchForAction(rc, ol, PM, mc, c)
            findMatchForAction(rc, oldOl, oldPM, mc, c)
        
        
        if (len(PM.heap) > 0):
            thereMatches = True
        else:
            thereMatches = False



def buildPlan(recipes, log):
    """calls findMatch to match actions with recipes, iteratively builds a plan"""
    priorityMatches = priorityQueueOfMatches()
    ol=deepcopy(log)
    numAct = 1;
    for act in ol:
        act.firstPos = numAct
        act.lastPos = numAct
        numAct = numAct + 1
    p={}
    p[0]=deepcopy(ol)
    i=1
    for rc in recipes:
        mc = match(0)
        findMatch(rc, ol, priorityMatches, mc)
        
    if (len(priorityMatches.heap) > 0):
        thereMatches = True
    else:
        thereMatches = False
        
    actionsUsed = []    
    while (thereMatches):  
        minMatch = priorityMatches.extract_min()
        firstIndex, lastIndex = minMatch[0]
        mc,rc = minMatch[1]
        
        #check matches between the actions composed this match:
        if (firstIndex != lastIndex):
            newOl = []
            firstAction = mc.actions[0]
            lastAction = mc.actions[len(mc.actions)-1]
            for act in ol:
                if (act.firstPos > firstIndex and act.lastPos <= lastIndex and act.firstPos<=act.lastPos):
                    newOl.append(act)
            if (len(newOl) > 0):
                checkMatchBetween(recipes, newOl, ol, p[i-1], actionsUsed, priorityMatches)
                
          
        if (len(priorityMatches.heap) > 0):
            thereMatches = True
        else:
            thereMatches = False   
        #check if the actions were used already
        isUsed = False
        for a in mc.actions: #iterates over the children of the complex action in the match
            if (not findAction(mc.actions[a], actionsUsed) is None):
                isUsed = True
        if(isUsed == True):
            continue
        
        c=deepcopy(rc.lhs)
        updateParams(c, mc, rc) # updates the parameters of the complex action
        c.id_num=mc.lastIndex
        
        p[i]=deepcopy(p[i-1])
        ol=deepcopy(p[i-1])
        
        p[i].insert(findActionIndex(mc.lastIndex,p[i])+1, c) # inserts the complex action to the current "P" (i.e. current list of actions)
        ol.insert(findActionIndex(mc.lastIndex,ol)+1, c) # inserts complex action to the current open list we're modifying
        for a in mc.actions: #iterates over the children of the complex action in the match
            actionsUsed.append(mc.actions[a])
            c.addChild(mc.actions[a]) # add child to complex action
            #need to add the remove attribute, and make sure it appears in the action that goes in to the match
            if (rc.rhs[a].remove is True): #check if this action is supposed to stay in log - Oriel, this condition is always true (we used to have situation where it wasn't but not relevant now)
                toRemove=findAction(mc.actions[a], p[i])
                p[i].remove(toRemove) # remove the action from the current plan 
                ol.remove(toRemove) # remove the action from current open linst
        if i==4:
            asd=23
              
        for rc in recipes:
            mc = match(0)
            findMatchForAction(rc, ol, priorityMatches, mc, c)
        
        if (len(priorityMatches.heap) > 0):
            thereMatches = True
        else:
            thereMatches = False
            
        i=i+1

    return p    

#-------------------------------algorithm methods end----------------------------------------------------


#-------------------------------utility methods----------------------------------------------------
def computeDistance(mc):
    dist = 0
    firstPos = 99999999
    lastPos = 0
    for action in list(mc.actions.values()):
        firstPos = min(firstPos, action.firstPos)
        lastPos = max(lastPos, action.lastPos)
    dist = lastPos - firstPos
    #if (len(mc.actions) > 0):
        #minIndex = mc.actions[0].posInSM
        #maxIndex = mc.actions[0].posInSM
        #for a in mc.actions: #iterates over the children of the complex action in the match
           # pos = mc.actions[a].posInSM
           # if (pos > maxIndex):
            #    maxIndex = pos
           # if (pos < minIndex):
           #     minIndex = pos
    #    dist = maxIndex - minIndex
    return dist
                    

def getPosInLog(mc):
    firstPos = 99999999
    lastPos = 0
    for action in list(mc.actions.values()):
        firstPos = min(firstPos, action.firstPos)
        lastPos = max(lastPos, action.lastPos)
    pos = (firstPos, lastPos)
    return pos


def findIndexOfAction(action, ol):
    for act in ol:
        sad
    return index


def findAction(action, _list):
    for ac in _list:
        if (action==ac):
            return ac
    return None
    
def findActionIndex(num, _list):
    for ac in _list:
        if (num==ac.id_num):
            return _list.index(ac)
    return None

def updateParams(comp_action, match, rc):
    """when a match is found, need to update the parameters of the complex action created"""
    j=0;
    comp_action.uniqueID=random.randint(0,100000)
    """
    compName = "C"
    if (len(rc.cons) >0):
        leftCons=['0','did']
        rightCons=['1','sid']
        if (leftCons == rc.cons[0][0] and rightCons == rc.cons[0][1]):
            compName = "D"
        else:
            leftCons=['0','did']
            rightCons=['1','did']
            if (leftCons == rc.cons[0][0] and rightCons == rc.cons[0][1]):
                compName = "C"
    if (compName=='C' and len(match.actions)==2):
        a=float(match.actions[0].ids['vol'])
        b=float(match.actions[1].ids['vol'])
        comp_action.ids['vol']=float(match.actions[0].ids['vol'])+float(match.actions[1].ids['vol'])
    """
  
    """  
    if(compName=="D"):
        k=5
    """
    for param in list(comp_action.ids.keys()):
        j = param.find("_")
        if j != -1:
            val = comp_action.ids[param]
            del comp_action.ids[param];
            comp_action.ids[param[:j]]=val;
    
    comp_action.firstPos = 9999999
    comp_action.lastPos = 0
    for action in list(match.actions.values()):
        for param in list(action.ids.keys()):
            if (param in comp_action.ids):
                del comp_action.ids[param];
                comp_action.ids[param]=action.ids[param]
                j=j+1
        comp_action.firstPos = min(comp_action.firstPos,action.firstPos)
        comp_action.lastPos = max(comp_action.lastPos,action.lastPos)   
    #apply the effects
    '''
    for eff in rc.effects:
        actionsOfMatch = list(match.actions.values())
        #print(actionsOfMatch[int(eff[1][0][0])])
        #print(comp_action.ids[eff[0][0]])
        #print(actionsOfMatch[int(eff[1][0][0])].ids[eff[1][1][0]])
        comp_action.ids[eff[0][0]] = actionsOfMatch[int(eff[1][0][0])].ids[eff[1][1][0]]
        if (len(eff) > 2):
            for index in range(2, len(eff)):
                comp_action.ids[eff[0][0]] =  float(comp_action.ids[eff[0][0]]) + float(actionsOfMatch[int(eff[index][0][0])].ids[eff[index][1][0]])
        ads=123
    '''
    
    return

def findLastIndex(mc,ol):
    index=0
    for a in mc.actions:
        i=ol.index(a)
        if (i<index):
            index=i
    return index

# print tree by xml
def printXML(log, start):
    for a in log:
        if a.name == start:
            printXML2(a, 0)
    
def printXML2(a, indent):
    print('%s%s' %('\t'*indent, a.toxml()))

    indices = []
    for child in a.children:
        indices.append(child.getIndex())
    d = {}
    for i in range(len(indices)):
        d[indices[i]] = i
    indices.sort()
        
    # to output in the order in the recipes simply do:
    # for child in a.children():
    
    for index in indices:
        child = a.children[d[index]]
        if child.children: # if you have grand children
            printXML2(child, indent+1)
        else: # if your child is a leaf
            print('%s%s' %('\t'*(indent+1), child.toxmlleaf()))

    print('%s</%s>' %('\t'*indent, a.name))

        
        
# str is something like A[x_1,y][0,1]
# which represents an action A parametrized by x_1 and y and has the precondition actions indexed 0 and 1 in the recipe
# so this action A should have index >= 2 in the recipe
# if the thing is not parametrized or has preconditions then A[][] should work for str
def parseAction(str):
    
    remove=True
    pat = re.compile('([A-Za-z0-9]+)\[(.*?)\]\[(.*?)\]')
    str = pat.sub('\g<1>~\g<2>~\g<3>', str)
    str = str.split('~')
    name = str[0]
    
    d = {} # dictionary for ids
    if str[1]:
        ids = str[1].split(',')
        for x in ids:
            if x.find(':') != -1: (x1,x2) = x.split(':') # (like [x:R])
            else: (x1,x2) = (x,None) # (like [x])

            d[x1] = x2 # (like [x: ... ])
    
    if 'leave' in d:
        remove=False
    l = [] # list for preconditions
    if str[2]:
        pcons = str[2].split(',')
        for p in pcons:
            l.append(int(p))
    
    return action(name, d, l, remove)
    
#-------------------------------utility methods end----------------------------------------------------

#-------------------------------log processing methods--

class actionForLog:
    def __init__(self, name, ids, pcons):
        self.name = name # is the name of an action
        self.ids = ids # is a dictionary from ids to their values
        self.pcons = pcons # is a list of precondition action indices in the rhs of the recipe
        self.children = [] # is a list of children actions (used in tree outputting)
        self.index = 0 # index into the log, for low level ones
        self.minIndexBelow = 0 # min index into the log, for high level ones
        
    def __str__(self):
        ret = '( %s' %self.name
        for key in self.ids:
            if self.ids[key]:
                ret += ' , %s=%s' %(key, self.ids[key]) # if key[1] None
            else:
                if key: ret += '%s' %(key)
                else: ret += '%s' %key
        if ret[-1] == ' , ': ret = ret[:-1]
        ret = '%s )' %ret
        return ret
        
    def toxml(self):
        ret = '<%s ' %self.name
        ids = list(self.ids.keys())
        ids.sort()
        for key in ids:
            if self.ids[key]:
                if key[1]: ret += '%s=\"%s\" ' %(key, self.ids[key]) # if key[1] not None
                else: ret += '%s=\"%s\" ' %(key, self.ids[key]) # if key[1] None
            else:
                if key[1]: ret += '%s ' %(key)
                else: ret += '%s ' %key
        ret += 'pos=\"%d\">' %(self.getIndex()-1) # swapna uses 0-based indices
        return ret
        
    def toxmlleaf(self):
        ret = '<%s ' %self.name
        ids = list(self.ids.keys())
        ids.sort()
        for key in ids:
            if self.ids[key]:
                if key: ret += '%s=\"%s\" ' %(key, self.ids[key]) # if key[1] not None
                else: ret += '%s=\"%s\" ' %(key, self.ids[key]) # if key[1] None
            else:
                if key[1]: ret += '%s ' %(key)
                else: ret += '%s ' %key
        ret += 'pos=\"%d\"/>' %(self.getIndex()-1) # swapna uses 0-based indices
        return ret
    
    def getIndex(self):
        if self.index: return self.index
        elif self.minIndexBelow: return self.minIndexBelow
        else: raise
    
    def addChild(self, child):
        self.children.append(child)
        index = child.getIndex()
        if self.minIndexBelow == 0 or self.minIndexBelow > index:
            self.minIndexBelow = index
    def getName(self):
        return self.name
    def getParams(self):
        return self.ids
            

def parseSolMix(line):
    
    params={}
    words=line.split()
    params["vol"]=words[0]
    st_start=words.index("from")+1
    s_type=words[st_start]
    for i in range(st_start+1, len(words)):
        if not(words[i].startswith("(")):
            s_type=s_type+" "+words[i]
        else:
            sid=words[i].strip("(,)")
            break
        
    params["st"]=s_type
    params["sid"]=sid
    s_con_det=""
    sc_start=words.index("contains")+1
    s_con=words[sc_start]
    for i in range(sc_start+1, len(words)):
        if not(words[i].startswith("(")):
            s_con=s_con+"_"+words[i]
        else:
            for j in range(i, len(words)):
                if not(words[j].endswith(";")):
                    s_con_det=s_con_det+" "+words[j].strip("(")
                else:
                    s_con_det=s_con_det+" "+words[j].strip(";")
                    break
            break
    params["sc"]=s_con
    params["scd"]=s_con_det
    params["svol"] = words[j+1].strip("V=");
    
    dt_start=words.index("into")+1
    d_type=words[dt_start]
    for i in range(dt_start+1, len(words)):
        if not(words[i].startswith("(")):
            d_type=d_type+" "+words[i]
        else:
            did=words[i].strip("(,)")
            break
        
    params["dt"]=d_type
    params["did"]=did
    
    words.remove("contains")
    dc_start=words.index("contains")+1
    d_con=words[dc_start]
    d_con_det=""
    for i in range(dc_start+1, len(words)):
        if not(words[i].startswith("(")):
            d_con=d_con+" "+words[i]
        else:
            for j in range(i, len(words)):
                if not(words[j].endswith(";")):
                    d_con_det=d_con_det+" "+words[j].strip("(")
                else:
                    d_con_det=d_con_det+" "+words[j].strip(";")
                    break
            break
        
    params["dc"]=d_con
    if (d_con_det != " ("):
        params["dcd"]=d_con_det
    else:
        params["dcd"]="Empty"
    params["dvol"] = words[j+1].strip("V=");
    rc_start=words.index("resulting")+1
    r_con_det=""
    for i in range(rc_start+1, len(words)):
        if (words[i].startswith("(")):
            for j in range(i, len(words)):
                if not(words[j].endswith(";")):
                    r_con_det=r_con_det+" "+words[j].strip("(")
                else:
                    r_con_det=r_con_det+" "+words[j].strip(";")
                    break
            break
        
    params["rcd"]=r_con_det
    
    params["rvol"] = words[j+1].strip("V=");
    
    ret=actionForLog("SM", params, [])
    return ret

def parseMoveObj(line):
    params={}
    words=line.split()
    ot_start=words.index("component/s:")+1
    o_type=words[ot_start]
    for i in range(ot_start+1, len(words)):
        if not(words[i].startswith("(")):
            o_type=o_type+" "+words[i]
        else:
            oid=words[i].strip("(,)")
            break
    
    params["t"]=o_type
    params["id"]=oid    
    ret=actionForLog("MO", params, [])
    return ret

def parseFlaskCon(line):
    
    params={}
    words=line.split()
    st_start=1
    s_type=words[1]
    for i in range(st_start+1, len(words)):
        if not(words[i].startswith("(")):
            s_type=s_type+" "+words[i]
        else:
            sid=words[i].strip("(,)")
            break
        
    params["st"]=s_type
    params["sid"]=sid
        
    dt_start=words.index("the")+1
    d_type=words[dt_start]
    for i in range(dt_start+1, len(words)):
        if not(words[i].startswith("(")):
            d_type=d_type+" "+words[i]
        else:
            did=words[i].strip("(,),.")
            break
        
    params["dt"]=d_type
    params["did"]=did
    ret=actionForLog("FC", params, [])
    return ret

def parseAddSol(line):
    params={}
    words=line.split()
    st_start=1
    empty=0
    if (words[st_start]=="empty"):
        st_start=st_start+1
        empty=1
    s_type=words[st_start]
    for i in range(st_start+1, len(words)):
        if not(words[i].startswith("(")):
            s_type=s_type+" "+words[i]
        else:
            sid=words[i].strip("(,)")
            break
        
    if (empty==1):
        params["c"]="empty"
    else:
        c_start=words.index("is:")+1
        c=words[c_start]
        for i in range(c_start+1, len(words)):
            if not(words[i].startswith("(")):
                c=c+"_"+words[i]
            else:
                break
        params["c"]=c
        
        
    params["t"]=s_type
    params["id"]=sid
    ret=actionForLog("AF", params, [])
    return ret

def parseLoadProb(line):
    params={}
    words=line.split()
    params["p"]=words[2]
    ret=actionForLog("LP", params, [])
    return ret


def parseProblemStart(line):
    params={}
    words=line.split(': ')
    params["p"]=words[1]
    ret=actionForLog("PS", params, [])
    return ret

def parseFormCheck(line):
    params={}
    indexBegin=0
    indexLast = 0
    params["c"]="correct"
    if (line.find("Correct")==-1):
        params["c"]="wrong"
    indexBegin = line.find("The correct value is") + 21
    newLine = line[indexBegin:len(line)]
    indexLast = newLine.find(".")
    answer = newLine[0:indexLast]
    index = newLine.find("-->")
    if (index > -1):
       newLine = newLine[0:index] + " = " + newLine[index+3:indexLast]
       words = newLine.split('  ')
       answer = words[0]
       i=1
       while (words[i] != '='):
           answer = answer + " + " + words[i]
           i = i+1
       i=i+2
       answer = answer + " CREATE: " + words[i-1]
       while (i < len(words)):
           answer = answer + " + " + words[i]
           i=i+1
    params["realAnswer"] = answer
    ret=actionForLog("FOC", params, [])
    return ret

def parseRemove(line):
    
    params={}
    words=line.split()
    st_start=1
    s_type=words[1]
    for i in range(st_start+1, len(words)):
        if not(words[i].startswith("(")):
            s_type=s_type+" "+words[i]
        else:
            sid=words[i].strip("(,)")
            break
        
    params["t"]=s_type
    params["id"]=sid
    ret= actionForLog("RM", params, [])
    return ret

def parseSetThermal(line):
    params={}
    words=line.split()
    st_start=1
    for i in range(st_start, len(words)):
        if (words[i].endswith(")")):
            idlong=words[i].strip("(,)")
            j=idlong.find("ID")
            id=idlong[j:len(idlong)]
            st_start=i
            break
        
    
    temp=words[st_start+8].strip(".");
    if (words[st_start+13]=="insulated."):
        ins = "true"
    else:
        ins="false"
    

    params["id"]=id
    params["temp"]=temp
    params["insulated"]=ins
    ret=actionForLog("ST", params, [])
    return ret

def parseActionForLog(actionForLog, actionType):
    
    takeaction = {
            "WORKBENCH_ADD_FLASK": parseAddSol,
            "SOLUTION_MIX": parseSolMix,
            "WORKBENCH_MOVE_OBJECT": parseMoveObj,
            "WORKBENCH_FLASKS_CONNECT": parseFlaskCon,
            "VLAB_LOAD_PROBLEM": parseLoadProb,
            "PROBLEM_START": parseProblemStart,
            "WORKBENCH_REMOVE": parseRemove,
            "SOLUTION_SET_THERMAL":parseSetThermal,
            "FORM_CHECK": parseFormCheck}
    
    #due to problem with form_check actions xml in all logs, parsed differently
    if (actionType=="FORM_CHECK"):
        a=parseFormCheck(actionForLog)    
        return a
    
    file = open("action.xml","w")
    file.write(actionForLog)
    file.close()
    xmldoc=minidom.parse('action.xml')
    desc=xmldoc.getElementsByTagName("description")[0]
    
    if (actionType in takeaction):
        a=takeaction.get(actionType)(desc.childNodes[0].data)
        return a
    else:
        return None
    

def readXlsLogs(log):
    wb=xlrd3.open_workbook(log)
    sh = wb.sheet_by_index(0)
    log_id = sh.cell(0,1).value
    #print id
    i=0
    index=1
    actions=[] 
    prob_name=""
    while not (i==sh.nrows):
        log_id = sh.cell(i,1).value
        while (sh.cell(i,1).value==log_id):
            a=parseActionForLog(sh.cell(i,9).value, sh.cell(i,5).value)
            
            if not (a==None):
                if (a.getName()=="LP"):
                    prob_name=a.ids["p"]           
                actions.append(a)
                #print a        
            i=i+1
            #print i
            if (i==sh.nrows):
                break
            
        file = open("log.txt",'w+')
        for act in actions:
            file.write(str(act))
            file.write("\n")
        file.close()
        del actions[:]
        #print i
        index=index+1
        
    return file

def readTxtLogs(log):
    logfile = open(log,'rt')
    actions=[] 
    for line in logfile:
        line = line.replace('"','')
        lineValues=line.split('\t')
        a=parseActionForLog(lineValues[9], lineValues[5])
        
        if not (a==None):
            if (a.getName()=="LP"):
                prob_name=a.ids["p"]            
            actions.append(a)

    file = open("log.txt",'w+')
    for act in actions:
        file.write(str(act))
        file.write("\n")
    file.close()
    del actions[:]
        #print i
        
    return file

#-------------------------------log processing methods end--

#-------------------------------main-----------------------------------------------------------------
def initPL():
    
    # Sigmas
    sigma_C = Sigma.Sigma('C', [])
    sigma_CC = Sigma.Sigma('CC', ['p'])
    sigma_CCD = Sigma.Sigma('CCD', ['s','d'])
    sigma_CDT = Sigma.Sigma('CDT', ['s','d','dt'])
    sigma_ChC = Sigma.Sigma('ChC', ['com'])
    sigma_CRT = Sigma.Sigma('CRT', [])
    sigma_CSM = Sigma.Sigma('CSM', ['s']) 
    sigma_DAE = Sigma.Sigma('DAE', ['s','d','ei','el'])
    sigma_DCE = Sigma.Sigma('DCE', ['s','d','ei','el'])
    sigma_DrA = Sigma.Sigma('DrA', ['p', 'ax', 'n', 'ai', 't', 's', 'nb', 'bi_0', 'l_0', 'bi_1', 'l_1', 'bi_2', 'l_2', 'bi_3', 'l_3'])
    sigma_DS = Sigma.Sigma('DS', ['s'])
    sigma_DT = Sigma.Sigma('DT', ['t'])
    sigma_MS = Sigma.Sigma('MS', ['s','d','ei','el'])
    sigma_MU = Sigma.Sigma('MU', ['p'])
    sigma_NA = Sigma.Sigma('NA', ['t','s','ai','n'])
    sigma_NP = Sigma.Sigma('NP', ['p'])   
    sigma_NS = Sigma.Sigma('NS', ['s'])
    sigma_NT = Sigma.Sigma('NT', ['t','s'])
    sigma_PO = Sigma.Sigma('PO', ['s','p'])
    sigma_Per = Sigma.Sigma('Per', ['p'])
    sigma_R = Sigma.Sigma('R', ['s', 'ai','t'])
    sigma_RB = Sigma.Sigma('RB', ['p', 'ax', 'n', 'rbi', 'ibi'])
    sigma_RS = Sigma.Sigma('RS', ['s', 'd','ss'])
    sigma_S = Sigma.Sigma('S', ['p'])
    sigma_SA = Sigma.Sigma('SA', ['com'])
    sigma_SAB = Sigma.Sigma('SAB', ['p','ax','n'])
    sigma_SAD = Sigma.Sigma('SAD', ['s','d','dt'])
    sigma_SDS = Sigma.Sigma('SDS', ['s','ds'])
    sigma_SR= Sigma.Sigma('SR', ['s','r'])
    sigma_SRP = Sigma.Sigma('SRP', [])
    sigma_SwA = Sigma.Sigma('SwA', ['p'])
    sigma_MR = Sigma.Sigma('MR', ['s','d'])

    # NTs
    NT_C = NT.NT('C', [])
    NT_CC = NT.NT('CC', ['p'])
    NT_CCD = NT.NT('CCD', ['s','d'])
    NT_CDT = NT.NT('CDT', ['s','d','dt'])
    NT_ChC = NT.NT('ChC', ['com'])
    NT_CRT = NT.NT('CRT', [])
    NT_CSM = NT.NT('CSM', ['s']) 
    NT_DAE = NT.NT('DAE', ['s','d','ei','el'])
    NT_DCE = NT.NT('DCE', ['s','d','ei','el'])
    NT_DrA = NT.NT('DrA', ['p', 'ax', 'n', 'ai', 't', 's', 'nb', 'bi_0', 'l_0', 'bi_1', 'l_1', 'bi_2', 'l_2', 'bi_3', 'l_3'])
    NT_DS = NT.NT('DS', ['s'])
    NT_DT = NT.NT('DT', ['t'])
    NT_MS = NT.NT('MS', ['s','d','ei','el'])
    NT_MU = NT.NT('MU', ['p']) 
    NT_NA = NT.NT('NA', ['t','s','ai','n'])
    NT_NP = NT.NT('NP', ['p'])   
    NT_NS = NT.NT('NS', ['s'])
    NT_NT = NT.NT('NT', ['t','s'])
    NT_PO = NT.NT('PO', ['s','p'])
    NT_Per = NT.NT('Per', ['p'])
    NT_R = NT.NT('R', ['s', 'ai','t'])
    NT_RB = NT.NT('RB', ['p', 'ax', 'n', 'rbi', 'ibi'])
    NT_RS = NT.NT('RS', ['s', 'd','ss'])
    NT_S = NT.NT('S', ['p'])
    NT_SA = NT.NT('SA', ['com'])
    NT_SAB = NT.NT('SAB', ['p','ax','n'])
    NT_SAD = NT.NT('SAD', ['s','d','dt'])
    NT_SDS = NT.NT('SDS', ['s','ds'])
    NT_SR= NT.NT('SR', ['s','r'])
    NT_SRP = NT.NT('SRP', [])
    NT_SwA = NT.NT('SwA', ['p'])
    NT_MR = NT.NT('MR', ['s','d'])    
    
    # Simple NT -> sigma Rules
    simple_C = Rule.Rule(NT_C, [sigma_C], [], [])
    simple_CC = Rule.Rule(NT_CC, [sigma_CC], [], [(-1, 'p', 0, 'p')])
    simple_CCD = Rule.Rule(NT_CCD, [sigma_CCD], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd')])
    simple_CDT = Rule.Rule(NT_CDT, [sigma_CDT], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'dt', 0, 'dt'),(0,'dt','Spinner')])
    simple_ChC = Rule.Rule(NT_ChC, [sigma_ChC], [], [(-1, 'com', 0, 'com')])
    simple_CRT = Rule.Rule(NT_CRT, [sigma_CRT], [], [])
    simple_CSM = Rule.Rule(NT_CSM, [sigma_CSM], [], [(-1, 's', 0, 's')]) 
    simple_DAE = Rule.Rule(NT_DAE, [sigma_DAE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(-1, 'el', 0, 'el')])
    simple_DAEr = Rule.Rule(NT_DAE, [sigma_DAE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','r'),(-1, 'el', 0, 'el')])
    simple_DAER = Rule.Rule(NT_DAE, [sigma_DAE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','R'),(-1, 'el', 0, 'el')])
    simple_DAEo = Rule.Rule(NT_DAE, [sigma_DAE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','o'),(-1, 'el', 0, 'el')])
    simple_DAEO = Rule.Rule(NT_DAE, [sigma_DAE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','O'),(-1, 'el', 0, 'el')])
    simple_DAEs = Rule.Rule(NT_DAE, [sigma_DAE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','s'),(-1, 'el', 0, 'el')])
    simple_DAES = Rule.Rule(NT_DAE, [sigma_DAE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','S'),(-1, 'el', 0, 'el')])
    simple_DAEa = Rule.Rule(NT_DAE, [sigma_DAE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','a'),(-1, 'el', 0, 'el')])
    simple_DAEA = Rule.Rule(NT_DAE, [sigma_DAE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','A'),(-1, 'el', 0, 'el')])
    simple_DCE = Rule.Rule(NT_DCE, [sigma_DCE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(-1, 'el', 0, 'el')])
    simple_DCEr = Rule.Rule(NT_DCE, [sigma_DCE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','r'),(-1, 'el', 0, 'el')])
    simple_DCER = Rule.Rule(NT_DCE, [sigma_DCE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','R'),(-1, 'el', 0, 'el')])
    simple_DCEo = Rule.Rule(NT_DCE, [sigma_DCE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','o'),(-1, 'el', 0, 'el')])
    simple_DCEO = Rule.Rule(NT_DCE, [sigma_DCE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','O'),(-1, 'el', 0, 'el')])
    simple_DCEs = Rule.Rule(NT_DCE, [sigma_DCE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','s'),(-1, 'el', 0, 'el')])
    simple_DCES = Rule.Rule(NT_DCE, [sigma_DCE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','S'),(-1, 'el', 0, 'el')])
    simple_DCEa = Rule.Rule(NT_DCE, [sigma_DCE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','a'),(-1, 'el', 0, 'el')])
    simple_DCEA = Rule.Rule(NT_DCE, [sigma_DCE], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(0,'el','A'),(-1, 'el', 0, 'el')])
    simple_DrA = Rule.Rule(NT_DrA, [sigma_DrA], [], [(-1, 'p', 0, 'p'),(-1, 'ax', 0, 'ax'),(-1, 'n', 0, 'n'),(-1, 'ai', 0, 'ai'),(-1, 't', 0, 't'),(-1, 's', 0, 's'),(-1, 'nb', 0, 'nb'),
                                                          (-1, 'bi_0', 0, 'bi_0'),(-1,'l_0',0,'l_0'),(-1, 'bi_1', 0, 'bi_1'),(-1,'l_1',0,'l_1'),(-1, 'bi_2', 0, 'bi_2'),(-1,'l_2',0,'l_2'),(-1, 'bi_3', 0, 'bi_3'),(-1,'l_3',0,'l_3'),(0,'n','Outcome')])
    simple_DS = Rule.Rule(NT_DS, [sigma_DS], [], [(-1, 's', 0, 's')])
    simple_DT = Rule.Rule(NT_DT, [sigma_DT], [], [(-1, 't', 0, 't')])
    simple_MS = Rule.Rule(NT_MS, [sigma_MS], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(-1, 'el', 0, 'el')])
    simple_MU = Rule.Rule(NT_MU, [sigma_MU], [], [(-1, 'p', 0, 'p')])
    simple_NA = Rule.Rule(NT_NA, [sigma_NA], [], [(-1, 't', 0, 't'),(-1, 's', 0, 's'),(-1, 'ai', 0, 'ai'),(0,'n','Outcome'),(-1, 'n', 0, 'n')])
    simple_NP = Rule.Rule(NT_NP, [sigma_NP], [], [(-1, 'p', 0, 'p')])   
    simple_NS = Rule.Rule(NT_NS, [sigma_NS], [], [(-1, 's', 0, 's')])
    simple_NT = Rule.Rule(NT_NT, [sigma_NT], [], [(-1, 's', 0, 's'),(-1, 't', 0, 't')])
    simple_PO = Rule.Rule(NT_PO, [sigma_PO], [], [(-1, 's', 0, 's'),(-1, 'p', 0, 'p')])
    simple_Per = Rule.Rule(NT_Per, [sigma_Per], [], [(-1, 'p', 0, 'p')])
    simple_R = Rule.Rule(NT_R, [sigma_R], [], [(-1, 's', 0, 's'),(-1, 'ai', 0, 'ai'),(-1, 't', 0, 't')])
    simple_RB = Rule.Rule(NT_RB, [sigma_RB], [], [(-1, 'p', 0, 'p'),(-1, 'ax', 0, 'ax'),(-1, 'n', 0, 'n'),(-1, 'rbi', 0, 'rbi'),(-1, 'ibi', 0, 'ibi')])
    simple_RS = Rule.Rule(NT_RS, [sigma_RS], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ss', 0, 'ss'),(0,'ss','0.5')])
    simple_S = Rule.Rule(NT_S, [sigma_S], [], [(-1, 'p', 0, 'p')])
    simple_SA = Rule.Rule(NT_SA, [sigma_SA], [], [(-1, 'com', 0, 'com')])
    simple_SAB = Rule.Rule(NT_SAB, [sigma_SAB], [], [(-1, 'p', 0, 'p'),(-1, 'ax', 0, 'ax'),(-1, 'n', 0, 'n')])
    simple_SAD = Rule.Rule(NT_SAD, [sigma_SAD], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'dt', 0, 'dt')])
    simple_SDS = Rule.Rule(NT_SDS, [sigma_SDS], [], [(-1, 's', 0, 's'),(-1, 'ds', 0, 'ds')])
    simple_SR= Rule.Rule(NT_SR, [sigma_SR], [], [(-1, 's', 0, 's'),(-1, 'r', 0, 'r')])
    simple_SRP = Rule.Rule(NT_SRP, [sigma_SRP], [], [])
    simple_SwA = Rule.Rule(NT_SwA, [sigma_SwA], [], [(-1, 'p', 0, 'p')])
    simple_MR = Rule.Rule(NT_MR, [sigma_MR], [], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd')])
    
    # Real Rules
    #C[p][] -> CC[p][]
    rule1 = Rule.Rule(NT_C, [NT_CC], [], [(-1, 'p', 0, 'p')])
    #C[p][] -> Per[p][]
    rule2 = Rule.Rule(NT_C, [NT_Per], [], [(-1, 'p', 0, 'p')])
    #PO[s,p][] -> NT[t][] NA[s,t,n:Outcome][0] NP[p][] DrA[t,p,n:Outcome][0,2] C[p][2]
    rule3 = Rule.Rule(NT_PO, [NT_NT, NT_NA, NT_NP, NT_DrA, NT_C], [(0,1),(0,3),(2,3),(2,4)], [(-1, 's', 1, 's'),(-1, 'p', 2, 'p'),(-1, 'p', 3, 'p'),(-1, 'p', 4, 'p'),(0, 't', 1, 't'),(0, 't', 3, 't'),(1, 't', 3, 't'),(1,'n',3,'n')])
    #DAE[s,d,ei,el][] -> DAE[s,d,ei][] DCE[s,d,ei,el][0]
    rule4 = Rule.Rule(NT_DAE, [NT_DAE, NT_DCE], [(0,1)], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(-1, 's', 1, 's'),(-1, 'd', 1, 'd'),(-1, 'ei', 1, 'ei'),(-1, 'el', 1, 'el')])
    #CCD[s,d][] -> SAD[s,d][] CDT[s,d,dt:Spinner][0] RS[s,d,ss:0.5][1]
    rule5 = Rule.Rule(NT_CCD, [NT_SAD, NT_CDT, NT_RS], [(0,1),(1,2)], [(-1, 's', 0, 's'),(-1, 's', 1, 's'),(-1, 's', 2, 's'),(-1, 'd', 0, 'd'),(-1, 'd', 1, 'd'),(-1, 'd', 2, 'd')])
    #CCD[s,d][] -> SAD[s,d][] DAE[s,d,ei_1,el_1][0] DAE[s,d,ei_2,el_1][0] DAE[s,d,ei_3,el_1][0] DAE[s,d,ei_4,el_2][0]
    rule6 = Rule.Rule(NT_CCD, [NT_SAD, NT_DAE, NT_DAE, NT_DAE, NT_DAE], [(0,1),(1,2),(2,3),(3,4)], [(-1, 's', 0, 's'),(-1, 's', 1, 's'),(-1, 's', 2, 's'),(-1, 's', 3, 's'),(-1, 's', 4, 's'),(-1, 'd', 0, 'd'),(-1, 'd', 1, 'd'),(-1, 'd', 2, 'd'),(-1, 'd', 3, 'd'),(-1, 'd', 4, 'd')])
    #CSM[s][] -> NS[s][] CCD[s,d][0] SDS[s,ds][0] SR[s,r][0]
    rule7 = Rule.Rule(NT_CSM, [NT_NS, NT_CCD, NT_SDS, NT_SR], [(0,1),(0,2),(0,3)], [(-1, 's', 0, 's'),(-1, 's', 1, 's'),(-1, 's', 2, 's'),(-1, 's', 3, 's')])
    #CSM[s][] -> NS[s][] CCD[s,d_1][0] CCD[s,d_2][0] CCD[s,d_3][0] CCD[s,d_4][0] SDS[s][0] SR[s][0]
    rule8 = Rule.Rule(NT_CSM, [NT_NS, NT_CCD, NT_CCD, NT_CCD, NT_CCD, NT_SDS, NT_SR], [(0,1),(0,2),(0,3),(0,4),(0,5),(0,6)], [(-1, 's', 0, 's'),(-1, 's', 1, 's'),(-1, 's', 2, 's'),(-1, 's', 3, 's'),(-1, 's', 4, 's'),(-1, 's', 5, 's'),(-1, 's', 6, 's')])
    #SRP[][] -> CSM[s][] R[s][0] PO[s,p][]
    rule9 = Rule.Rule(NT_SRP, [NT_CSM, NT_R, NT_PO], [(0,1)], [(0, 's', 1, 's'),(1, 's', 2, 's'),(0, 's', 2, 's')])
    # MR[s,d][] -> DAE[s,d,ei_1,el_1:r][] DAE[s,d,ei_2,el_2:o][] DAE[s,d,ei_3,el_3:s][] DAE[s,d,ei_4,el_4:a][]
    rule10 = Rule.Rule(NT_MR, [NT_DAE, NT_DAE, NT_DAE, NT_DAE], [], [(-1, 's', 0, 's'),(-1, 's', 1, 's'),(-1, 's', 2, 's'),(-1, 's', 3, 's'),(-1, 'd', 0, 'd'),(-1, 'd', 1, 'd'),(-1, 'd', 2, 'd'),(-1, 'd', 3, 'd')])
    # CSM[s][] -> NS[s][] SAD[s,d,dt:Mixer][0] MR[s,d][1] SDS[s,ds:4][1] SR[s][1] CRT[s,d,rt:WoRUNRep][1]
    rule11 = Rule.Rule(NT_CSM, [NT_NS, NT_SAD, NT_MR, NT_SDS, NT_SR, NT_CRT], [(0,1), (1,2), (1,3), (1,4), (1,5)], [(-1,'s',0,'s'),(-1,'s',1,'s'),(-1,'s',2,'s'),(-1,'s',3,'s'),(-1,'s',4,'s'),(-1,'s',5,'s'),(1,'d',2,'d'),(1,'d',5,'d')])
    #DAE[s,d,ei,el][] -> DAE[s,d,ei][] DCE[s,d,ei,el:r][0]
#     rule12 = Rule.Rule(NT_DAEr, [NT_DAE, NT_DCEr], [(0,1)], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(-1, 's', 1, 's'),(-1, 'd', 1, 'd'),(-1, 'ei', 1, 'ei'),(-1, 'el', 1, 'el')])
#     #DAE[s,d,ei,el][] -> DAE[s,d,ei][] DCE[s,d,ei,el:R][0]
#     rule13 = Rule.Rule(NT_DAER, [NT_DAE, NT_DCER], [(0,1)], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(-1, 's', 1, 's'),(-1, 'd', 1, 'd'),(-1, 'ei', 1, 'ei'),(-1, 'el', 1, 'el')])
#     #DAE[s,d,ei,el][] -> DAE[s,d,ei][] DCE[s,d,ei,el:o][0]
#     rule14 = Rule.Rule(NT_DAEo, [NT_DAE, NT_DCEo], [(0,1)], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(-1, 's', 1, 's'),(-1, 'd', 1, 'd'),(-1, 'ei', 1, 'ei'),(-1, 'el', 1, 'el')])
#     #DAE[s,d,ei,el][] -> DAE[s,d,ei][] DCE[s,d,ei,el:O][0]
#     rule15 = Rule.Rule(NT_DAEO, [NT_DAE, NT_DCEO], [(0,1)], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(-1, 's', 1, 's'),(-1, 'd', 1, 'd'),(-1, 'ei', 1, 'ei'),(-1, 'el', 1, 'el')])
#     #DAE[s,d,ei,el][] -> DAE[s,d,ei][] DCE[s,d,ei,el:s][0]
#     rule16 = Rule.Rule(NT_DAEs, [NT_DAE, NT_DCEs], [(0,1)], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(-1, 's', 1, 's'),(-1, 'd', 1, 'd'),(-1, 'ei', 1, 'ei'),(-1, 'el', 1, 'el')])
#     #DAE[s,d,ei,el][] -> DAE[s,d,ei][] DCE[s,d,ei,el:S][0]
#     rule17 = Rule.Rule(NT_DAES, [NT_DAE, NT_DCES], [(0,1)], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(-1, 's', 1, 's'),(-1, 'd', 1, 'd'),(-1, 'ei', 1, 'ei'),(-1, 'el', 1, 'el')])
#     #DAE[s,d,ei,el][] -> DAE[s,d,ei][] DCE[s,d,ei,el:a][0]
#     rule18 = Rule.Rule(NT_DAEa, [NT_DAE, NT_DCEa], [(0,1)], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(-1, 's', 1, 's'),(-1, 'd', 1, 'd'),(-1, 'ei', 1, 'ei'),(-1, 'el', 1, 'el')])
#     #DAE[s,d,ei,el][] -> DAE[s,d,ei][] DCE[s,d,ei,el:A][0]
#     rule19 = Rule.Rule(NT_DAEA, [NT_DAE, NT_DCEA], [(0,1)], [(-1, 's', 0, 's'),(-1, 'd', 0, 'd'),(-1, 'ei', 0, 'ei'),(-1, 's', 1, 's'),(-1, 'd', 1, 'd'),(-1, 'ei', 1, 'ei'),(-1, 'el', 1, 'el')])
    

    ########
    #    Rules for Rain - simple, 1-9
    #    Rules for ROSA  - simple, 1-4, 9-11
    #########
    sigmas = [sigma_C, sigma_CC, sigma_CCD, sigma_CDT, sigma_ChC, sigma_CRT, sigma_CSM,
              sigma_DAE, sigma_DCE, sigma_DrA, sigma_DS, sigma_DT, sigma_MS, sigma_MU, sigma_NA,
              sigma_NP, sigma_NS, sigma_NT, sigma_PO, sigma_Per, sigma_R, sigma_RB, sigma_RS, sigma_S,
              sigma_SA, sigma_SAB, sigma_SAD, sigma_SDS, sigma_SR, sigma_SRP, sigma_SwA, sigma_MR]
    nts = [NT_C, NT_CC, NT_CCD, NT_CDT, NT_ChC, NT_CRT, NT_CSM,
              NT_DAE, NT_DCE, NT_DrA, NT_DS, NT_DT, NT_MS, NT_MU, NT_NA,
              NT_NP, NT_NS, NT_NT, NT_PO, NT_Per, NT_R, NT_RB, NT_RS, NT_S,
              NT_SA, NT_SAB, NT_SAD, NT_SDS, NT_SR, NT_SRP, NT_SwA, NT_MR]
    goals = [NT_SRP]
    rules = [simple_C, simple_CC, simple_CCD, simple_CDT, simple_ChC, simple_CRT, simple_CSM,
              simple_DAE, simple_DAEr, simple_DAER, simple_DAEo, simple_DAEO, simple_DAEs, simple_DAES, simple_DAEa, simple_DAEA,
              simple_DCEr, simple_DCER, simple_DCEo, simple_DCEO, simple_DCEs, simple_DCES, simple_DCEa, simple_DCEA,
              simple_DCE, simple_DrA, simple_DS, simple_DT, simple_MS, simple_MU, simple_NA,
              simple_NP, simple_NS, simple_NT, simple_PO, simple_Per, simple_R, simple_RB, simple_RS, simple_S,
              simple_SA, simple_SAB, simple_SAD, simple_SDS, simple_SR, simple_SRP, simple_SwA, simple_MR]
    if sys.argv[2]=="rain":          
              rules.extend([rule1, rule2, rule3, rule4, rule5, rule6, rule7, rule8, rule9])
    if sys.argv[2]=="rosa":
              rules.extend([rule1, rule2, rule3, rule4, rule9, rule10, rule11])
    return PL.PL(sigmas, nts, goals, rules)


reuthObservations = []

import profile
def main():
    profile.run('myMain()')

def writeExp(exp):
    expAsStr="{ROOT"
    for tree in exp.getTrees():
        expAsStr+=reprTree(tree)
    expAsStr+="}"
    return expAsStr
    
def reprTree(tree):
    if [] == tree._children:
        sid=tree.getRoot().getParam("sid")
        if sid==None:
            sid="X"
        else:
            sid=sid[2:]
        did=tree.getRoot().getParam("did")
        if did==None:
            did="X"
        else:
            did=did[2:]
        if tree.isComplete():
            return sid+"-"+did
        else:
            return "{"+sid+"-"+did+"}"
    
    else:
        treeAsStr="{"
        for child in tree._children:
            treeAsStr+=reprTree(child)
        treeAsStr+="}"
        return treeAsStr
  
    
def myMain():
    
    #initPL()

    fileName = ("C:\\Users\\Owner\\Dropbox (BGU)\\Reuth-new\\Online Plan Recognition\\Workspace\\PHATT-2015\\realData\\TinkerPlots\\PreProcessedLogs\\"+sys.argv[2]+"\\short\\"+sys.argv[1]+".txt")
    file = open(fileName, mode='r')
    lines = file.readlines()
    
    allActions = []
    i = 0
    
    for line in lines:
        #print (line)
        line = line[2:-2]
        #print "line=",line
        tokens = line.split(",")
        actionName = tokens[0][:-1]
        params = []
        for token in tokens[1:]:
            tokenParts = token.split("=")
            #print token
            key = tokenParts[0][1:-1]
            val = tokenParts[1][1:-1]
            params.append((key,val))
            
        obsSigma = Sigma.Sigma(actionName, params)
        i += 1
        print "("+str(i)+") "+str(obsSigma)
        reuthObservations.append(obsSigma)
    
    myPL = initPL()
    #print(myPL)
    
    sys.stdout = open('C:\\Users\\Owner\\Desktop\\test2\\'+sys.argv[2]+'-'+str(sys.argv[1])+'.txt', 'w+')
    exps = Algorithm.ExplainAndCompute(myPL, reuthObservations)
    if len(exps)==0:
        print "No Explnanations"    
    print "\n\n"    
    explanations = 0   
    explanations = 0
    noFrontier = []
    
    exps.sort(key=Explanation.Explanation.getExpProbability)
    
    ####### Code to create goldStandard #####################
#     filee = open("C:\Users\Owner\Dropbox (BGU)\Reuth-new\Online Plan Recognition\Domains\TinkerPlots-Recipe+Logs\\2016\Gold Standard\\"+sys.argv[2]+"-"+sys.argv[1]+".xml", 'a+')
#     print "Total exps=", len(exps)
#     dictionaryToPickFrom = {}
#     singleExps=[]
#     i=0
#     for exp in exps:
# #         if exp.getSize()==1:
# #             print "here"
#             singleExps.append(exp)
#             dictionaryToPickFrom[i]=exp.getExpProbability()
#             i+=1 
#             
#     print "remaining exps:", len(singleExps)
#     print dictionaryToPickFrom
#     chosenExp=singleExps[WeightedPick(dictionaryToPickFrom)]
#     print chosenExp  
#     filee.write("<?xml version=\"1.0\"?>\n")
#     filee.write("<Explanation>\n")
#     for tree in chosenExp.getTrees():
#         filee.write(reprInTPForm(tree)[0])
#     filee.write("</Explanation>\n")
#     filee.close()
#     return
                  
    
    ####### Code to Print Explanations #####################
    firstflag = True
      
    numOfExps = 0
    numOfExpsBySize = {0:0, 1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0, 8:0}
      
    while not len(exps)==0:
        exp = exps.pop()
        numOfExps +=1
        numOfExpsBySize[len(exp._trees)] += 1
          
        if firstflag:
            print "-----------------\n First Exp\n-----------------"
            #print printInTPForm(exp)
            firstflag = False
          
        elif len(exp.getTrees())==1:
            print "-----------------\n Exp with One Tree\n-----------------"
          
        else:
            print "-----------------\n Just Exp\n-----------------"
        print exp
#    mod = 0
#    for exp in noFrontier:
#        if mod==0:
#        print (exp)
  
    print "Total number of exps:", str(numOfExps)
    print "Num of Exps by size:", str(numOfExpsBySize)
    sys.exit()

def WeightedPick(d):
    r = random.uniform(0, sum(d.itervalues()))
    s = 0.0
    for k, w in d.iteritems():
        s += w
        if r < s: return k
    return k

def printInTPForm(explanation):
    if explanation._trees == []:
        return "Empty Explanation"
    res = "<ROOT probName=\"\" answer=\"\">\n"

    for tree in explanation._trees:
        res += reprInTPForm(tree, depth="")[0]
        res += "\n"
    
    res=res[:-1]
    res += "</ROOT>"   
    return res

def reprInTPForm(tree, depth="", pos=0):
    pos+=1
    res = depth+"<"
    res += tree.getRoot().get()+" "
    for (param, val) in tree.getRoot().getParamList():
        if val!=None:
            res += param+"=\""+val+"\" "
    
    res += "isComplete=\""+str(tree.isComplete())+"\" "   
    res += "pos=\""+str(pos)+"\""    
    lastPos=pos
    
    if [] == tree._children: # or tree._children[0].getRoot().get()==tree.getRoot().get():
        res +="/>\n"
        
    else:
        res +=">\n"
        for child in tree._children:
            childRepr = reprInTPForm(child, depth+"\t", pos=lastPos) 
            res+=childRepr[0]
            lastPos=childRepr[1]
            
        res += depth+"</"+tree.getRoot().get()+">\n"
        
    return (res, lastPos)
    
    
if __name__ == '__main__': main()