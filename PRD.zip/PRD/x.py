from Queue import Queue
from copy import deepcopy 
from Explanation import Explanation
from Sigma import Letter, Sigma
from NT import NT
from Rule import Rule
from Tree import Tree
import random
from math import log
import sys
import xml.etree.ElementTree as ET
import time
import Algorithm

#home
#location = "Owner"
#office
location = "dekelr"    

oldNumExps = 0;
oldNumTrees = 0;
queriesNumber = 0;

expsByQueries = "C:\\Users\\"+location+"\\Desktop\\test2\\ExpsByQueries.csv" 
treesByQueries = "C:\\Users\\"+location+"\\Desktop\\test2\\TreesByQueries.csv" 
queriesAsked = "C:\\Users\\"+location+"\\Desktop\\test2\\Queries.csv"

resultExps = ""
resultTrees = ""

treesMatrix={}

##############################################################################################################################
#                                            Basic Functions
##############################################################################################################################
def NormalizeProbabilities(exps):
    totalProbability = 0.0
    for exp in exps:
        totalProbability += exp.getExpProbability()
    
    for exp in exps:
        probability = exp.getExpProbability() / totalProbability
        exp.setExpProbability(probability)        

# Best is the set of trees to compare to
# other is the tree to compare
# Operator is either Refine/Match
def compareToBestExp(best, other, operator):   
    for tree in best:
        if operator(tree, other):
            return True
    return False

##############################################################################################################################
#                                            Refine / Match / Contain
##############################################################################################################################
###  MATCH OPERATOR ######        
def Match(this, other):
#   1. if this.name!=other.name
    if not other.getRoot().matchLetter(this.getRoot()):
        return False

#   2. if one of them is open
    if (not this.isComplete()) or (not other.isComplete()):
        return True 

#   3.      If p1 and p2 are basic actions return True - implicitly checked 
#   4.      If p1 and p2 are complex actions
    if len(this._children) != len(other._children):
        return False

#   5. recursive check for children
    for childIndex in range(len(other._children)):
        if not Match(this._children[childIndex], other._children[childIndex]):
            return False
    return True

###  Refine OPERATOR ######        
def Refines(this, other):      #"This" is the bigger tree and we want to know if it is a refinement of "other"   
    if not other.getRoot().matchLetter(this.getRoot()):
        #print "this is the problem1"
        return False
    
    if type(this.getRoot().get())==Sigma:
        return True 

    if other.isComplete() and not this.isComplete():
        #print "this is the problem2"
        return False

    if this.isComplete() and not other.isComplete():
        return True
         
    if len(other._children) != len(this._children):
        #print "this is the problem3"
        return False
    
    for childIndex in range(len(other._children)):

        if not Refines(this._children[childIndex], other._children[childIndex]):
            #print "this is the problem4"
            return False
            
    return True

def readRefinesProbabilites(biggerTreeIndex, smallerTreeIndex):
    global treesMatrix
    
    return smallerTreeIndex in treesMatrix[biggerTreeIndex][0] 

def readContainsProbabilites(biggerTreeIndex, smallerTreeIndex):
    global treesMatrix
    
    return biggerTreeIndex in treesMatrix[smallerTreeIndex][0] 
    
def readMatchProbabilites(biggerTreeIndex, smallerTreeIndex):
    global treesMatrix
    
    return smallerTreeIndex in treesMatrix[biggerTreeIndex][1]

def createMatrices(exps):
    global treesMatrix
    for exp in exps:
        for biggerTree in exp.getTrees():
            biggerTreeID = biggerTree.getID()
            treesMatrix[biggerTreeID] = ([biggerTreeID],[biggerTreeID]) #0 is contains, 1 is match
            for exp in exps:
                for smallerTree in exp.getTrees():
                    smallerTreeID = smallerTree.getID()
                    if smallerTreeID in treesMatrix[biggerTreeID]:
                        continue
                    else:
                        if Refines(biggerTree, smallerTree):
                            treesMatrix[biggerTreeID][0].append(smallerTreeID)
                        if Match(biggerTree, smallerTree):
                            treesMatrix[biggerTreeID][1].append(smallerTreeID)                          
    
    return

# Tree is the tree to get probability of
# Exps is the set of all explanations
# Operator is either readRefinesProbabilites/readContainesProbabilites/readMatchProbabilites
def GetProbability(tree, exps, operator):
    probabilityWithTree = 0.0
    probabilityWithoutTree = 0.0
    expsWith = 0
    expsWithout = 0
    for exp in exps:
        contains = False
        for biggerTree in exp.getTrees():
            if operator(biggerTree.getID(), tree.getID()):
                contains = True
                break
        if contains:
            probabilityWithTree += exp.getExpProbability()
            expsWith += 1
        else:
            probabilityWithoutTree += exp.getExpProbability()
            expsWithout += 1
    
    treeProbability = probabilityWithTree / (probabilityWithTree+probabilityWithoutTree)
    #print tree.getID(), ": ", probabilityWithTree, "(", expsWith, "), ", probabilityWithoutTree,"(", expsWithout, "),", treeProbability
    return treeProbability


##############################################################################################################################
#                                            Read Best Exp for Different Domains
##############################################################################################################################            

###  DOPLAR  ######    
def readBestExpFromFile_Doplar(PL):
    xmltree = ET.parse("C:\\Users\\"+location+"\\Desktop\\goldStandard-2-3-3-2-2-full-20\\"+sys.argv[2]+".xml")
    explanation = xmltree.getroot()
    children = explanation.getchildren()
    parsedExp = []
    for child in children:
        parsedTree = parseTreeFromXML_Doplar(child, PL)
        parsedExp.append(parsedTree)
    return parsedExp
    
def parseTreeFromXML_Doplar(root, PL):
    children = root.getchildren()
    
    if root.tag[0] == "A":
        t = Tree("Basic", Sigma(root.tag, []), [], [], PL)
        t._isComplete=True
        return t

    else:
        tree = Tree("Complex", NT(root.tag, []), [], [], PL)
        isComplete=True
        for child in children:
            treeChild = parseTreeFromXML_Doplar(child, PL)
            if not treeChild.isComplete():
                isComplete=False
            tree._children.append(treeChild)

        tree._isComplete=isComplete
            
        return tree


###  Virtual Labs  ######
def readBestExpFromFile_VL(PL):
    xmltree = ET.parse("C:\Users\\"+location+"\Desktop\VirtualLabs\GoldStandard\\"+sys.argv[1]+".xml")
        
    trees = xmltree.getroot().getchildren()# = xmltree.getroot()
    parsedExp = []
    for tree in trees:
        parsedTree = parseTreeFromXML_VL(tree, PL)
        parsedTree.getRoot()._ch='C'
        parsedTree.isComplete()
        parsedExp.append(parsedTree)
    return parsedExp
    
def parseTreeFromXML_VL(root, PL):
    children = root.getchildren()
    params = []
    isOpen = False
    for key in root.attrib.keys():
        if root.attrib[key]=="-1":
            isOpen = True
            params.append((key, None))
        else:
            params.append((key, root.attrib[key]))
            
    if children == []:
        if isOpen:
            tree = Tree("Complex", NT('SM', params), [], [], PL)
            return tree
        else:
            tree = Tree("Basic", Sigma('sm', params), [], [], PL)
            tree._isComplete=True
            return tree

    else:
        tree = Tree("Complex", NT('SM', params), [], [], PL)
        isComplete=True
        print "here with", tree
        for child in children:
            print "   child=", treeChild
            treeChild = parseTreeFromXML_VL(child, PL)
            if not treeChild.isComplete():
                print "not complete - false"
                isComplete=False
            tree._children.append(treeChild)
        return tree    
        

##############################################################################################################################
#                                            Probe Strategies
##############################################################################################################################

###  MPT  ######    
def probeByMostProbableTree(exps=[], askedAbout=[]):
    IDsAndProbs = {}
    IDsAndTrees = {}
    treesOrderedByProbability = {}
   
    #Calculate the probabilities of the remaining trees
    for exp in exps:
        for tree in exp.getTrees():
            if tree.getID() not in IDsAndProbs.keys():
                IDsAndProbs[tree.getID()] = GetProbability(tree, exps, readRefinesProbabilites) 
                IDsAndTrees[tree.getID()] = tree
                if IDsAndProbs[tree.getID()] not in treesOrderedByProbability.keys():
                    treesOrderedByProbability[IDsAndProbs[tree.getID()]] = [tree.getID()]
                else:
                    treesOrderedByProbability[IDsAndProbs[tree.getID()]].append(tree.getID())
    
    #Remove Trees already asked about
    probabilityToSearch = 0
    treeIDToProb = -1
    while 0==probabilityToSearch or (treeIDToProb in askedAbout):
        if probabilityToSearch!=0:
            treesOrderedByProbability[probabilityToSearch].pop()
            if 0==len(treesOrderedByProbability[probabilityToSearch]):
                del treesOrderedByProbability[probabilityToSearch]

        if len(treesOrderedByProbability)==0:
            return [-1, []]     #Meaning all trees were queried about once
        
        probabilityToSearch = max(treesOrderedByProbability.keys())
        treeIDToProb = treesOrderedByProbability[probabilityToSearch][-1]
        treeToProbeFor = IDsAndTrees[treeIDToProb]
    
    #Ask about this tree
    askedAbout.append(treeIDToProb) 
    print "Number of trees: ", len(IDsAndProbs.keys())
    return [treeToProbeFor, askedAbout]


###  MPE  ######    
def probeByMostProbableExp(exps=[], askedAbout=[]):
    expsByProbability= {}
    trees = []

    # Collect explanations by probability            
    for exp in exps:
        for tree in exp.getTrees():
            if tree.getID() not in trees:
                trees.append(tree.getID())
        expProb = exp.getExpProbability()
        if expProb not in expsByProbability.keys():
            expsByProbability[expProb] = [exp]
        else:
            expsByProbability[expProb].append(exp)
    
       
    #Remove Trees already asked about
    probabilityToSearch = 0
    treeIDToProb = -1

    while 0==probabilityToSearch or (treeIDToProb in askedAbout):
        if probabilityToSearch!=0:
            expsByProbability[probabilityToSearch].pop(0)
            if 0==len(expsByProbability[probabilityToSearch]):
                del expsByProbability[probabilityToSearch]

        if len(expsByProbability)==0:
            return [-1, []]     #Meaning all trees were queried about once
        
        
        probabilityToSearch = max(expsByProbability.keys())
        i = 0 
        while i==0 or i<len(expsByProbability[probabilityToSearch][0].getTrees()):
            treeToProbeFor = expsByProbability[probabilityToSearch][0].getTrees()[i]
            treeIDToProb = treeToProbeFor.getID()    
            if (treeIDToProb not in askedAbout):
                break
            i+=1
        
    #Ask about this tree
    askedAbout.append(treeIDToProb) 
    print "Number of trees: ", len(trees)
    return [treeToProbeFor, askedAbout]
  
  
###  Entropy  ######      
def probeByEntropy(exps=[], askedAbout=[]):
    treeIDtoTree = {}
    
    for exp in exps:
        for tree in exp.getTrees():
            treeID = tree.getID()
            if treeID not in treeIDtoTree:  #If this is the first time we see this tree
                treeIDtoTree[treeID] = tree              

    #Collect probabilities of all explanations remaining in the system with and without tree
    informationGainPerTree = {}
    
    for treeID in treeIDtoTree.keys():
        entropyWithTree=0
        entropyWithoutTree=0
        
        #Calculate Ent(phi(H, t, True)) and Ent(phi(H, t, False))
        for exp in exps:
            refines = False
            for bigTree in exp.getTrees():
                if readRefinesProbabilites(bigTree.getID(), treeID):
                    refines = True
                    break
                if readMatchProbabilites(bigTree.getID(), treeID):
                    expProb=exp.getExpProbability()
                    entropyWithTree-=(expProb * log(expProb,2))
                    break
            if not refines:
                expProb=exp.getExpProbability()
                entropyWithoutTree-=(expProb * log(expProb,2))
        
        #Calculate Information Gain    
        tree = treeIDtoTree[treeID]
        treeProbabilityR = GetProbability(tree, exps, readRefinesProbabilites)
        treeProbabilityM = GetProbability(tree, exps, readMatchProbabilites)
        informationGain = treeProbabilityM*entropyWithTree + (1-treeProbabilityR)*entropyWithoutTree
        
        if informationGain in informationGainPerTree:
            informationGainPerTree[informationGain].append(treeID) 
        else:
            informationGainPerTree[informationGain] = [treeID]


    treeIDToProb = 0
    #Remove Trees already asked about
    while 0==treeIDToProb or (treeIDToProb in askedAbout):
        if treeIDToProb!=0:
            minEntropy = min(informationGainPerTree.keys())
            informationGainPerTree[minEntropy].remove(treeIDToProb)
            if 0==len(informationGainPerTree[minEntropy]):
                del informationGainPerTree[minEntropy]

        if len(informationGainPerTree)==0:
            return [-1, []]     #Meaning all trees were queried about once
        
        minEntropy = min(informationGainPerTree.keys())
        treeIDToProb = informationGainPerTree[minEntropy][0]
        treeToProbeFor = treeIDtoTree[treeIDToProb] 
    
    #Ask about this tree
    askedAbout.append(treeIDToProb) 
    print "Number of trees: ", len(treeIDtoTree.keys())
    return [treeToProbeFor, askedAbout]
    
    
###  Random  ######        
def probeByRandom(exps=[], askedAbout=[]):
    trees = []
    IDs = []
        
    for exp in exps:
        for tree in exp.getTrees():
            if tree.getID() not in IDs:
                trees.append(tree)
                IDs.append(tree.getID())
    
    #Remove Trees already asked about
    treeIDToProb = 0
    treeToProbeFor = None
    while 0==treeIDToProb or (treeIDToProb in askedAbout):
        if treeIDToProb!=0:
            IDs.remove(treeIDToProb)
            trees.remove(treeToProbeFor)
        if len(IDs)==0:
            return [-1, []]     #Meaning all trees were queried about once
        
        #Find Tree by random 
        treeToProbeFor = random.choice(trees)
        treeIDToProb = treeToProbeFor.getID()
        
    #Ask about this tree
    askedAbout.append(treeIDToProb) 
    print "Number of trees: ", len(trees)
    return [treeToProbeFor, askedAbout]

##############################################################################################################################
#                                            Query Function
##############################################################################################################################
    
def query(exps=[], askedAbout=[], probingStrategy=probeByRandom):
    #print "------------ Explanations at this Point --------------"
    #print exps

    #createMatrices(exp) - should be performed higher in hierarchy, because this is not needed to be calculated every query

    NormalizeProbabilities(exps)
    bestExp = readBestExpFromFile_VL(exps[0].getTrees()[0]._PL)
    
    [treeToProbeFor, newAskedAbout] = probingStrategy(exps, askedAbout)

    global oldNumExps, oldNumTrees, resultExps, resultTrees, queriesNumber
    queriesNumber+=1

    if oldNumExps!=0:
        resultExps+=str(oldNumExps)+","+str(len(exps))+"\n"
    oldNumExps=len(exps)

    trees = []
    for exp in exps:
        for treeID in exp.getTreeIDs(): 
            if treeID not in trees:
                trees.append(treeID)
                    
    if oldNumTrees!=0:
        resultTrees+=str(oldNumTrees)+","+str(len(trees))+"\n"
    oldNumTrees=len(trees)
    
    if treeToProbeFor == -1:
        print "------------------ Cannot Discard Any More Hypotheses -------------------"
        
        file1 = open(expsByQueries, 'a+')
        file2 = open(treesByQueries, 'a+')
        file3 = open(queriesAsked, 'a+')
        resultExps += str(resultExps.count("\n"))+"\n"
        resultTrees += str(resultTrees.count("\n"))+"\n"
        file1.write(resultExps)
        file2.write(resultTrees)
        file3.write(sys.argv[1]+","+str(queriesNumber-1)+"\n")
        file1.close()
        file2.close()
        
        return exps    
   
    print "Is this part of your plan?"
    print treeToProbeFor.reprWithParams()
    
    print "Best is:"
    for tree in bestExp:
        print tree.reprWithParams()
    
    ### See if the treeToProbeFor can be refined to one of the trees in "best"
    isPart = compareToBestExp(bestExp, treeToProbeFor, Refines)
    print isPart
    
    newExps = []
    
    ### QA(p)=True, we need to keep all hypotheses with p' s.t. p ~m p'
    if isPart:
        for exp in exps:
            for tree in exp.getTrees():
                if Match(tree, treeToProbeFor):
                    newExps.append(exp)
                    break
        
    ### QA(p)=False, we need to keep all hypotheses with no p' s.t. p ~r p'      
    else:
        newExps = exps
        for exp in exps:
            for tree in exp.getTrees():
                if Refines(tree, treeToProbeFor):
                    newExps.remove(exp)
                    break
    
    ### Do we need to perform another query? 
    if 1==len(newExps):
        print "------------------ The Final Explanation is: -------------------"
        print newExps[0]
        print resultExps, resultTrees
        file1 = open(expsByQueries, 'a+')
        file2 = open(treesByQueries, 'a+')
        file3 = open(queriesAsked, 'a+')
        resultExps+=str(oldNumExps)+",1\n"
        resultTrees+=str(oldNumExps)+","+str(len(newExps[0].getTrees()))+"\n"   
        resultExps += str(resultExps.count("\n"))+"\n"
        resultTrees += str(resultTrees.count("\n"))+"\n"     
        file1.write(resultExps)
        file2.write(resultTrees)
        file3.write(sys.argv[1]+","+str(queriesNumber)+"\n")
        file1.close()
        file2.close()
        file3.close()
        return newExps
    
    elif 1<len(newExps):
        return query(newExps, newAskedAbout, probingStrategy)
            
    else:
        print "------------------ No Explanation Fits the Probing ------------------"
        return []    
    
    